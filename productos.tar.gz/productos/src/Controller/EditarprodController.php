<?php

namespace App\Controller;

use App\Entity\Products;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class EditarprodController extends AbstractController
{
    /**
     * @Route("/editarprod", name="editarprod")
     */
    public function index($id)
    {

        $em = $this->getDoctrine()->getManager();
        $product = $em->getRepository(Products::class)->find($id);
        

        return $this->render('editarprod/index.html.twig', [
            'controller_name' => 'Editar Producto',
            'product' => array($product)
        ]);
    }


    public function update(Request $request,$id)
    {
        $idproduct = $id;

        $entityManager = $this->getDoctrine()->getManager();
        $product = $entityManager->getRepository(Products::class)->find($id);

        $code        = $request->get('code');
        $name        = $request->get('name');
        $description = $request->get('description');
        $brand       = $request->get('brand');
        $category    = $request->get('category');
        $cost        = $request->get('cost');

        $product->setName($name);
        $product->setDescription($description);
        $product->setBrand($brand);
        //$product->setCategory($category);
        $product->setCost($cost);
        $flush=$entityManager->flush();
        
        //echo 'producto modificado';

        $em = $this->getDoctrine()->getManager();
        $products = $em->getRepository(Products::class)->findAll();

        if ($flush == null){
            $this->addFlash('exito','Se ha modificado el producto con exito');

            return $this->render('products/index.html.twig', [
                'controller_name' => 'Lista de Productos Disponibles',
                'products' => $products
            ]);
        }else{
            $this->addFlash('error','Ha ocurrido un problema al modificar el producto.');

            return $this->render('products/index.html.twig', [
                'controller_name' => 'Lista de Productos Disponibles',
                'products' => $products
            ]);
        }

        

    }  
}