<?php

namespace App\Controller;

use App\Entity\Categories;
use App\Form\CategoriesType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class RegistrocatController extends AbstractController
{
    /**
     * @Route("/registrocat", name="registrocat")
     */
    public function index(Request $request)
    {
        $categories = new Categories();
        $form = $this->createForm(CategoriesType::class, $categories);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()){
            $em = $this->getDoctrine()->getManager();
            $em->persist($categories);
            $em->flush();
            $this->addFlash('exito','Se ha registrado la categoria con exito');
            return $this->redirectToRoute('registrocat');
        }

        return $this->render('registrocat/index.html.twig', [
            'controller_name' => 'Registro de Categorias',
            'formulario'      => $form->createView()
        ]);
    }
}
