<?php

namespace App\Controller;

use App\Entity\Products;
use App\Form\ProductsType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class RegistroController extends AbstractController
{
    /**
     * @Route("/registro", name="registro")
     */
    public function index(Request $request)
    {
        $products = new Products();
        $form = $this->createForm(ProductsType::class, $products);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()){
            $em = $this->getDoctrine()->getManager();
            $em->persist($products);
            $em->flush();
            $this->addFlash('exito','Se ha registrado el producto con exito');
            return $this->redirectToRoute('products');
        }

        return $this->render('registro/index.html.twig', [
            'controller_name' => 'Registro de Productos',
            'formulario'      => $form->createView()
        ]);
    }
}
