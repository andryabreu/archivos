<?php

namespace App\Controller;

use App\Entity\Products;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\BrowserKit\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class EliminarprodController extends AbstractController
{
    /**
     * @Route("/eliminarprod", name="eliminarprod")
     */
    public function index($id)
    {
        
        $idproducto = $id;
        //echo $idproducto;
        
        $em = $this->getDoctrine()->getManager();
        $products = $em->getRepository(Products::class);
 
        $product = $products->find($id);
        $em->remove($product);
        $flush=$em->flush();
        
 
        if ($flush == null) {
            $this->addFlash('exito','El producto ha sido eliminado con exito!');
            return $this->redirectToRoute('products');
            
        } else {
            $this->addFlash('error','El producto no ha podido ser eliminado!');
            return $this->redirectToRoute('products');
        }
        
        return $this->render('eliminarprod/index.html.twig', [
            'controller_name' => 'EliminarprodController',
            
        ]);
    }
}
