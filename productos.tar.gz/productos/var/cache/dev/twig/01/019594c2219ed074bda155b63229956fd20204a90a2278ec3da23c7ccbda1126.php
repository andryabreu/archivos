<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* editarprod/index.html.twig */
class __TwigTemplate_bd0f9e11e1b81b40bc5fa0d2bcc58702648d86fc94cd0b4ce8e3301ede4144f8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "editarprod/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "editarprod/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "editarprod/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Editar Producto";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<div class=\"example-wrapper\">
    <h1>";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["controller_name"]) || array_key_exists("controller_name", $context) ? $context["controller_name"] : (function () { throw new RuntimeError('Variable "controller_name" does not exist.', 12, $this->source); })()), "html", null, true);
        echo "! ✅</h1>

   <p><a href=\"";
        // line 14
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Listar Produtos&nbsp;&nbsp;<i class=\"bi bi-card-checklist\"></i></a></p>
    
    ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["product"]) || array_key_exists("product", $context) ? $context["product"] : (function () { throw new RuntimeError('Variable "product" does not exist.', 16, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["valor"]) {
            // line 17
            echo "    <form name=\"editprod\" id=\"editprod\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("editarprod2", ["id" => twig_get_attribute($this->env, $this->source, $context["valor"], "id", [], "any", false, false, false, 17)]), "html", null, true);
            echo "\">

        <table class=\"table\">
            
            <tbody>
                <tr>
                    <td>
                    <div class=\"mb-3\">
                        <label for=\"code\" class=\"form-label\">Codigo</label>
                        <input value=\"";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "code", [], "any", false, false, false, 26), "html", null, true);
            echo "\" type=\"text\" class=\"form-control\" id=\"code\" name=\"code\" readonly>
                    </div>
                    </td>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Nombre</label>
                            <input value=\"";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "name", [], "any", false, false, false, 32), "html", null, true);
            echo "\" type=\"text\" class=\"form-control\" id=\"name\" name=\"name\" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Descripcion</label>
                            <input value=\"";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "description", [], "any", false, false, false, 40), "html", null, true);
            echo "\" type=\"text\" class=\"form-control\" id=\"description\" name=\"description\" required>
                        </div>
                    </td>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Marca</label>
                            <input value=\"";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "brand", [], "any", false, false, false, 46), "html", null, true);
            echo "\" type=\"text\" class=\"form-control\" id=\"brand\" name=\"brand\" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Categoria</label>
                            <input value=\"";
            // line 54
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "category", [], "any", false, false, false, 54), "html", null, true);
            echo "\" type=\"text\" class=\"form-control\" id=\"category\" name=\"category\">
                        </div>
                    </td>
                
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Costo</label>
                            <input value=\"";
            // line 61
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "cost", [], "any", false, false, false, 61), "html", null, true);
            echo "\" type=\"text\" class=\"form-control\" id=\"cost\" name=\"cost\" required>
                        </div>
                    </td>
                </tr>
                
            </tbody>
        </table>
        <button type=\"submit\" class=\"btn btn-primary mb-3\">Modificar Producto</button>  
    </form>   
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['valor'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        echo "    

   
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "editarprod/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  189 => 71,  173 => 61,  163 => 54,  152 => 46,  143 => 40,  132 => 32,  123 => 26,  110 => 17,  106 => 16,  101 => 14,  96 => 12,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Editar Producto{% endblock %}

{% block body %}
<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<div class=\"example-wrapper\">
    <h1>{{ controller_name }}! ✅</h1>

   <p><a href=\"{{ path('products') }}\">Listar Produtos&nbsp;&nbsp;<i class=\"bi bi-card-checklist\"></i></a></p>
    
    {% for valor in product %}
    <form name=\"editprod\" id=\"editprod\" method=\"post\" action=\"{{ path('editarprod2',{id:valor.id}) }}\">

        <table class=\"table\">
            
            <tbody>
                <tr>
                    <td>
                    <div class=\"mb-3\">
                        <label for=\"code\" class=\"form-label\">Codigo</label>
                        <input value=\"{{ valor.code }}\" type=\"text\" class=\"form-control\" id=\"code\" name=\"code\" readonly>
                    </div>
                    </td>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Nombre</label>
                            <input value=\"{{ valor.name }}\" type=\"text\" class=\"form-control\" id=\"name\" name=\"name\" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Descripcion</label>
                            <input value=\"{{ valor.description }}\" type=\"text\" class=\"form-control\" id=\"description\" name=\"description\" required>
                        </div>
                    </td>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Marca</label>
                            <input value=\"{{ valor.brand }}\" type=\"text\" class=\"form-control\" id=\"brand\" name=\"brand\" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Categoria</label>
                            <input value=\"{{ valor.category }}\" type=\"text\" class=\"form-control\" id=\"category\" name=\"category\">
                        </div>
                    </td>
                
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Costo</label>
                            <input value=\"{{ valor.cost }}\" type=\"text\" class=\"form-control\" id=\"cost\" name=\"cost\" required>
                        </div>
                    </td>
                </tr>
                
            </tbody>
        </table>
        <button type=\"submit\" class=\"btn btn-primary mb-3\">Modificar Producto</button>  
    </form>   
    {% endfor %}
    

   
</div>
{% endblock %}
", "editarprod/index.html.twig", "/var/www/productos/templates/editarprod/index.html.twig");
    }
}
