<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @MopaBootstrap/Form/formflow_buttons.html.twig */
class __TwigTemplate_6168648c692a08b4efc9dbd23c6e320520031495ac3abd33ec3619653214af2e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/Form/formflow_buttons.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/Form/formflow_buttons.html.twig"));

        // line 1
        $context["renderBackButton"] = twig_in_filter(twig_get_attribute($this->env, $this->source, (isset($context["flow"]) || array_key_exists("flow", $context) ? $context["flow"] : (function () { throw new RuntimeError('Variable "flow" does not exist.', 1, $this->source); })()), "getCurrentStep", [], "method", false, false, false, 1), range((twig_get_attribute($this->env, $this->source, (isset($context["flow"]) || array_key_exists("flow", $context) ? $context["flow"] : (function () { throw new RuntimeError('Variable "flow" does not exist.', 1, $this->source); })()), "getFirstStep", [], "method", false, false, false, 1) + 1), twig_get_attribute($this->env, $this->source, (isset($context["flow"]) || array_key_exists("flow", $context) ? $context["flow"] : (function () { throw new RuntimeError('Variable "flow" does not exist.', 1, $this->source); })()), "getLastStep", [], "method", false, false, false, 1)));
        // line 2
        echo "<div class=\"form-actions form-flow-actions\">
    ";
        // line 8
        echo "    <button type=\"submit\" class=\"btn btn-primary\">";
        // line 9
        if ((-1 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["flow"]) || array_key_exists("flow", $context) ? $context["flow"] : (function () { throw new RuntimeError('Variable "flow" does not exist.', 9, $this->source); })()), "getCurrentStep", [], "method", false, false, false, 9), twig_get_attribute($this->env, $this->source, (isset($context["flow"]) || array_key_exists("flow", $context) ? $context["flow"] : (function () { throw new RuntimeError('Variable "flow" does not exist.', 9, $this->source); })()), "getMaxSteps", [], "method", false, false, false, 9)))) {
            // line 10
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("button.next", [], "CraueFormFlowBundle"), "html", null, true);
        } else {
            // line 12
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("button.finish", [], "CraueFormFlowBundle"), "html", null, true);
        }
        // line 14
        echo "</button>

    <button type=\"submit\" name=\"";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["flow"]) || array_key_exists("flow", $context) ? $context["flow"] : (function () { throw new RuntimeError('Variable "flow" does not exist.', 16, $this->source); })()), "getFormTransitionKey", [], "method", false, false, false, 16), "html", null, true);
        echo "\" value=\"back\" class=\"btn btn-primary";
        if ( !(isset($context["renderBackButton"]) || array_key_exists("renderBackButton", $context) ? $context["renderBackButton"] : (function () { throw new RuntimeError('Variable "renderBackButton" does not exist.', 16, $this->source); })())) {
            echo " disabled";
        }
        echo "\" formnovalidate=\"formnovalidate\"";
        if ( !(isset($context["renderBackButton"]) || array_key_exists("renderBackButton", $context) ? $context["renderBackButton"] : (function () { throw new RuntimeError('Variable "renderBackButton" does not exist.', 16, $this->source); })())) {
            echo " disabled=\"disabled\"";
        }
        echo ">";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("button.back", [], "CraueFormFlowBundle"), "html", null, true);
        // line 18
        echo "</button>

    <button type=\"submit\" name=\"";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["flow"]) || array_key_exists("flow", $context) ? $context["flow"] : (function () { throw new RuntimeError('Variable "flow" does not exist.', 20, $this->source); })()), "getFormTransitionKey", [], "method", false, false, false, 20), "html", null, true);
        echo "\" value=\"reset\" class=\"btn btn-primary\" formnovalidate=\"formnovalidate\">";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("button.reset", [], "CraueFormFlowBundle"), "html", null, true);
        // line 22
        echo "</button>
</div>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "@MopaBootstrap/Form/formflow_buttons.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 22,  82 => 21,  79 => 20,  75 => 18,  73 => 17,  62 => 16,  58 => 14,  55 => 12,  52 => 10,  50 => 9,  48 => 8,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set renderBackButton = flow.getCurrentStep() in (flow.getFirstStep() + 1) .. flow.getLastStep() %}
<div class=\"form-actions form-flow-actions\">
    {#
        Default button (the one trigged by pressing the enter/return key) must be defined first.
        Thus, all buttons are defined in reverse order and will be reversed again via CSS.
        See http://stackoverflow.com/questions/1963245/multiple-submit-buttons-specifying-default-button
    #}
    <button type=\"submit\" class=\"btn btn-primary\">
        {%- if flow.getCurrentStep() < flow.getMaxSteps() -%}
            {{- 'button.next' | trans({}, 'CraueFormFlowBundle') -}}
        {%- else -%}
            {{- 'button.finish' | trans({}, 'CraueFormFlowBundle') -}}
        {%- endif -%}
    </button>

    <button type=\"submit\" name=\"{{ flow.getFormTransitionKey() }}\" value=\"back\" class=\"btn btn-primary{% if not renderBackButton %} disabled{% endif %}\" formnovalidate=\"formnovalidate\"{% if not renderBackButton %} disabled=\"disabled\"{% endif %}>
        {{- 'button.back' | trans({}, 'CraueFormFlowBundle') -}}
    </button>

    <button type=\"submit\" name=\"{{ flow.getFormTransitionKey() }}\" value=\"reset\" class=\"btn btn-primary\" formnovalidate=\"formnovalidate\">
        {{- 'button.reset' | trans({}, 'CraueFormFlowBundle') -}}
    </button>
</div>
", "@MopaBootstrap/Form/formflow_buttons.html.twig", "/var/www/productos/vendor/mopa/bootstrap-bundle/Resources/views/Form/formflow_buttons.html.twig");
    }
}
