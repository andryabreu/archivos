<?php

namespace App\Controller;

use App\Entity\Products;
use App\Entity\Categories;
use App\Form\ProductsType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class RegistroController extends AbstractController
{
    
    /**
     * @Route("/agregarprod", name="agregarprod")
     */
    public function index(){
        

        return $this->render('registro/index.html.twig', [
            'controller_name' => 'Registro de Productos',
            
        ]);
    }
    
    
    /**
     * @Route("/registroprod", name="registroprod")
     */
    public function store(Request $request)
    {
        /*
        $products = new Products();
        $form = $this->createForm(ProductsType::class, $products);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()){
            $em = $this->getDoctrine()->getManager();
            $em->persist($products);
            $em->flush();
            $this->addFlash('exito','Se ha registrado el producto con exito');
            return $this->redirectToRoute('products');
        }
        */
        $code        = $request->get('code');
        $name        = $request->get('name');
        $description = $request->get('description');
        $brand       = $request->get('brand');
        $cost        = $request->get('cost');
        

        $product = new Products();
        $product->setCode($code);
        $product->setName($name);
        $product->setDescription($description);
        $product->setBrand($brand);
        $product->setCost($cost);
        

        $em = $this->getDoctrine()->getManager();

        $em->persist($product);
        $result = $em->flush();

        $em = $this->getDoctrine()->getManager();
        $products = $em->getRepository(Products::class)->findAll();

        if ($result == null){
            
            $this->addFlash('exito','Se ha registrado el producto con exito');
            return $this->render('products/index.html.twig', [
                'controller_name' => 'Registro de Productos',
                'products'      => $products
            ]);
        }else{
            
            $this->addFlash('error','ERROR: Se ha presentado un error al registrar el producto');
            return $this->render('products/index.html.twig', [
                'controller_name' => 'Registro de Productos',
                'products'      => $products
            ]);
        }


        return $this->render('registro/index.html.twig', [
            'controller_name' => 'Registro de Productos',
            //'formulario'      => $form->createView()
        ]);
    }
}
