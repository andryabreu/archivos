<?php

namespace App\Controller;

use App\Entity\Categories;
use App\Form\CategoriesType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class RegistrocatController extends AbstractController
{

    /**
     * @Route("/agregarcat", name="agregarcat")
     */
    public function index(){

        return $this->render('registrocat/index.html.twig', [
            'ingresar' => 'Registrar Categoria',
            
        ]);
    }

    /**
     * @Route("/editarcat", name="editarcat")
     */
    public function update($id){
        $entityManager = $this->getDoctrine()->getManager();
        $category = $entityManager->getRepository(Categories::class)->find($id);

        return $this->render('registrocat/editarcat.html.twig', [
            'editar'   => 'Editar Categoria',
            'category' => array($category)
            
        ]);
    }

    /**
     * @Route("/editarcat2", name="editarcat2")
     */
    public function update2(Request $request, $id){
        $entityManager = $this->getDoctrine()->getManager();
        $category = $entityManager->getRepository(Categories::class)->find($id);

        $code        = $request->get('code');
        $name        = $request->get('name');
        $description = $request->get('description');
        $active      = $request->get('active');

        $category = new Categories();
        $category->setCode($code);
        $category->setName($name);
        $category->setDescription($description);
        $category->setActive($active);

        $em = $this->getDoctrine()->getManager();

        $em->persist($category);
        $result = $em->flush();

        $em = $this->getDoctrine()->getManager();
        $categories = $em->getRepository(Categories::class)->findAll();

        if ($result == null){
            
            $this->addFlash('exito','Se ha modificado la categoria con exito');
            return $this->render('categories/index.html.twig', [
                'controller_name' => 'Registro de Categorias',
                'categories'      => $categories
            ]);
        }else{
            
            $this->addFlash('error','ERROR: Se ha presentado un error al modificar la categoria');
            return $this->render('categories/index.html.twig', [
                'controller_name' => 'Registro de Categorias',
                'categories'      => $categories
            ]);
        }

        return $this->render('registrocat/editarcat.html.twig', [
            'editar'   => 'Editar Categoria',
            'category' => array($category)
            
        ]);
    }




    /**
     * @Route("/eliminarcat", name="eliminarcat")
     */
    public function delete($id){
        $em = $this->getDoctrine()->getManager();
        $category = $em->getRepository(Categories::class)->find($id);
        $em->remove($category);
        $flush=$em->flush();

        if ($flush == null) {
            $this->addFlash('exito','La categoria ha sido eliminado con exito!');
            return $this->redirectToRoute('categories');
            
        } else {
            $this->addFlash('error','La categoria no ha podido ser eliminado!');
            return $this->redirectToRoute('categories');
        }

        return $this->render('registrocat/index.html.twig', [
            'controller_name' => 'Registro de Categorias',
            
        ]);
    }

    /**
     * @Route("/registrocat", name="registrocat")
     */
    public function store(Request $request)
    {
        $code        = $request->get('code');
        $name        = $request->get('name');
        $description = $request->get('description');
        $active      = $request->get('active');

        $category = new Categories();
        $category->setCode($code);
        $category->setName($name);
        $category->setDescription($description);
        $category->setActive($active);

        $em = $this->getDoctrine()->getManager();

        $em->persist($category);
        $result = $em->flush();

        $em = $this->getDoctrine()->getManager();
        $categories = $em->getRepository(Categories::class)->findAll();

        if ($result == null){
            
            $this->addFlash('exito','Se ha registrado la categoria con exito');
            return $this->render('categories/index.html.twig', [
                'controller_name' => 'Registro de Categorias',
                'categories'      => $categories
            ]);
        }else{
            
            $this->addFlash('error','ERROR: Se ha presentado un error al registrar la categoria');
            return $this->render('categories/index.html.twig', [
                'controller_name' => 'Registro de Categorias',
                'categories'      => $categories
            ]);
        }
    }
}
