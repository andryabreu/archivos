<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* registrocat/editarcat.html.twig */
class __TwigTemplate_eced8e95a72acc7f6eed9fb0602e0390df546beb363d8537d845fda2964a5069 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "registrocat/editarcat.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "registrocat/editarcat.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "registrocat/editarcat.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello RegistrocatController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>
";
        // line 10
        $this->loadTemplate("default/index.html.twig", "registrocat/editarcat.html.twig", 10)->display($context);
        // line 11
        echo "<div class=\"example-wrapper\">
    <h4>";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["editar"]) || array_key_exists("editar", $context) ? $context["editar"] : (function () { throw new RuntimeError('Variable "editar" does not exist.', 12, $this->source); })()), "html", null, true);
        echo "! ✅</h4>
    <br> 
    
    ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 15, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["valor"]) {
            // line 16
            echo "    <form name=\"editprod\" id=\"editprod\" method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("editarcat2", ["id" => twig_get_attribute($this->env, $this->source, $context["valor"], "id", [], "any", false, false, false, 16)]), "html", null, true);
            echo "\">

        <table class=\"table\">
            
            <tbody>
                <tr>
                    <td>
                    <div class=\"mb-3\">
                        <label for=\"code\" class=\"form-label\">Codigo</label>
                        <input value=\"";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "code", [], "any", false, false, false, 25), "html", null, true);
            echo "\" type=\"text\" class=\"form-control\" id=\"code\" name=\"code\" readonly>
                    </div>
                    </td>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Nombre</label>
                            <input value=\"";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "name", [], "any", false, false, false, 31), "html", null, true);
            echo "\" type=\"text\" class=\"form-control\" id=\"name\" name=\"name\" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Descripcion</label>
                            <input value=\"";
            // line 39
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "description", [], "any", false, false, false, 39), "html", null, true);
            echo "\" type=\"text\" class=\"form-control\" id=\"description\" name=\"description\" required>
                        </div>
                    </td>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Estatus</label>
                            <select name=\"active\" id=\"active\" class=\"form-select form-select-sm\" aria-label=\".form-select-sm example\" required>
                                <option selected disabled>Seleccione..</option>
                                <option value=\"activa\">Activa</option>
                                <option value=\"inactiva\">Inactiva</option>
                            </select>
                        </div>
                    </td>
                </tr>
               
                
            </tbody>
        </table>
        <button type=\"submit\" class=\"btn btn-primary mb-3\">Modificar Categoria</button>  
    </form>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['valor'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 59
        echo " 
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "registrocat/editarcat.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 59,  142 => 39,  131 => 31,  122 => 25,  109 => 16,  105 => 15,  99 => 12,  96 => 11,  94 => 10,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello RegistrocatController!{% endblock %}

{% block body %}
<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>
{% include \"default/index.html.twig\" %}
<div class=\"example-wrapper\">
    <h4>{{ editar }}! ✅</h4>
    <br> 
    
    {% for valor in category %}
    <form name=\"editprod\" id=\"editprod\" method=\"post\" action=\"{{ path('editarcat2',{id:valor.id}) }}\">

        <table class=\"table\">
            
            <tbody>
                <tr>
                    <td>
                    <div class=\"mb-3\">
                        <label for=\"code\" class=\"form-label\">Codigo</label>
                        <input value=\"{{ valor.code }}\" type=\"text\" class=\"form-control\" id=\"code\" name=\"code\" readonly>
                    </div>
                    </td>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Nombre</label>
                            <input value=\"{{ valor.name }}\" type=\"text\" class=\"form-control\" id=\"name\" name=\"name\" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Descripcion</label>
                            <input value=\"{{ valor.description }}\" type=\"text\" class=\"form-control\" id=\"description\" name=\"description\" required>
                        </div>
                    </td>
                    <td>
                        <div class=\"mb-3\">
                            <label for=\"code\" class=\"form-label\">Estatus</label>
                            <select name=\"active\" id=\"active\" class=\"form-select form-select-sm\" aria-label=\".form-select-sm example\" required>
                                <option selected disabled>Seleccione..</option>
                                <option value=\"activa\">Activa</option>
                                <option value=\"inactiva\">Inactiva</option>
                            </select>
                        </div>
                    </td>
                </tr>
               
                
            </tbody>
        </table>
        <button type=\"submit\" class=\"btn btn-primary mb-3\">Modificar Categoria</button>  
    </form>
    {% endfor %} 
</div>
{% endblock %}
", "registrocat/editarcat.html.twig", "/var/www/productos/templates/registrocat/editarcat.html.twig");
    }
}
