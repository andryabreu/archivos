<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @MopaBootstrap/base_initializr.html.twig */
class __TwigTemplate_81b2c25c0c02f687ff046a730dc67f7dd8d48aec395328eff62e1e0db231727c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'html_tag' => [$this, 'block_html_tag'],
            'head' => [$this, 'block_head'],
            'dns_prefetch' => [$this, 'block_dns_prefetch'],
            'title' => [$this, 'block_title'],
            'head_style' => [$this, 'block_head_style'],
            'head_script' => [$this, 'block_head_script'],
            'body_start' => [$this, 'block_body_start'],
            'body' => [$this, 'block_body'],
            'navbar' => [$this, 'block_navbar'],
            'container' => [$this, 'block_container'],
            'foot_script' => [$this, 'block_foot_script'],
            'jquery' => [$this, 'block_jquery'],
            'jquery_cdn_url' => [$this, 'block_jquery_cdn_url'],
            'jquery_local_url' => [$this, 'block_jquery_local_url'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "@MopaBootstrap/base_less.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/base_initializr.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/base_initializr.html.twig"));

        $this->parent = $this->loadTemplate("@MopaBootstrap/base_less.html.twig", "@MopaBootstrap/base_initializr.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_html_tag($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "html_tag"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "html_tag"));

        // line 4
        echo "<!--[if lt IE 7]>      <html class=\"no-js lt-ie9 lt-ie8 lt-ie7\"> <![endif]-->
<!--[if IE 7]>         <html class=\"no-js lt-ie9 lt-ie8\"> <![endif]-->
<!--[if IE 8]>         <html class=\"no-js lt-ie9\"> <![endif]-->
<!--[if gt IE 8]><!--> <html class=\"no-js\"> <!--<![endif]-->

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 14
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        // line 15
        echo "<head>
    <meta charset=\"utf-8\" />

    ";
        // line 20
        echo "    ";
        $this->displayBlock('dns_prefetch', $context, $blocks);
        // line 27
        echo "
    ";
        // line 33
        echo "    <!--[if IE]><meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" /><![endif]-->

    ";
        // line 37
        echo "    <meta name=\"viewport\" content=\"width=device-width\" />

    ";
        // line 39
        $context["meta_robots"] = "";
        // line 40
        echo "    ";
        $context["metatitle"] = "";
        // line 41
        echo "    ";
        if (array_key_exists("meta", $context)) {
            // line 42
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, ($context["meta"] ?? null), "description", [], "any", true, true, false, 42)) {
                // line 43
                echo "            <meta name=\"description\" content=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 43, $this->source); })()), "description", [], "array", false, false, false, 43), "html", null, true);
                echo "\" />
        ";
            }
            // line 45
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, ($context["meta"] ?? null), "keywords", [], "any", true, true, false, 45)) {
                // line 46
                echo "            <meta name=\"keywords\" content=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 46, $this->source); })()), "keywords", [], "array", false, false, false, 46), "html", null, true);
                echo "\" />
        ";
            }
            // line 48
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, ($context["meta"] ?? null), "author_name", [], "any", true, true, false, 48)) {
                // line 49
                echo "            <meta name=\"author\" content=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 49, $this->source); })()), "author_name", [], "array", false, false, false, 49), "html", null, true);
                echo "\" />
        ";
            }
            // line 51
            echo "        ";
            if ((twig_get_attribute($this->env, $this->source, ($context["meta"] ?? null), "author_url", [], "any", true, true, false, 51) && twig_get_attribute($this->env, $this->source, ($context["meta"] ?? null), "author_name", [], "any", true, true, false, 51))) {
                // line 52
                echo "            ";
                // line 53
                echo "            <link rel=\"author\" href=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 53, $this->source); })()), "author_url", [], "array", false, false, false, 53), "html", null, true);
                echo "\" title=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 53, $this->source); })()), "author_name", [], "array", false, false, false, 53), "html", null, true);
                echo "\" />
        ";
            }
            // line 55
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, ($context["meta"] ?? null), "title", [], "any", true, true, false, 55)) {
                // line 56
                echo "            ";
                $context["metatitle"] = twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 56, $this->source); })()), "title", [], "any", false, false, false, 56);
                // line 57
                echo "        ";
            }
            // line 58
            echo "
        ";
            // line 61
            echo "
        ";
            // line 65
            echo "
        ";
            // line 68
            echo "
        <link rel=\"shortcut icon\" href=\"";
            // line 69
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("favicon.ico"), "html", null, true);
            echo "\" />
        <link rel=\"apple-touch-icon\" href=\"";
            // line 70
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("apple-touch-icon.png"), "html", null, true);
            echo "\" />

        ";
            // line 73
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, ($context["meta"] ?? null), "sitemap", [], "array", true, true, false, 73)) {
                // line 74
                echo "        <link rel=\"sitemap\" type=\"application/xml\" title=\"Sitemap\" href=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 74, $this->source); })()), "sitemap", [], "array", false, false, false, 74), "html", null, true);
                echo "\" />
        ";
            }
            // line 76
            echo "
        ";
            // line 78
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, ($context["meta"] ?? null), "feed_atom", [], "array", true, true, false, 78)) {
                // line 79
                echo "        <link rel=\"alternate\" type=\"application/atom+xml\" title=\"Atom\" href=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 79, $this->source); })()), "feed_atom", [], "array", false, false, false, 79), "html", null, true);
                echo "\" />
        ";
            }
            // line 81
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, ($context["meta"] ?? null), "feed_rss", [], "array", true, true, false, 81)) {
                // line 82
                echo "        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"RSS\" href=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 82, $this->source); })()), "feed_rss", [], "array", false, false, false, 82), "html", null, true);
                echo "\" />
        ";
            }
            // line 84
            echo "
        ";
            // line 86
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 86, $this->source); })()), "noindex", [], "array", false, false, false, 86)) {
                // line 87
                echo "            ";
                $context["meta_robots"] = "noindex,";
                // line 88
                echo "        ";
            }
            // line 89
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, (isset($context["meta"]) || array_key_exists("meta", $context) ? $context["meta"] : (function () { throw new RuntimeError('Variable "meta" does not exist.', 89, $this->source); })()), "nofollow", [], "array", false, false, false, 89)) {
                // line 90
                echo "            ";
                $context["meta_robots"] = ((isset($context["meta_robots"]) || array_key_exists("meta_robots", $context) ? $context["meta_robots"] : (function () { throw new RuntimeError('Variable "meta_robots" does not exist.', 90, $this->source); })()) . "nofollow");
                // line 91
                echo "        ";
            } else {
                // line 92
                echo "            ";
                $context["meta_robots"] = ((isset($context["meta_robots"]) || array_key_exists("meta_robots", $context) ? $context["meta_robots"] : (function () { throw new RuntimeError('Variable "meta_robots" does not exist.', 92, $this->source); })()) . "follow");
                // line 93
                echo "        ";
            }
            // line 94
            echo "    ";
        }
        // line 95
        echo "
    <meta name=\"robots\" content=\"";
        // line 96
        echo twig_escape_filter($this->env, (isset($context["meta_robots"]) || array_key_exists("meta_robots", $context) ? $context["meta_robots"] : (function () { throw new RuntimeError('Variable "meta_robots" does not exist.', 96, $this->source); })()), "html", null, true);
        echo "\" />
    <title>";
        // line 97
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 99
        if (twig_get_attribute($this->env, $this->source, ($context["google"] ?? null), "wt", [], "array", true, true, false, 99)) {
            // line 100
            echo "        <meta name=\"google-site-verification\" content=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["google"]) || array_key_exists("google", $context) ? $context["google"] : (function () { throw new RuntimeError('Variable "google" does not exist.', 100, $this->source); })()), "wt", [], "array", false, false, false, 100), "html", null, true);
            echo "\" />
    ";
        }
        // line 102
        echo "
    ";
        // line 106
        echo "
    ";
        // line 108
        echo "    ";
        $this->displayBlock('head_style', $context, $blocks);
        // line 117
        echo "
    ";
        // line 118
        $this->displayBlock('head_script', $context, $blocks);
        // line 121
        echo "</head>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 20
    public function block_dns_prefetch($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "dns_prefetch"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "dns_prefetch"));

        // line 21
        echo "        ";
        if (array_key_exists("dns_prefetch", $context)) {
            // line 22
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["dns_prefetch"]) || array_key_exists("dns_prefetch", $context) ? $context["dns_prefetch"] : (function () { throw new RuntimeError('Variable "dns_prefetch" does not exist.', 22, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["domain"]) {
                // line 23
                echo "            <link rel=\"dns-prefetch\" href=\"";
                echo twig_escape_filter($this->env, $context["domain"], "html", null, true);
                echo "\" />
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['domain'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "        ";
        }
        // line 26
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 97
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, (isset($context["metatitle"]) || array_key_exists("metatitle", $context) ? $context["metatitle"] : (function () { throw new RuntimeError('Variable "metatitle" does not exist.', 97, $this->source); })()), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 108
    public function block_head_style($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head_style"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head_style"));

        // line 109
        echo "        ";
        $this->displayParentBlock("head_style", $context, $blocks);
        echo "

        ";
        // line 113
        echo "        ";
        if ((isset($context["diagnostic_mode"]) || array_key_exists("diagnostic_mode", $context) ? $context["diagnostic_mode"] : (function () { throw new RuntimeError('Variable "diagnostic_mode" does not exist.', 113, $this->source); })())) {
            // line 114
            echo "            <link href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/mopabootstrap/css/diagnostic.css"), "html", null, true);
            echo "\" type=\"text/css\" rel=\"stylesheet\" media=\"screen\" />
        ";
        }
        // line 116
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 118
    public function block_head_script($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head_script"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head_script"));

        // line 119
        echo "        <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/mopabootstrap/js/modernizr-2.7.1-respond-1.4.2.min.js"), "html", null, true);
        echo "\"></script>
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 124
    public function block_body_start($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body_start"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body_start"));

        // line 125
        echo "<!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href=\"http://browsehappy.com/\">Upgrade to a different browser</a> or <a href=\"http://www.google.com/chromeframe/?redirect=true\">install Google Chrome Frame</a> to experience this site.</p><![endif]-->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 128
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 129
        echo "    ";
        $this->displayBlock('navbar', $context, $blocks);
        // line 132
        echo "
    ";
        // line 133
        $this->displayBlock('container', $context, $blocks);
        // line 136
        echo "
    ";
        // line 137
        $this->displayBlock('foot_script', $context, $blocks);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 129
    public function block_navbar($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "navbar"));

        // line 130
        echo "    ";
        $this->displayParentBlock("navbar", $context, $blocks);
        echo "
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 133
    public function block_container($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "container"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "container"));

        // line 134
        echo "    ";
        $this->displayParentBlock("container", $context, $blocks);
        echo "
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 137
    public function block_foot_script($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "foot_script"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "foot_script"));

        // line 138
        echo "    ";
        $this->displayBlock('jquery', $context, $blocks);
        // line 144
        echo "    ";
        // line 146
        echo "    ";
        // line 148
        echo "    ";
        if (twig_get_attribute($this->env, $this->source, ($context["google"] ?? null), "analytics", [], "array", true, true, false, 148)) {
            // line 149
            echo "    <script>
        (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
        function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
        e=o.createElement(i);r=o.getElementsByTagName(i)[0];
        e.src='//www.google-analytics.com/analytics.js';
        r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
        ga('create','";
            // line 155
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["google"]) || array_key_exists("google", $context) ? $context["google"] : (function () { throw new RuntimeError('Variable "google" does not exist.', 155, $this->source); })()), "analytics", [], "array", false, false, false, 155), "html", null, true);
            echo "');ga('send','pageview');
\t";
            // line 156
            if (twig_get_attribute($this->env, $this->source, (isset($context["google"]) || array_key_exists("google", $context) ? $context["google"] : (function () { throw new RuntimeError('Variable "google" does not exist.', 156, $this->source); })()), "extendedanalytics", [], "array", false, false, false, 156)) {
                // line 157
                echo "\t\tga('require', 'displayfeatures');
\t";
            }
            // line 159
            echo "    </script>
    ";
        }
        // line 161
        echo "    ";
        $this->displayParentBlock("foot_script", $context, $blocks);
        echo "
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 138
    public function block_jquery($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jquery"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jquery"));

        // line 139
        echo "      ";
        // line 141
        echo "      <script src=\"";
        $this->displayBlock('jquery_cdn_url', $context, $blocks);
        echo "\"></script>
      <script>window.jQuery || document.write('<script src=\"";
        // line 142
        $this->displayBlock('jquery_local_url', $context, $blocks);
        echo "\"><\\/script>')</script>
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 141
    public function block_jquery_cdn_url($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jquery_cdn_url"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jquery_cdn_url"));

        echo "//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 142
    public function block_jquery_local_url($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jquery_local_url"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "jquery_local_url"));

        echo "../js/libs/jquery-1.11.0.min.js";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@MopaBootstrap/base_initializr.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  626 => 142,  607 => 141,  595 => 142,  590 => 141,  588 => 139,  578 => 138,  565 => 161,  561 => 159,  557 => 157,  555 => 156,  551 => 155,  543 => 149,  540 => 148,  538 => 146,  536 => 144,  533 => 138,  523 => 137,  510 => 134,  500 => 133,  487 => 130,  477 => 129,  467 => 137,  464 => 136,  462 => 133,  459 => 132,  456 => 129,  446 => 128,  435 => 125,  425 => 124,  412 => 119,  402 => 118,  392 => 116,  386 => 114,  383 => 113,  377 => 109,  367 => 108,  348 => 97,  338 => 26,  335 => 25,  326 => 23,  321 => 22,  318 => 21,  308 => 20,  297 => 121,  295 => 118,  292 => 117,  289 => 108,  286 => 106,  283 => 102,  277 => 100,  275 => 99,  270 => 97,  266 => 96,  263 => 95,  260 => 94,  257 => 93,  254 => 92,  251 => 91,  248 => 90,  245 => 89,  242 => 88,  239 => 87,  236 => 86,  233 => 84,  227 => 82,  224 => 81,  218 => 79,  215 => 78,  212 => 76,  206 => 74,  203 => 73,  198 => 70,  194 => 69,  191 => 68,  188 => 65,  185 => 61,  182 => 58,  179 => 57,  176 => 56,  173 => 55,  165 => 53,  163 => 52,  160 => 51,  154 => 49,  151 => 48,  145 => 46,  142 => 45,  136 => 43,  133 => 42,  130 => 41,  127 => 40,  125 => 39,  121 => 37,  117 => 33,  114 => 27,  111 => 20,  106 => 15,  96 => 14,  81 => 4,  71 => 3,  48 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '@MopaBootstrap/base_less.html.twig' %}

{% block html_tag %}
<!--[if lt IE 7]>      <html class=\"no-js lt-ie9 lt-ie8 lt-ie7\"> <![endif]-->
<!--[if IE 7]>         <html class=\"no-js lt-ie9 lt-ie8\"> <![endif]-->
<!--[if IE 8]>         <html class=\"no-js lt-ie9\"> <![endif]-->
<!--[if gt IE 8]><!--> <html class=\"no-js\"> <!--<![endif]-->

{# make your site working offline with Application Cache (AppCache)
   http://www.html5rocks.com/en/tutorials/appcache/beginner/
<html manifest=\"manifest.appcache\"> #}
{% endblock html_tag %}

{% block head %}
<head>
    <meta charset=\"utf-8\" />

    {# About DNS prefetching: http://html5boilerplate.com/docs/DNS-Prefetching/
       If you fetch data from other domains, add them too #}
    {% block dns_prefetch %}
        {% if dns_prefetch is defined %}
            {% for domain in dns_prefetch %}
            <link rel=\"dns-prefetch\" href=\"{{ domain }}\" />
            {% endfor %}
        {% endif %}
    {% endblock dns_prefetch %}

    {# IE10 does not support plugins, such as Flash, in Metro Mode.
       If your site requires plugins, you can let users know that via the
       X-UA-Compatible meta element, which will prompt them to switch to Desktop Mode.
       http://html5boilerplate.com/docs/html-head/#prompt-users-to-switch-to-desktop-mode-in-ie10-metro
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1,requiresActiveX=true\"> #}
    <!--[if IE]><meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" /><![endif]-->

    {# WARNING: do not add \"initial-scale=1\" to viewport, breaks iOS view!
       https://github.com/h5bp/html5-boilerplate/issues/824 #}
    <meta name=\"viewport\" content=\"width=device-width\" />

    {% set meta_robots = '' %}
    {% set metatitle = '' %}
    {% if meta is defined %}
        {% if meta.description is defined %}
            <meta name=\"description\" content=\"{{ meta['description'] }}\" />
        {% endif %}
        {% if meta.keywords is defined %}
            <meta name=\"keywords\" content=\"{{ meta['keywords'] }}\" />
        {% endif %}
        {% if meta.author_name is defined %}
            <meta name=\"author\" content=\"{{ meta['author_name'] }}\" />
        {% endif %}
        {% if meta.author_url is defined and meta.author_name is defined %}
            {# example: href=\"/humans.txt\" #}
            <link rel=\"author\" href=\"{{ meta['author_url'] }}\" title=\"{{ meta['author_name'] }}\" />
        {% endif %}
        {% if meta.title is defined %}
            {% set metatitle = meta.title %}
        {% endif %}

        {# to be removed as HTML5 has no such tag
        <meta name=\"title\" content=\"{{ meta_title|default('') }}\"> #}

        {# read more about canonical urls and then decide whether enable this part or remove
           http://html5boilerplate.com/docs/html-head/#canonical-url
        <link rel=\"canonical\" href=\"\"> #}

        {# Official short link, poorly supported now
        <link rel=\"shortlink\" href=\"h5bp.com\"> #}

        <link rel=\"shortcut icon\" href=\"{{ asset('favicon.ico') }}\" />
        <link rel=\"apple-touch-icon\" href=\"{{ asset('apple-touch-icon.png') }}\" />

        {# allow BOTs see SITEMAP #}
        {% if meta['sitemap'] is defined %}
        <link rel=\"sitemap\" type=\"application/xml\" title=\"Sitemap\" href=\"{{ meta['sitemap'] }}\" />
        {% endif %}

        {# Feeds RSS & ATOM #}
        {% if meta['feed_atom'] is defined %}
        <link rel=\"alternate\" type=\"application/atom+xml\" title=\"Atom\" href=\"{{ meta['feed_atom'] }}\" />
        {% endif %}
        {% if meta['feed_rss'] is defined %}
        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"RSS\" href=\"{{ meta['feed_rss'] }}\" />
        {% endif %}

        {# this should be allowed to be changed from controller scope #}
        {% if meta['noindex'] %}
            {% set meta_robots = 'noindex,' %}
        {% endif %}
        {% if meta['nofollow'] %}
            {% set meta_robots = meta_robots ~ 'nofollow' %}
        {% else %}
            {% set meta_robots = meta_robots ~ 'follow' %}
        {% endif %}
    {% endif %}

    <meta name=\"robots\" content=\"{{ meta_robots }}\" />
    <title>{% block title%}{{ metatitle }}{% endblock %}</title>

    {% if google['wt'] is defined %}
        <meta name=\"google-site-verification\" content=\"{{ google['wt'] }}\" />
    {% endif %}

    {# Site Search Browser plugin:
       http://www.google.com/search?ie=UTF-8&q=how+to+make+browser+search+plugin
    <link rel=\"search\" title=\"\" type=\"application/opensearchdescription+xml\" href=\"\"> #}

    {# Override this block to add your own files! #}
    {% block head_style %}
        {{ parent() }}

        {# Find places where your CSS is broken, docs how to use:
           http://meyerweb.com/eric/tools/css/diagnostics/' #}
        {% if diagnostic_mode %}
            <link href=\"{{ asset('bundles/mopabootstrap/css/diagnostic.css') }}\" type=\"text/css\" rel=\"stylesheet\" media=\"screen\" />
        {% endif %}
    {% endblock head_style %}

    {% block head_script %}
        <script type=\"text/javascript\" src=\"{{ asset('bundles/mopabootstrap/js/modernizr-2.7.1-respond-1.4.2.min.js') }}\"></script>
    {% endblock head_script %}
</head>
{% endblock head %}

{% block body_start %}
<!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href=\"http://browsehappy.com/\">Upgrade to a different browser</a> or <a href=\"http://www.google.com/chromeframe/?redirect=true\">install Google Chrome Frame</a> to experience this site.</p><![endif]-->
{% endblock body_start %}

{% block body %}
    {% block navbar %}
    {{ parent() }}
    {% endblock navbar %}

    {% block container %}
    {{ parent() }}
    {% endblock container %}

    {% block foot_script %}
    {% block jquery %}
      {# Load jQuery from Google CDN
       http://encosia.com/3-reasons-why-you-should-let-google-host-jquery-for-you/ #}
      <script src=\"{% block jquery_cdn_url %}//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js{% endblock jquery_cdn_url %}\"></script>
      <script>window.jQuery || document.write('<script src=\"{% block jquery_local_url %}../js/libs/jquery-1.11.0.min.js{% endblock jquery_local_url %}\"><\\/script>')</script>
    {% endblock jquery %}
    {# Asynchronous Google Analytics snippet grabbed from:
       http://mathiasbynens.be/notes/async-analytics-snippet#dont-push-it #}
    {# more GA tweaks:
       http://html5boilerplate.com/docs/ga-augments/ #}
    {% if google['analytics'] is defined %}
    <script>
        (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
        function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
        e=o.createElement(i);r=o.getElementsByTagName(i)[0];
        e.src='//www.google-analytics.com/analytics.js';
        r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
        ga('create','{{ google['analytics'] }}');ga('send','pageview');
\t{% if google['extendedanalytics'] %}
\t\tga('require', 'displayfeatures');
\t{% endif %}
    </script>
    {% endif %}
    {{ parent() }}
    {% endblock foot_script %}
{% endblock body %}
", "@MopaBootstrap/base_initializr.html.twig", "/var/www/productos/vendor/mopa/bootstrap-bundle/Resources/views/base_initializr.html.twig");
    }
}
