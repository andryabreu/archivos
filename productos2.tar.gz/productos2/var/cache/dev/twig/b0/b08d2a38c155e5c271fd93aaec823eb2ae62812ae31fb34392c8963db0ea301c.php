<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* categories/index.html.twig */
class __TwigTemplate_24ee8de15d8a8728e9ac9e580f48049f95c119f25d06e7de7b1d299f786d74fd extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "categories/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "categories/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "categories/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Categorias";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

";
        // line 11
        $this->loadTemplate("default/index.html.twig", "categories/index.html.twig", 11)->display($context);
        // line 12
        echo "
<div class=\"example-wrapper\">
    <h4>";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["controller_name"]) || array_key_exists("controller_name", $context) ? $context["controller_name"] : (function () { throw new RuntimeError('Variable "controller_name" does not exist.', 14, $this->source); })()), "html", null, true);
        echo "! ✅</h4>

    ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "flashes", [0 => "exito"], "method", false, false, false, 16));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 17
            echo "        <div class=\"alert alert-success\">
            ";
            // line 18
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
        <i class=\"bi bi-check\"></i>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "    
    ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 23, $this->source); })()), "flashes", [0 => "error"], "method", false, false, false, 23));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 24
            echo "        <div class=\"alert alert-error\">
            ";
            // line 25
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
        <i class=\"bi bi-x-circle\"></i>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "
    <br>
    <div><a href=\"";
        // line 31
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("agregarcat");
        echo "\" title=\"Agregar Categorias\">Agregar Categorias&nbsp;<i class=\"bi bi-plus-circle\"></i></a></div>
    <br><br>
    <br>
    <table id=\"table_id\" class=\"display example-wrapper\">
        <thead>
            <tr>
                <th>ID</th>
                <th>Codigo</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Estatus</th>
                <th>Accion</th>
            </tr>
        </thead>
        <tbody>
            ";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) || array_key_exists("categories", $context) ? $context["categories"] : (function () { throw new RuntimeError('Variable "categories" does not exist.', 46, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["valor"]) {
            // line 47
            echo "            <tr>
                <td> ";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "id", [], "any", false, false, false, 48), "html", null, true);
            echo " </td>
                <td> ";
            // line 49
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "code", [], "any", false, false, false, 49), "html", null, true);
            echo " </td>
                <td> ";
            // line 50
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "name", [], "any", false, false, false, 50), "html", null, true);
            echo " </td>
                <td> ";
            // line 51
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "description", [], "any", false, false, false, 51), "html", null, true);
            echo " </td>
                <td> ";
            // line 52
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["valor"], "active", [], "any", false, false, false, 52), "html", null, true);
            echo " </td>
                <td> <a class=\"editar\" href=\"";
            // line 53
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("editarcat", ["id" => twig_get_attribute($this->env, $this->source, $context["valor"], "id", [], "any", false, false, false, 53)]), "html", null, true);
            echo "\" title=\"Editar Categoria\"><i class=\"alert-info bi bi-pencil\"></i></a>&nbsp;&nbsp;&nbsp;
                <a class=\"eliminar\" href=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("eliminarcat", ["id" => twig_get_attribute($this->env, $this->source, $context["valor"], "id", [], "any", false, false, false, 54)]), "html", null, true);
            echo "\" title=\"Eliminar Categoria\"><i class=\"alert-danger bi bi-x-octagon\"></a></i></td>
            </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['valor'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "        </tbody>
    </table>
    
</div>
<script type=\"text/javascript\">
    \$(document).ready( function () {
        \$('#table_id').DataTable();

        \$(\".editar\", function(e){
            //alert('hola');
            e.preventDefault(); // Evito que la pagina se recargue.
            
            // como this es el link, tengo acceso al atributo href directamente
            \$.get(this.href).done(function(response){ 
                //alert('hola');
            });
        });

    } );
</script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "categories/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 57,  196 => 54,  192 => 53,  188 => 52,  184 => 51,  180 => 50,  176 => 49,  172 => 48,  169 => 47,  165 => 46,  147 => 31,  143 => 29,  133 => 25,  130 => 24,  126 => 23,  123 => 22,  113 => 18,  110 => 17,  106 => 16,  101 => 14,  97 => 12,  95 => 11,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Categorias{% endblock %}

{% block body %}
<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

{% include \"default/index.html.twig\" %}

<div class=\"example-wrapper\">
    <h4>{{ controller_name }}! ✅</h4>

    {% for message in app.flashes('exito') %}
        <div class=\"alert alert-success\">
            {{ message }}
        <i class=\"bi bi-check\"></i>
        </div>
    {% endfor %}
    
    {% for message in app.flashes('error') %}
        <div class=\"alert alert-error\">
            {{ message }}
        <i class=\"bi bi-x-circle\"></i>
        </div>
    {% endfor %}

    <br>
    <div><a href=\"{{ path('agregarcat') }}\" title=\"Agregar Categorias\">Agregar Categorias&nbsp;<i class=\"bi bi-plus-circle\"></i></a></div>
    <br><br>
    <br>
    <table id=\"table_id\" class=\"display example-wrapper\">
        <thead>
            <tr>
                <th>ID</th>
                <th>Codigo</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Estatus</th>
                <th>Accion</th>
            </tr>
        </thead>
        <tbody>
            {% for valor in categories %}
            <tr>
                <td> {{ valor.id }} </td>
                <td> {{ valor.code }} </td>
                <td> {{ valor.name }} </td>
                <td> {{ valor.description }} </td>
                <td> {{ valor.active }} </td>
                <td> <a class=\"editar\" href=\"{{ path(\"editarcat\",{id:valor.id}) }}\" title=\"Editar Categoria\"><i class=\"alert-info bi bi-pencil\"></i></a>&nbsp;&nbsp;&nbsp;
                <a class=\"eliminar\" href=\"{{ path(\"eliminarcat\",{id:valor.id}) }}\" title=\"Eliminar Categoria\"><i class=\"alert-danger bi bi-x-octagon\"></a></i></td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
    
</div>
<script type=\"text/javascript\">
    \$(document).ready( function () {
        \$('#table_id').DataTable();

        \$(\".editar\", function(e){
            //alert('hola');
            e.preventDefault(); // Evito que la pagina se recargue.
            
            // como this es el link, tengo acceso al atributo href directamente
            \$.get(this.href).done(function(response){ 
                //alert('hola');
            });
        });

    } );
</script>
{% endblock %}
", "categories/index.html.twig", "/var/www/productos/templates/categories/index.html.twig");
    }
}
