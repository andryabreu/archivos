<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @MopaBootstrap/Pagination/sliding.html.twig */
class __TwigTemplate_ce621edbf36056f9e6c045c9f9e6b578f5cc315b141eefd514a295702820f208 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/Pagination/sliding.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/Pagination/sliding.html.twig"));

        // line 1
        if ((1 === twig_compare((isset($context["pageCount"]) || array_key_exists("pageCount", $context) ? $context["pageCount"] : (function () { throw new RuntimeError('Variable "pageCount" does not exist.', 1, $this->source); })()), 1))) {
            // line 2
            echo "    ";
            $context["item"] = "@MopaBootstrap/Pagination/sliding_item.html.twig";
            // line 3
            echo "
    <ul class=\"";
            // line 4
            echo twig_escape_filter($this->env, ((array_key_exists("pagination_class", $context)) ? (_twig_default_filter((isset($context["pagination_class"]) || array_key_exists("pagination_class", $context) ? $context["pagination_class"] : (function () { throw new RuntimeError('Variable "pagination_class" does not exist.', 4, $this->source); })()), "pagination")) : ("pagination")), "html", null, true);
            echo "\">
        ";
            // line 5
            $this->loadTemplate((isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 5, $this->source); })()), "@MopaBootstrap/Pagination/sliding.html.twig", 5)->display(twig_array_merge($context, ["name" => "first", "text" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((            // line 6
array_key_exists("first_text", $context)) ? (_twig_default_filter((isset($context["first_text"]) || array_key_exists("first_text", $context) ? $context["first_text"] : (function () { throw new RuntimeError('Variable "first_text" does not exist.', 6, $this->source); })()), "«")) : ("«")), [], "pagination"), "page" => ((            // line 7
array_key_exists("first", $context)) ? ((isset($context["first"]) || array_key_exists("first", $context) ? $context["first"] : (function () { throw new RuntimeError('Variable "first" does not exist.', 7, $this->source); })())) : (null)), "clickable" => (            // line 8
array_key_exists("first", $context) && (0 !== twig_compare((isset($context["current"]) || array_key_exists("current", $context) ? $context["current"] : (function () { throw new RuntimeError('Variable "current" does not exist.', 8, $this->source); })()), (isset($context["first"]) || array_key_exists("first", $context) ? $context["first"] : (function () { throw new RuntimeError('Variable "first" does not exist.', 8, $this->source); })()))))]));
            // line 11
            echo "
        ";
            // line 12
            $this->loadTemplate((isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 12, $this->source); })()), "@MopaBootstrap/Pagination/sliding.html.twig", 12)->display(twig_array_merge($context, ["name" => "prev", "text" => ("‹ " . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((            // line 13
array_key_exists("prev_text", $context)) ? (_twig_default_filter((isset($context["prev_text"]) || array_key_exists("prev_text", $context) ? $context["prev_text"] : (function () { throw new RuntimeError('Variable "prev_text" does not exist.', 13, $this->source); })()), "Previous")) : ("Previous")), [], "pagination")), "page" => ((            // line 14
array_key_exists("previous", $context)) ? ((isset($context["previous"]) || array_key_exists("previous", $context) ? $context["previous"] : (function () { throw new RuntimeError('Variable "previous" does not exist.', 14, $this->source); })())) : (null)), "clickable" =>             // line 15
array_key_exists("previous", $context)]));
            // line 18
            echo "
        ";
            // line 19
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["pagesInRange"]) || array_key_exists("pagesInRange", $context) ? $context["pagesInRange"] : (function () { throw new RuntimeError('Variable "pagesInRange" does not exist.', 19, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["page"]) {
                // line 20
                echo "            ";
                $this->loadTemplate((isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 20, $this->source); })()), "@MopaBootstrap/Pagination/sliding.html.twig", 20)->display($context);
                // line 21
                echo "        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['page'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 22
            echo "
        ";
            // line 24
            $this->loadTemplate((isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 24, $this->source); })()), "@MopaBootstrap/Pagination/sliding.html.twig", 24)->display(twig_array_merge($context, ["name" => "next", "text" => ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((            // line 26
array_key_exists("next_text", $context)) ? (_twig_default_filter((isset($context["next_text"]) || array_key_exists("next_text", $context) ? $context["next_text"] : (function () { throw new RuntimeError('Variable "next_text" does not exist.', 26, $this->source); })()), "Next")) : ("Next")), [], "pagination") . " ›"), "page" => ((            // line 27
array_key_exists("next", $context)) ? ((isset($context["next"]) || array_key_exists("next", $context) ? $context["next"] : (function () { throw new RuntimeError('Variable "next" does not exist.', 27, $this->source); })())) : (null)), "clickable" =>             // line 28
array_key_exists("next", $context)]));
            // line 31
            echo "
        ";
            // line 33
            $this->loadTemplate((isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 33, $this->source); })()), "@MopaBootstrap/Pagination/sliding.html.twig", 33)->display(twig_array_merge($context, ["name" => "last", "text" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((            // line 35
array_key_exists("last_text", $context)) ? (_twig_default_filter((isset($context["last_text"]) || array_key_exists("last_text", $context) ? $context["last_text"] : (function () { throw new RuntimeError('Variable "last_text" does not exist.', 35, $this->source); })()), "»")) : ("»")), [], "pagination"), "page" => ((            // line 36
array_key_exists("last", $context)) ? ((isset($context["last"]) || array_key_exists("last", $context) ? $context["last"] : (function () { throw new RuntimeError('Variable "last" does not exist.', 36, $this->source); })())) : (null)), "clickable" => (            // line 37
array_key_exists("last", $context) && (0 !== twig_compare((isset($context["current"]) || array_key_exists("current", $context) ? $context["current"] : (function () { throw new RuntimeError('Variable "current" does not exist.', 37, $this->source); })()), (isset($context["last"]) || array_key_exists("last", $context) ? $context["last"] : (function () { throw new RuntimeError('Variable "last" does not exist.', 37, $this->source); })()))))]));
            // line 40
            echo "    </ul>
";
        }
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "@MopaBootstrap/Pagination/sliding.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 40,  119 => 37,  118 => 36,  117 => 35,  116 => 33,  113 => 31,  111 => 28,  110 => 27,  109 => 26,  108 => 24,  105 => 22,  91 => 21,  88 => 20,  71 => 19,  68 => 18,  66 => 15,  65 => 14,  64 => 13,  63 => 12,  60 => 11,  58 => 8,  57 => 7,  56 => 6,  55 => 5,  51 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if pageCount > 1 %}
    {% set item = '@MopaBootstrap/Pagination/sliding_item.html.twig' %}

    <ul class=\"{{ pagination_class|default('pagination') }}\">
        {% include item with {name: 'first',
                text: first_text|default('«') | trans({}, 'pagination'),
                page: first is defined ? first : null,
                clickable: first is defined and current != first
            }
        %}

        {% include item with {name: 'prev',
                text: '‹ ' ~ prev_text|default('Previous') | trans({}, 'pagination'),
                page: previous is defined ? previous : null,
                clickable: previous is defined
            }
        %}

        {% for page in pagesInRange %}
            {% include item %}
        {% endfor %}

        {%
            include item with {
                name: 'next',
                text: next_text|default('Next') | trans({}, 'pagination') ~ ' ›',
                page: next is defined ? next : null,
                clickable: next is defined
            }
        %}

        {%
            include item with {
                name: 'last',
                text: last_text|default('»') | trans({}, 'pagination'),
                page: last is defined ? last : null,
                clickable: last is defined and current != last
            }
        %}
    </ul>
{% endif %}
", "@MopaBootstrap/Pagination/sliding.html.twig", "/var/www/productos/vendor/mopa/bootstrap-bundle/Resources/views/Pagination/sliding.html.twig");
    }
}
