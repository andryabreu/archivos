<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @MopaBootstrap/Form/fields.html.twig */
class __TwigTemplate_b74be552df139e3972398273f1de2f5f52a90aafd4d70863a5c713508c3e240b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        // line 1
        $_trait_0 = $this->loadTemplate("form_div_layout.html.twig", "@MopaBootstrap/Form/fields.html.twig", 1);
        if (!$_trait_0->isTraitable()) {
            throw new RuntimeError('Template "'."form_div_layout.html.twig".'" cannot be used as a trait.', 1, $this->source);
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            [
                'button_attributes' => [$this, 'block_button_attributes'],
                'button_widget' => [$this, 'block_button_widget'],
                'button_row' => [$this, 'block_button_row'],
                'textarea_widget' => [$this, 'block_textarea_widget'],
                'form_widget_simple' => [$this, 'block_form_widget_simple'],
                'form_widget_compound' => [$this, 'block_form_widget_compound'],
                'form_tabs' => [$this, 'block_form_tabs'],
                'tabs_widget' => [$this, 'block_tabs_widget'],
                'form_tab' => [$this, 'block_form_tab'],
                'collection_widget' => [$this, 'block_collection_widget'],
                'choice_widget_collapsed' => [$this, 'block_choice_widget_collapsed'],
                'choice_widget_expanded' => [$this, 'block_choice_widget_expanded'],
                'checkbox_widget' => [$this, 'block_checkbox_widget'],
                'date_widget' => [$this, 'block_date_widget'],
                'time_widget' => [$this, 'block_time_widget'],
                'datetime_widget' => [$this, 'block_datetime_widget'],
                'percent_widget' => [$this, 'block_percent_widget'],
                'money_widget' => [$this, 'block_money_widget'],
                'file_widget' => [$this, 'block_file_widget'],
                'form_legend' => [$this, 'block_form_legend'],
                'form_label' => [$this, 'block_form_label'],
                'help_label' => [$this, 'block_help_label'],
                'help_label_tooltip' => [$this, 'block_help_label_tooltip'],
                'help_block_tooltip' => [$this, 'block_help_block_tooltip'],
                'help_label_popover' => [$this, 'block_help_label_popover'],
                'help_block_popover' => [$this, 'block_help_block_popover'],
                'form_actions_widget' => [$this, 'block_form_actions_widget'],
                'form_actions_row' => [$this, 'block_form_actions_row'],
                'form_rows_visible' => [$this, 'block_form_rows_visible'],
                'form_row' => [$this, 'block_form_row'],
                'form_message' => [$this, 'block_form_message'],
                'form_help' => [$this, 'block_form_help'],
                'form_widget_add_btn' => [$this, 'block_form_widget_add_btn'],
                'form_widget_remove_btn' => [$this, 'block_form_widget_remove_btn'],
                'collection_button' => [$this, 'block_collection_button'],
                'label_asterisk' => [$this, 'block_label_asterisk'],
                'widget_addon' => [$this, 'block_widget_addon'],
                'widget_btns' => [$this, 'block_widget_btns'],
                'form_errors' => [$this, 'block_form_errors'],
                'error_type' => [$this, 'block_error_type'],
                'widget_form_group_start' => [$this, 'block_widget_form_group_start'],
                'help_widget_popover' => [$this, 'block_help_widget_popover'],
                'widget_form_group_end' => [$this, 'block_widget_form_group_end'],
            ]
        );
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/Form/fields.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/Form/fields.html.twig"));

        // line 2
        echo "
";
        // line 4
        $this->displayBlock('button_attributes', $context, $blocks);
        // line 8
        echo "
";
        // line 9
        $this->displayBlock('button_widget', $context, $blocks);
        // line 28
        echo "
";
        // line 29
        $this->displayBlock('button_row', $context, $blocks);
        // line 45
        echo "
";
        // line 47
        $this->displayBlock('textarea_widget', $context, $blocks);
        // line 66
        echo "
";
        // line 67
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 103
        echo "
";
        // line 104
        $this->displayBlock('form_widget_compound', $context, $blocks);
        // line 129
        echo "
";
        // line 130
        $this->displayBlock('form_tabs', $context, $blocks);
        // line 135
        echo "
";
        // line 136
        $this->displayBlock('tabs_widget', $context, $blocks);
        // line 155
        echo "
";
        // line 156
        $this->displayBlock('form_tab', $context, $blocks);
        // line 162
        echo "
";
        // line 163
        $this->displayBlock('collection_widget', $context, $blocks);
        // line 193
        echo "
";
        // line 194
        $this->displayBlock('choice_widget_collapsed', $context, $blocks);
        // line 202
        echo "
";
        // line 203
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 255
        echo "
";
        // line 256
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 304
        echo "
";
        // line 305
        $this->displayBlock('date_widget', $context, $blocks);
        // line 337
        echo "
";
        // line 338
        $this->displayBlock('time_widget', $context, $blocks);
        // line 372
        echo "
";
        // line 373
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 404
        echo "
";
        // line 405
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 411
        echo "
";
        // line 412
        $this->displayBlock('money_widget', $context, $blocks);
        // line 418
        echo "
";
        // line 419
        $this->displayBlock('file_widget', $context, $blocks);
        // line 435
        echo "
";
        // line 437
        echo "
";
        // line 438
        $this->displayBlock('form_legend', $context, $blocks);
        // line 453
        echo "
";
        // line 454
        $this->displayBlock('form_label', $context, $blocks);
        // line 502
        echo "
";
        // line 503
        $this->displayBlock('help_label', $context, $blocks);
        // line 506
        echo "
";
        // line 507
        $this->displayBlock('help_label_tooltip', $context, $blocks);
        // line 519
        echo "
";
        // line 520
        $this->displayBlock('help_block_tooltip', $context, $blocks);
        // line 524
        echo "
";
        // line 525
        $this->displayBlock('help_label_popover', $context, $blocks);
        // line 537
        echo "
";
        // line 538
        $this->displayBlock('help_block_popover', $context, $blocks);
        // line 542
        echo "
";
        // line 543
        $this->displayBlock('form_actions_widget', $context, $blocks);
        // line 548
        echo "
";
        // line 550
        $this->displayBlock('form_actions_row', $context, $blocks);
        // line 553
        echo "
";
        // line 554
        $this->displayBlock('form_rows_visible', $context, $blocks);
        // line 568
        echo "
";
        // line 569
        $this->displayBlock('form_row', $context, $blocks);
        // line 604
        echo "
";
        // line 606
        echo "
";
        // line 607
        $this->displayBlock('form_message', $context, $blocks);
        // line 616
        echo "
";
        // line 618
        echo "
";
        // line 619
        $this->displayBlock('form_help', $context, $blocks);
        // line 630
        echo "
";
        // line 631
        $this->displayBlock('form_widget_add_btn', $context, $blocks);
        // line 640
        echo "
";
        // line 641
        $this->displayBlock('form_widget_remove_btn', $context, $blocks);
        // line 662
        echo "
";
        // line 663
        $this->displayBlock('collection_button', $context, $blocks);
        // line 674
        echo "
";
        // line 675
        $this->displayBlock('label_asterisk', $context, $blocks);
        // line 682
        echo "
";
        // line 683
        $this->displayBlock('widget_addon', $context, $blocks);
        // line 690
        echo "
";
        // line 691
        $this->displayBlock('widget_btns', $context, $blocks);
        // line 704
        echo "
";
        // line 706
        echo "
";
        // line 707
        $this->displayBlock('form_errors', $context, $blocks);
        // line 733
        echo "
";
        // line 735
        echo "
";
        // line 736
        $this->displayBlock('error_type', $context, $blocks);
        // line 747
        echo "
";
        // line 749
        echo "
";
        // line 750
        $this->displayBlock('widget_form_group_start', $context, $blocks);
        // line 787
        echo "
";
        // line 788
        $this->displayBlock('help_widget_popover', $context, $blocks);
        // line 795
        echo "
";
        // line 796
        $this->displayBlock('widget_form_group_end', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_button_attributes($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button_attributes"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button_attributes"));

        // line 5
        echo "    ";
        $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 5, $this->source); })()), ["class" => ("btn " . ((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 5)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 5), "btn-default")) : ("btn-default")))]);
        // line 6
        echo "    ";
        $this->displayParentBlock("button_attributes", $context, $blocks);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_button_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button_widget"));

        // line 10
        ob_start();
        // line 11
        echo "    ";
        if (twig_test_empty((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 11, $this->source); })()))) {
            // line 12
            if ((array_key_exists("label_format", $context) &&  !twig_test_empty((isset($context["label_format"]) || array_key_exists("label_format", $context) ? $context["label_format"] : (function () { throw new RuntimeError('Variable "label_format" does not exist.', 12, $this->source); })())))) {
                // line 13
                $context["label"] = twig_replace_filter((isset($context["label_format"]) || array_key_exists("label_format", $context) ? $context["label_format"] : (function () { throw new RuntimeError('Variable "label_format" does not exist.', 13, $this->source); })()), ["%name%" =>                 // line 14
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 14, $this->source); })()), "%id%" =>                 // line 15
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 15, $this->source); })())]);
            } else {
                // line 18
                $context["label"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 18, $this->source); })()));
            }
        }
        // line 21
        echo "    <button type=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 21, $this->source); })()), "button")) : ("button")), "html", null, true);
        echo "\" ";
        $this->displayBlock("button_attributes", $context, $blocks);
        echo ">
    ";
        // line 22
        if ( !twig_test_empty((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 22, $this->source); })()))) {
            // line 23
            echo "            ";
            echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, (isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 23, $this->source); })()), ((array_key_exists("icon_inverted", $context)) ? (_twig_default_filter((isset($context["icon_inverted"]) || array_key_exists("icon_inverted", $context) ? $context["icon_inverted"] : (function () { throw new RuntimeError('Variable "icon_inverted" does not exist.', 23, $this->source); })()), false)) : (false)));
            echo "
    ";
        }
        // line 25
        echo "    ";
        echo twig_escape_filter($this->env, ((((isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 25, $this->source); })()) === false)) ? ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 25, $this->source); })())) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 25, $this->source); })()), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 25, $this->source); })())))), "html", null, true);
        echo "</button>
";
        $___internal_36a4b3fdab121fbdff97bfc0a3665a5bb05bb7b2f2a2b4ea310e40357d070d16_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 10
        echo twig_spaceless($___internal_36a4b3fdab121fbdff97bfc0a3665a5bb05bb7b2f2a2b4ea310e40357d070d16_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 29
    public function block_button_row($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button_row"));

        // line 30
        echo "    ";
        ob_start();
        // line 31
        echo "        ";
        if ((array_key_exists("button_offset", $context) &&  !twig_test_empty((isset($context["button_offset"]) || array_key_exists("button_offset", $context) ? $context["button_offset"] : (function () { throw new RuntimeError('Variable "button_offset" does not exist.', 31, $this->source); })())))) {
            // line 32
            echo "            ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 32, $this->source); })()), ["for" => (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 32, $this->source); })()), "class" => (isset($context["button_offset"]) || array_key_exists("button_offset", $context) ? $context["button_offset"] : (function () { throw new RuntimeError('Variable "button_offset" does not exist.', 32, $this->source); })())]);
            // line 33
            echo "            <div class=\"form-group\">
                <div ";
            // line 34
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 34, $this->source); })()));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">
                ";
            // line 35
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 35, $this->source); })()), 'widget');
            echo "
                </div>
            </div>
        ";
        } else {
            // line 39
            echo "            <div class=\"form-group\">
                ";
            // line 40
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 40, $this->source); })()), 'widget');
            echo "
            </div>
        ";
        }
        // line 43
        echo "    ";
        $___internal_587205bf079ed55048a7baf444a3186ae2763f2ae54a81055c2060d9251209f1_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 30
        echo twig_spaceless($___internal_587205bf079ed55048a7baf444a3186ae2763f2ae54a81055c2060d9251209f1_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 47
    public function block_textarea_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "textarea_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "textarea_widget"));

        // line 48
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 48, $this->source); })()), "text")) : ("text"));
        // line 49
        echo "    ";
        if (((0 !== twig_compare((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 49, $this->source); })()), "hidden")) && ( !(null === ((array_key_exists("widget_addon_prepend", $context)) ? (_twig_default_filter((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 49, $this->source); })()), null)) : (null))) ||  !(null === ((array_key_exists("widget_addon_append", $context)) ? (_twig_default_filter((isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 49, $this->source); })()), null)) : (null)))))) {
            // line 50
            echo "    <div class=\"input-group\">
        ";
            // line 51
            if ( !(null === ((array_key_exists("widget_addon_prepend", $context)) ? (_twig_default_filter((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 51, $this->source); })()), null)) : (null)))) {
                // line 52
                echo "            ";
                $context["widget_addon"] = (isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 52, $this->source); })());
                // line 53
                echo "            ";
                $this->displayBlock("widget_addon", $context, $blocks);
                echo "
        ";
            }
            // line 55
            echo "    ";
        }
        // line 56
        echo "    ";
        $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 56, $this->source); })()), ["class" => ((((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 56)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 56), "")) : ("")) . " ") . (isset($context["widget_form_control_class"]) || array_key_exists("widget_form_control_class", $context) ? $context["widget_form_control_class"] : (function () { throw new RuntimeError('Variable "widget_form_control_class" does not exist.', 56, $this->source); })()))]);
        // line 57
        echo "    ";
        $this->displayParentBlock("textarea_widget", $context, $blocks);
        echo "
    ";
        // line 58
        if (((0 !== twig_compare((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 58, $this->source); })()), "hidden")) && ( !(null === ((array_key_exists("widget_addon_prepend", $context)) ? (_twig_default_filter((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 58, $this->source); })()), null)) : (null))) ||  !(null === ((array_key_exists("widget_addon_append", $context)) ? (_twig_default_filter((isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 58, $this->source); })()), null)) : (null)))))) {
            // line 59
            echo "        ";
            if ( !(null === ((array_key_exists("widget_addon_append", $context)) ? (_twig_default_filter((isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 59, $this->source); })()), null)) : (null)))) {
                // line 60
                echo "        ";
                $context["widget_addon"] = (isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 60, $this->source); })());
                // line 61
                echo "        ";
                $this->displayBlock("widget_addon", $context, $blocks);
                echo "
        ";
            }
            // line 63
            echo "    </div>
    ";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 67
    public function block_form_widget_simple($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_widget_simple"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_widget_simple"));

        // line 68
        ob_start();
        // line 69
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 69, $this->source); })()), "text")) : ("text"));
        // line 70
        echo "    ";
        if (((0 !== twig_compare((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 70, $this->source); })()), "hidden")) && ((( !(null === ((array_key_exists("widget_addon_prepend", $context)) ? (_twig_default_filter((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 70, $this->source); })()), null)) : (null))) ||  !(null === ((array_key_exists("widget_addon_append", $context)) ? (_twig_default_filter((isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 70, $this->source); })()), null)) : (null)))) ||  !(null === ((array_key_exists("widget_btn_prepend", $context)) ? (_twig_default_filter((isset($context["widget_btn_prepend"]) || array_key_exists("widget_btn_prepend", $context) ? $context["widget_btn_prepend"] : (function () { throw new RuntimeError('Variable "widget_btn_prepend" does not exist.', 70, $this->source); })()), null)) : (null)))) ||  !(null === ((array_key_exists("widget_btn_append", $context)) ? (_twig_default_filter((isset($context["widget_btn_append"]) || array_key_exists("widget_btn_append", $context) ? $context["widget_btn_append"] : (function () { throw new RuntimeError('Variable "widget_btn_append" does not exist.', 70, $this->source); })()), null)) : (null)))))) {
            // line 71
            echo "    <div class=\"input-group\">
        ";
            // line 72
            if ( !(null === ((array_key_exists("widget_btn_prepend", $context)) ? (_twig_default_filter((isset($context["widget_btn_prepend"]) || array_key_exists("widget_btn_prepend", $context) ? $context["widget_btn_prepend"] : (function () { throw new RuntimeError('Variable "widget_btn_prepend" does not exist.', 72, $this->source); })()), null)) : (null)))) {
                // line 73
                echo "            ";
                $context["widget_btns"] = (isset($context["widget_btn_prepend"]) || array_key_exists("widget_btn_prepend", $context) ? $context["widget_btn_prepend"] : (function () { throw new RuntimeError('Variable "widget_btn_prepend" does not exist.', 73, $this->source); })());
                // line 74
                echo "            ";
                $this->displayBlock("widget_btns", $context, $blocks);
                echo "
        ";
            }
            // line 76
            echo "        ";
            if ( !(null === ((array_key_exists("widget_addon_prepend", $context)) ? (_twig_default_filter((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 76, $this->source); })()), null)) : (null)))) {
                // line 77
                echo "            ";
                $context["widget_addon"] = (isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 77, $this->source); })());
                // line 78
                echo "            ";
                $this->displayBlock("widget_addon", $context, $blocks);
                echo "
        ";
            }
            // line 80
            echo "    ";
        }
        // line 81
        echo "    ";
        if ( !((array_key_exists("widget_remove_btn", $context)) ? (_twig_default_filter((isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 81, $this->source); })()), null)) : (null))) {
            // line 82
            echo "        ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 82, $this->source); })()), ["class" => (((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 82)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 82), "")) : ("")) . " not-removable")]);
            // line 83
            echo "    ";
        }
        // line 84
        echo "    ";
        $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 84, $this->source); })()), ["class" => twig_trim_filter(((((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 84)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 84), "")) : ("")) . " ") . (isset($context["widget_form_control_class"]) || array_key_exists("widget_form_control_class", $context) ? $context["widget_form_control_class"] : (function () { throw new RuntimeError('Variable "widget_form_control_class" does not exist.', 84, $this->source); })())))]);
        // line 85
        echo "    ";
        if (((isset($context["static_text"]) || array_key_exists("static_text", $context) ? $context["static_text"] : (function () { throw new RuntimeError('Variable "static_text" does not exist.', 85, $this->source); })()) === true)) {
            // line 86
            echo "        <p class=\"form-control-static\">";
            echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 86, $this->source); })()), "html", null, true);
            echo "</p>
    ";
        } else {
            // line 88
            echo "        ";
            $this->displayParentBlock("form_widget_simple", $context, $blocks);
            echo "
    ";
        }
        // line 90
        echo "    ";
        if (((0 !== twig_compare((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 90, $this->source); })()), "hidden")) && ((( !(null === ((array_key_exists("widget_addon_prepend", $context)) ? (_twig_default_filter((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 90, $this->source); })()), null)) : (null))) ||  !(null === ((array_key_exists("widget_addon_append", $context)) ? (_twig_default_filter((isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 90, $this->source); })()), null)) : (null)))) ||  !(null === ((array_key_exists("widget_btn_prepend", $context)) ? (_twig_default_filter((isset($context["widget_btn_prepend"]) || array_key_exists("widget_btn_prepend", $context) ? $context["widget_btn_prepend"] : (function () { throw new RuntimeError('Variable "widget_btn_prepend" does not exist.', 90, $this->source); })()), null)) : (null)))) ||  !(null === ((array_key_exists("widget_btn_append", $context)) ? (_twig_default_filter((isset($context["widget_btn_append"]) || array_key_exists("widget_btn_append", $context) ? $context["widget_btn_append"] : (function () { throw new RuntimeError('Variable "widget_btn_append" does not exist.', 90, $this->source); })()), null)) : (null)))))) {
            // line 91
            echo "        ";
            if ( !(null === ((array_key_exists("widget_addon_append", $context)) ? (_twig_default_filter((isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 91, $this->source); })()), null)) : (null)))) {
                // line 92
                echo "            ";
                $context["widget_addon"] = (isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 92, $this->source); })());
                // line 93
                echo "            ";
                $this->displayBlock("widget_addon", $context, $blocks);
                echo "
        ";
            }
            // line 95
            echo "        ";
            if ( !(null === ((array_key_exists("widget_btn_append", $context)) ? (_twig_default_filter((isset($context["widget_btn_append"]) || array_key_exists("widget_btn_append", $context) ? $context["widget_btn_append"] : (function () { throw new RuntimeError('Variable "widget_btn_append" does not exist.', 95, $this->source); })()), null)) : (null)))) {
                // line 96
                echo "            ";
                $context["widget_btns"] = (isset($context["widget_btn_append"]) || array_key_exists("widget_btn_append", $context) ? $context["widget_btn_append"] : (function () { throw new RuntimeError('Variable "widget_btn_append" does not exist.', 96, $this->source); })());
                // line 97
                echo "            ";
                $this->displayBlock("widget_btns", $context, $blocks);
                echo "
        ";
            }
            // line 99
            echo "    </div>
    ";
        }
        $___internal_60b893fea60b05c7ad654eaeac17f74e54373b33cfebfb3897c14ca1ce96a374_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 68
        echo twig_spaceless($___internal_60b893fea60b05c7ad654eaeac17f74e54373b33cfebfb3897c14ca1ce96a374_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 104
    public function block_form_widget_compound($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_widget_compound"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_widget_compound"));

        // line 105
        ob_start();
        // line 106
        echo "    ";
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 106, $this->source); })()), "parent", [], "any", false, false, false, 106), null))) {
            // line 107
            echo "        ";
            if ((isset($context["render_fieldset"]) || array_key_exists("render_fieldset", $context) ? $context["render_fieldset"] : (function () { throw new RuntimeError('Variable "render_fieldset" does not exist.', 107, $this->source); })())) {
                echo "<fieldset>";
            }
            // line 108
            echo "        ";
            if ((isset($context["show_legend"]) || array_key_exists("show_legend", $context) ? $context["show_legend"] : (function () { throw new RuntimeError('Variable "show_legend" does not exist.', 108, $this->source); })())) {
                $this->displayBlock("form_legend", $context, $blocks);
            }
            // line 109
            echo "    ";
        }
        // line 110
        echo "
    ";
        // line 111
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 111, $this->source); })()), "vars", [], "any", false, false, false, 111), "tabbed", [], "any", false, false, false, 111)) {
            // line 112
            echo "        ";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 112, $this->source); })()), 'tabs');
            echo "
        <div class=\"tab-content\">
    ";
        }
        // line 115
        echo "
    ";
        // line 116
        $this->displayBlock("form_rows_visible", $context, $blocks);
        echo "

    ";
        // line 118
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 118, $this->source); })()), "vars", [], "any", false, false, false, 118), "tabbed", [], "any", false, false, false, 118)) {
            // line 119
            echo "        </div>
    ";
        }
        // line 121
        echo "
    ";
        // line 122
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 122, $this->source); })()), 'rest');
        echo "

    ";
        // line 124
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 124, $this->source); })()), "parent", [], "any", false, false, false, 124), null))) {
            // line 125
            echo "        ";
            if ((isset($context["render_fieldset"]) || array_key_exists("render_fieldset", $context) ? $context["render_fieldset"] : (function () { throw new RuntimeError('Variable "render_fieldset" does not exist.', 125, $this->source); })())) {
                echo "</fieldset>";
            }
            // line 126
            echo "    ";
        }
        $___internal_7aa9b420d363b8201525a79bc3ad201af406710fcdc46fabe9eec60eadfb11e6_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 105
        echo twig_spaceless($___internal_7aa9b420d363b8201525a79bc3ad201af406710fcdc46fabe9eec60eadfb11e6_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 130
    public function block_form_tabs($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_tabs"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_tabs"));

        // line 131
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 131), "tabsView", [], "any", true, true, false, 131)) {
            // line 132
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 132, $this->source); })()), "vars", [], "any", false, false, false, 132), "tabsView", [], "any", false, false, false, 132), 'widget');
            echo "
";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 136
    public function block_tabs_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "tabs_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "tabs_widget"));

        // line 137
        ob_start();
        // line 138
        echo "<ul class=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 138, $this->source); })()), "vars", [], "any", false, false, false, 138), "attr", [], "any", false, false, false, 138), "class", [], "any", false, false, false, 138), "html", null, true);
        echo "\">
    ";
        // line 139
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 139, $this->source); })()), "vars", [], "any", false, false, false, 139), "tabs", [], "any", false, false, false, 139));
        foreach ($context['_seq'] as $context["_key"] => $context["tab"]) {
            // line 140
            echo "        ";
            $context["class"] = twig_trim_filter((((twig_get_attribute($this->env, $this->source, $context["tab"], "active", [], "any", false, false, false, 140)) ? ("active ") : ("")) . ((twig_get_attribute($this->env, $this->source, $context["tab"], "disabled", [], "any", false, false, false, 140)) ? ("disabled") : (""))));
            // line 141
            echo "        <li";
            if ( !twig_test_empty(twig_trim_filter((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 141, $this->source); })())))) {
                echo " class=\"";
                echo twig_escape_filter($this->env, (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 141, $this->source); })()), "html", null, true);
                echo "\"";
            }
            echo ">
            <a data-toggle=\"tab\" href=\"#";
            // line 142
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tab"], "id", [], "any", false, false, false, 142), "html", null, true);
            echo "\">
                ";
            // line 143
            if (twig_get_attribute($this->env, $this->source, $context["tab"], "icon", [], "any", false, false, false, 143)) {
                echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, twig_get_attribute($this->env, $this->source, $context["tab"], "icon", [], "any", false, false, false, 143));
            }
            // line 144
            if ( !twig_test_empty(twig_get_attribute($this->env, $this->source, $context["tab"], "label", [], "any", false, false, false, 144))) {
                // line 145
                echo twig_escape_filter($this->env, (((twig_get_attribute($this->env, $this->source, $context["tab"], "translation_domain", [], "any", false, false, false, 145) === false)) ? (twig_get_attribute($this->env, $this->source, $context["tab"], "label", [], "any", false, false, false, 145)) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, $context["tab"], "label", [], "any", false, false, false, 145), [], twig_get_attribute($this->env, $this->source, $context["tab"], "translation_domain", [], "any", false, false, false, 145)))), "html", null, true);
            } elseif ( !(twig_get_attribute($this->env, $this->source,             // line 146
$context["tab"], "label", [], "any", false, false, false, 146) === false)) {
                // line 147
                echo twig_escape_filter($this->env, (((twig_get_attribute($this->env, $this->source, $context["tab"], "translation_domain", [], "any", false, false, false, 147) === false)) ? ($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize(twig_get_attribute($this->env, $this->source, $context["tab"], "name", [], "any", false, false, false, 147))) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize(twig_get_attribute($this->env, $this->source, $context["tab"], "name", [], "any", false, false, false, 147)), [], twig_get_attribute($this->env, $this->source, $context["tab"], "translation_domain", [], "any", false, false, false, 147)))), "html", null, true);
            }
            // line 149
            echo "</a>
        </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tab'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 152
        echo "</ul>
";
        $___internal_74e6b1b22f3f794a9f39319240b3b09907077a87540057f36932770fc2ffe5ef_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 137
        echo twig_spaceless($___internal_74e6b1b22f3f794a9f39319240b3b09907077a87540057f36932770fc2ffe5ef_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 156
    public function block_form_tab($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_tab"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_tab"));

        // line 157
        echo "    ";
        $context["tab_attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 157, $this->source); })()), ["class" => twig_trim_filter(((("tab-pane" . ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 157, $this->source); })()), "vars", [], "any", false, false, false, 157), "tab_active", [], "any", false, false, false, 157)) ? (" active") : (""))) . " ") . ((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 157)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 157), "")) : ("")))), "id" => (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 157, $this->source); })())]);
        // line 158
        echo "    <div";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tab_attr"]) || array_key_exists("tab_attr", $context) ? $context["tab_attr"] : (function () { throw new RuntimeError('Variable "tab_attr" does not exist.', 158, $this->source); })()));
        foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
            echo " ";
            echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
            echo "=\"";
            echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
            echo "\"";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo ">
        ";
        // line 159
        $this->displayBlock("form_widget", $context, $blocks);
        echo "
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 163
    public function block_collection_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "collection_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "collection_widget"));

        // line 164
        ob_start();
        // line 165
        echo "    ";
        if (array_key_exists("prototype", $context)) {
            // line 166
            echo "        ";
            $context["prototype_markup"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["prototype"]) || array_key_exists("prototype", $context) ? $context["prototype"] : (function () { throw new RuntimeError('Variable "prototype" does not exist.', 166, $this->source); })()), 'row');
            // line 167
            echo "        ";
            $context["data_prototype_name"] = ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 167), "form", [], "any", false, true, false, 167), "vars", [], "any", false, true, false, 167), "prototype", [], "any", false, true, false, 167), "vars", [], "any", false, true, false, 167), "name", [], "any", true, true, false, 167)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 167), "form", [], "any", false, true, false, 167), "vars", [], "any", false, true, false, 167), "prototype", [], "any", false, true, false, 167), "vars", [], "any", false, true, false, 167), "name", [], "any", false, false, false, 167), "__name__")) : ("__name__"));
            // line 168
            echo "        ";
            $context["data_prototype_label"] = ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 168), "form", [], "any", false, true, false, 168), "vars", [], "any", false, true, false, 168), "prototype", [], "any", false, true, false, 168), "vars", [], "any", false, true, false, 168), "label", [], "any", true, true, false, 168)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 168), "form", [], "any", false, true, false, 168), "vars", [], "any", false, true, false, 168), "prototype", [], "any", false, true, false, 168), "vars", [], "any", false, true, false, 168), "label", [], "any", false, false, false, 168), "__name__label__")) : ("__name__label__"));
            // line 169
            echo "        ";
            $context["widget_form_group_attr"] = twig_array_merge(twig_array_merge((isset($context["widget_form_group_attr"]) || array_key_exists("widget_form_group_attr", $context) ? $context["widget_form_group_attr"] : (function () { throw new RuntimeError('Variable "widget_form_group_attr" does not exist.', 169, $this->source); })()), ["data-prototype" =>             // line 170
(isset($context["prototype_markup"]) || array_key_exists("prototype_markup", $context) ? $context["prototype_markup"] : (function () { throw new RuntimeError('Variable "prototype_markup" does not exist.', 170, $this->source); })()), "data-prototype-name" =>             // line 171
(isset($context["data_prototype_name"]) || array_key_exists("data_prototype_name", $context) ? $context["data_prototype_name"] : (function () { throw new RuntimeError('Variable "data_prototype_name" does not exist.', 171, $this->source); })()), "data-prototype-label" =>             // line 172
(isset($context["data_prototype_label"]) || array_key_exists("data_prototype_label", $context) ? $context["data_prototype_label"] : (function () { throw new RuntimeError('Variable "data_prototype_label" does not exist.', 172, $this->source); })())]),             // line 173
(isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 173, $this->source); })()));
            // line 174
            echo "    ";
        }
        // line 175
        echo "    ";
        // line 176
        echo "\t";
        if ((twig_in_filter("collection", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 176, $this->source); })()), "vars", [], "any", false, false, false, 176), "block_prefixes", [], "any", false, false, false, 176)) && twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 176))) {
            // line 177
            echo "\t\t";
            $context["widget_form_group_attr"] = twig_array_merge((isset($context["widget_form_group_attr"]) || array_key_exists("widget_form_group_attr", $context) ? $context["widget_form_group_attr"] : (function () { throw new RuntimeError('Variable "widget_form_group_attr" does not exist.', 177, $this->source); })()), ["class" => ((((twig_get_attribute($this->env, $this->source, ($context["widget_form_group_attr"] ?? null), "class", [], "any", true, true, false, 177)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["widget_form_group_attr"] ?? null), "class", [], "any", false, false, false, 177), "row")) : ("row")) . " ") . twig_get_attribute($this->env, $this->source, (isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 177, $this->source); })()), "class", [], "any", false, false, false, 177))]);
            // line 178
            echo "\t";
        }
        // line 179
        echo "    ";
        // line 180
        echo "    ";
        $context["widget_form_group_attr"] = twig_array_merge((isset($context["widget_form_group_attr"]) || array_key_exists("widget_form_group_attr", $context) ? $context["widget_form_group_attr"] : (function () { throw new RuntimeError('Variable "widget_form_group_attr" does not exist.', 180, $this->source); })()), ["id" => (("collection" . (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 180, $this->source); })())) . "_form_group"), "class" => (((twig_get_attribute($this->env, $this->source, (isset($context["widget_form_group_attr"]) || array_key_exists("widget_form_group_attr", $context) ? $context["widget_form_group_attr"] : (function () { throw new RuntimeError('Variable "widget_form_group_attr" does not exist.', 180, $this->source); })()), "class", [], "any", false, false, false, 180) . " collection-items ") . (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 180, $this->source); })())) . "_form_group")]);
        // line 181
        echo "
    <div ";
        // line 182
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["widget_form_group_attr"]) || array_key_exists("widget_form_group_attr", $context) ? $context["widget_form_group_attr"] : (function () { throw new RuntimeError('Variable "widget_form_group_attr" does not exist.', 182, $this->source); })()));
        foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
            echo " ";
            echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
            echo "=\"";
            echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
            echo "\"";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo ">
    ";
        // line 184
        echo "    ";
        if (((0 === twig_compare(twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 184, $this->source); })()), "vars", [], "any", false, false, false, 184), "value", [], "any", false, false, false, 184)), 0)) && array_key_exists("prototype", $context))) {
            // line 185
            echo "        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["prototype_names"]) || array_key_exists("prototype_names", $context) ? $context["prototype_names"] : (function () { throw new RuntimeError('Variable "prototype_names" does not exist.', 185, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["name"]) {
                // line 186
                echo "            ";
                echo twig_replace_filter((isset($context["prototype_markup"]) || array_key_exists("prototype_markup", $context) ? $context["prototype_markup"] : (function () { throw new RuntimeError('Variable "prototype_markup" does not exist.', 186, $this->source); })()), ["__name__" => $context["name"]]);
                echo "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['name'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 188
            echo "    ";
        }
        // line 189
        echo "    ";
        $this->displayBlock("form_widget", $context, $blocks);
        echo "
    </div>
";
        $___internal_9ed4bf5d019a8953c4c50f70850efaac7f76c0ac27364d230029ae13e0596eba_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 164
        echo twig_spaceless($___internal_9ed4bf5d019a8953c4c50f70850efaac7f76c0ac27364d230029ae13e0596eba_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 194
    public function block_choice_widget_collapsed($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        // line 195
        echo "    ";
        $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 195, $this->source); })()), ["class" => ((((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 195)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 195), "")) : ("")) . " ") . (isset($context["widget_form_control_class"]) || array_key_exists("widget_form_control_class", $context) ? $context["widget_form_control_class"] : (function () { throw new RuntimeError('Variable "widget_form_control_class" does not exist.', 195, $this->source); })()))]);
        // line 196
        echo "    ";
        if ((0 === twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 196, $this->source); })()), "inline-btn"))) {
            // line 197
            echo "        ";
            $this->displayBlock("choice_widget_expanded", $context, $blocks);
            echo "
    ";
        } else {
            // line 199
            echo "        ";
            $this->displayParentBlock("choice_widget_collapsed", $context, $blocks);
            echo "
    ";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 203
    public function block_choice_widget_expanded($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        // line 204
        echo "    ";
        ob_start();
        // line 205
        echo "        ";
        $context["tagName"] = "label";
        // line 206
        echo "        ";
        $context["label_attr"] = twig_array_merge((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 206, $this->source); })()), ["class" => ((twig_get_attribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", true, true, false, 206)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", false, false, false, 206), "")) : (""))]);
        // line 207
        echo "        ";
        $context["label_attr"] = twig_array_merge((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 207, $this->source); })()), ["class" => ((twig_get_attribute($this->env, $this->source, (isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 207, $this->source); })()), "class", [], "any", false, false, false, 207) . " ") . (((0 !== twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 207, $this->source); })()), ""))) ? ((((((isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 207, $this->source); })())) ? ("checkbox") : ("radio")) . "-") . (isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 207, $this->source); })()))) : ("")))]);
        // line 208
        echo "        ";
        if ((isset($context["expanded"]) || array_key_exists("expanded", $context) ? $context["expanded"] : (function () { throw new RuntimeError('Variable "expanded" does not exist.', 208, $this->source); })())) {
            // line 209
            echo "            ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 209, $this->source); })()), ["class" => ((((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 209)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 209), "")) : ("")) . " ") . (isset($context["horizontal_input_wrapper_class"]) || array_key_exists("horizontal_input_wrapper_class", $context) ? $context["horizontal_input_wrapper_class"] : (function () { throw new RuntimeError('Variable "horizontal_input_wrapper_class" does not exist.', 209, $this->source); })()))]);
            // line 210
            echo "        ";
        }
        // line 211
        echo "        ";
        if (((isset($context["layout"]) || array_key_exists("layout", $context) ? $context["layout"] : (function () { throw new RuntimeError('Variable "layout" does not exist.', 211, $this->source); })()) === false)) {
            // line 212
            echo "            <div>
        ";
        }
        // line 214
        echo "        ";
        if ((0 === twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 214, $this->source); })()), "inline-btn"))) {
            // line 215
            echo "            ";
            $context["tagName"] = "button";
            // line 216
            echo "            <div class=\"btn-group\" data-toggle=\"buttons\">
        ";
        }
        // line 218
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 218, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 219
            echo "            ";
            if (!twig_in_filter((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 219, $this->source); })()), [0 => "inline", 1 => "inline-btn"])) {
                // line 220
                echo "                <div class=\"";
                echo (((isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 220, $this->source); })())) ? ("checkbox") : ("radio"));
                echo "\"";
                // line 221
                if ((0 === twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 221, $this->source); })()), "inline-btn"))) {
                    echo " class=\"btn-group\" data-toggle=\"buttons\"";
                }
                echo ">
            ";
            }
            // line 223
            echo "            ";
            if ((0 === twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 223, $this->source); })()), "inline-btn"))) {
                // line 224
                echo "                ";
                $context["label_attr"] = twig_array_merge(((array_key_exists("label_attr", $context)) ? (_twig_default_filter((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 224, $this->source); })()), [])) : ([])), ["class" => ("btn " . ((twig_get_attribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", true, true, false, 224)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", false, false, false, 224), "")) : ("")))]);
                // line 225
                echo "            ";
            }
            // line 226
            echo "            ";
            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["child"], "vars", [], "any", false, false, false, 226), "checked", [], "any", false, false, false, 226) && (0 === twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 226, $this->source); })()), "inline-btn")))) {
                // line 227
                echo "                ";
                $context["label_attr_copy"] = twig_array_merge(((array_key_exists("label_attr", $context)) ? (_twig_default_filter((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 227, $this->source); })()), [])) : ([])), ["class" => ("active " . ((twig_get_attribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", true, true, false, 227)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", false, false, false, 227), "")) : ("")))]);
                // line 228
                echo "            ";
            } else {
                // line 229
                echo "                ";
                $context["label_attr_copy"] = ((array_key_exists("label_attr", $context)) ? (_twig_default_filter((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 229, $this->source); })()), [])) : ([]));
                // line 230
                echo "            ";
            }
            // line 231
            echo "            <";
            echo twig_escape_filter($this->env, (isset($context["tagName"]) || array_key_exists("tagName", $context) ? $context["tagName"] : (function () { throw new RuntimeError('Variable "tagName" does not exist.', 231, $this->source); })()), "html", null, true);
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["label_attr_copy"]) || array_key_exists("label_attr_copy", $context) ? $context["label_attr_copy"] : (function () { throw new RuntimeError('Variable "label_attr_copy" does not exist.', 231, $this->source); })()));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 232
            if ((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 232, $this->source); })())) {
                echo " disabled=\"disabled\"";
            }
            echo ">
            ";
            // line 233
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', ["horizontal_label_class" => (isset($context["horizontal_label_class"]) || array_key_exists("horizontal_label_class", $context) ? $context["horizontal_label_class"] : (function () { throw new RuntimeError('Variable "horizontal_label_class" does not exist.', 233, $this->source); })()), "horizontal_input_wrapper_class" => (isset($context["horizontal_input_wrapper_class"]) || array_key_exists("horizontal_input_wrapper_class", $context) ? $context["horizontal_input_wrapper_class"] : (function () { throw new RuntimeError('Variable "horizontal_input_wrapper_class" does not exist.', 233, $this->source); })()), "attr" => ["class" => ((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", true, true, false, 233)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", false, false, false, 233), "")) : (""))]]);
            echo "
            ";
            // line 234
            if ( !array_key_exists("choice_translation_domain", $context)) {
                // line 235
                echo "                ";
                $context["choice_translation_domain"] = (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 235, $this->source); })());
                // line 236
                echo "            ";
            }
            // line 237
            echo "            ";
            if (((0 === twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 237, $this->source); })()), "inline-btn")) || (0 === twig_compare((isset($context["widget_checkbox_label"]) || array_key_exists("widget_checkbox_label", $context) ? $context["widget_checkbox_label"] : (function () { throw new RuntimeError('Variable "widget_checkbox_label" does not exist.', 237, $this->source); })()), "widget")))) {
                // line 238
                echo "                ";
                echo ((((isset($context["choice_translation_domain"]) || array_key_exists("choice_translation_domain", $context) ? $context["choice_translation_domain"] : (function () { throw new RuntimeError('Variable "choice_translation_domain" does not exist.', 238, $this->source); })()) === false)) ? (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["child"], "vars", [], "any", false, false, false, 238), "label", [], "any", false, false, false, 238)) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["child"], "vars", [], "any", false, false, false, 238), "label", [], "any", false, false, false, 238), [], (isset($context["choice_translation_domain"]) || array_key_exists("choice_translation_domain", $context) ? $context["choice_translation_domain"] : (function () { throw new RuntimeError('Variable "choice_translation_domain" does not exist.', 238, $this->source); })()))));
                echo "
            ";
            } else {
                // line 240
                echo "                ";
                echo twig_escape_filter($this->env, ((((isset($context["choice_translation_domain"]) || array_key_exists("choice_translation_domain", $context) ? $context["choice_translation_domain"] : (function () { throw new RuntimeError('Variable "choice_translation_domain" does not exist.', 240, $this->source); })()) === false)) ? (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["child"], "vars", [], "any", false, false, false, 240), "label", [], "any", false, false, false, 240)) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["child"], "vars", [], "any", false, false, false, 240), "label", [], "any", false, false, false, 240), [], (isset($context["choice_translation_domain"]) || array_key_exists("choice_translation_domain", $context) ? $context["choice_translation_domain"] : (function () { throw new RuntimeError('Variable "choice_translation_domain" does not exist.', 240, $this->source); })())))), "html", null, true);
                echo "
            ";
            }
            // line 242
            echo "            </";
            echo twig_escape_filter($this->env, (isset($context["tagName"]) || array_key_exists("tagName", $context) ? $context["tagName"] : (function () { throw new RuntimeError('Variable "tagName" does not exist.', 242, $this->source); })()), "html", null, true);
            echo ">
            ";
            // line 243
            if (!twig_in_filter((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 243, $this->source); })()), [0 => "inline", 1 => "inline-btn"])) {
                // line 244
                echo "                </div>
            ";
            }
            // line 246
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 247
        echo "        ";
        if ((0 === twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 247, $this->source); })()), "inline-btn"))) {
            // line 248
            echo "            </div>
        ";
        }
        // line 250
        echo "        ";
        if (((isset($context["layout"]) || array_key_exists("layout", $context) ? $context["layout"] : (function () { throw new RuntimeError('Variable "layout" does not exist.', 250, $this->source); })()) === false)) {
            // line 251
            echo "            </div>
        ";
        }
        // line 253
        echo "    ";
        $___internal_02f54658c22b532fbed87f656ec98735c6097a0d1bdfaf47501f8bcc4918bc9e_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 204
        echo twig_spaceless($___internal_02f54658c22b532fbed87f656ec98735c6097a0d1bdfaf47501f8bcc4918bc9e_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 256
    public function block_checkbox_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "checkbox_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "checkbox_widget"));

        // line 257
        echo "    ";
        ob_start();
        // line 258
        echo "        ";
        if (( !((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 258, $this->source); })()) === false) && twig_test_empty((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 258, $this->source); })())))) {
            // line 259
            if ((array_key_exists("label_format", $context) &&  !twig_test_empty((isset($context["label_format"]) || array_key_exists("label_format", $context) ? $context["label_format"] : (function () { throw new RuntimeError('Variable "label_format" does not exist.', 259, $this->source); })())))) {
                // line 260
                $context["label"] = twig_replace_filter((isset($context["label_format"]) || array_key_exists("label_format", $context) ? $context["label_format"] : (function () { throw new RuntimeError('Variable "label_format" does not exist.', 260, $this->source); })()), ["%name%" =>                 // line 261
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 261, $this->source); })()), "%id%" =>                 // line 262
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 262, $this->source); })())]);
            } else {
                // line 265
                $context["label"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 265, $this->source); })()));
            }
        }
        // line 268
        echo "        ";
        if (((0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 268, $this->source); })()), "parent", [], "any", false, false, false, 268), null)) && !twig_in_filter("choice", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 268, $this->source); })()), "parent", [], "any", false, false, false, 268), "vars", [], "any", false, false, false, 268), "block_prefixes", [], "any", false, false, false, 268)))) {
            // line 269
            echo "            <div";
            // line 270
            if ((0 === twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 270, $this->source); })()), "inline-btn"))) {
                echo " class=\"btn-group\" data-toggle=\"buttons\"";
            } else {
                // line 271
                echo " class=\"checkbox\"";
            }
            // line 272
            echo ">
        ";
        }
        // line 274
        echo "        ";
        if ((((0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 274, $this->source); })()), "parent", [], "any", false, false, false, 274), null)) && !twig_in_filter("choice", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 274, $this->source); })()), "parent", [], "any", false, false, false, 274), "vars", [], "any", false, false, false, 274), "block_prefixes", [], "any", false, false, false, 274))) && (isset($context["label_render"]) || array_key_exists("label_render", $context) ? $context["label_render"] : (function () { throw new RuntimeError('Variable "label_render" does not exist.', 274, $this->source); })()))) {
            // line 275
            echo "            ";
            if ((0 === twig_compare((isset($context["widget_type"]) || array_key_exists("widget_type", $context) ? $context["widget_type"] : (function () { throw new RuntimeError('Variable "widget_type" does not exist.', 275, $this->source); })()), "inline-btn"))) {
                // line 276
                echo "                ";
                $context["default_class"] = "btn btn-primary";
                // line 277
                echo "                ";
                $context["label_attr"] = ((array_key_exists("attr", $context)) ? (_twig_default_filter((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 277, $this->source); })()), ["class" => (isset($context["default_class"]) || array_key_exists("default_class", $context) ? $context["default_class"] : (function () { throw new RuntimeError('Variable "default_class" does not exist.', 277, $this->source); })())])) : (["class" => (isset($context["default_class"]) || array_key_exists("default_class", $context) ? $context["default_class"] : (function () { throw new RuntimeError('Variable "default_class" does not exist.', 277, $this->source); })())]));
                // line 278
                echo "                ";
                if ((isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 278, $this->source); })())) {
                    // line 279
                    echo "                    ";
                    $context["label_attr"] = twig_array_merge((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 279, $this->source); })()), ["class" => ("active " . ((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 279)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 279), (isset($context["default_class"]) || array_key_exists("default_class", $context) ? $context["default_class"] : (function () { throw new RuntimeError('Variable "default_class" does not exist.', 279, $this->source); })()))) : ((isset($context["default_class"]) || array_key_exists("default_class", $context) ? $context["default_class"] : (function () { throw new RuntimeError('Variable "default_class" does not exist.', 279, $this->source); })()))))]);
                    // line 280
                    echo "                ";
                }
                // line 281
                echo "            ";
            }
            // line 282
            echo "            <label";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 282, $this->source); })()));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 283
            if ((0 === twig_compare((isset($context["layout"]) || array_key_exists("layout", $context) ? $context["layout"] : (function () { throw new RuntimeError('Variable "layout" does not exist.', 283, $this->source); })()), "inline"))) {
                echo " class=\"checkbox-inline\"";
            }
            echo ">
        ";
        }
        // line 285
        echo "        <input type=\"checkbox\" ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        if (array_key_exists("value", $context)) {
            echo " value=\"";
            echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 285, $this->source); })()), "html", null, true);
            echo "\"";
        }
        if ((isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 285, $this->source); })())) {
            echo " checked=\"checked\"";
        }
        echo "/>
        ";
        // line 286
        if (((0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 286, $this->source); })()), "parent", [], "any", false, false, false, 286), null)) && !twig_in_filter("choice", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 286, $this->source); })()), "parent", [], "any", false, false, false, 286), "vars", [], "any", false, false, false, 286), "block_prefixes", [], "any", false, false, false, 286)))) {
            // line 287
            echo "            ";
            if ((isset($context["label_render"]) || array_key_exists("label_render", $context) ? $context["label_render"] : (function () { throw new RuntimeError('Variable "label_render" does not exist.', 287, $this->source); })())) {
                // line 288
                echo "                ";
                if (twig_in_filter((isset($context["widget_checkbox_label"]) || array_key_exists("widget_checkbox_label", $context) ? $context["widget_checkbox_label"] : (function () { throw new RuntimeError('Variable "widget_checkbox_label" does not exist.', 288, $this->source); })()), [0 => "both", 1 => "widget"])) {
                    // line 289
                    echo "                    ";
                    if ( !array_key_exists("choice_translation_domain", $context)) {
                        // line 290
                        echo "                        ";
                        $context["choice_translation_domain"] = (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 290, $this->source); })());
                        // line 291
                        echo "                    ";
                    }
                    // line 292
                    echo "                    ";
                    echo ((((isset($context["choice_translation_domain"]) || array_key_exists("choice_translation_domain", $context) ? $context["choice_translation_domain"] : (function () { throw new RuntimeError('Variable "choice_translation_domain" does not exist.', 292, $this->source); })()) === false)) ? ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 292, $this->source); })())) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 292, $this->source); })()), [], (isset($context["choice_translation_domain"]) || array_key_exists("choice_translation_domain", $context) ? $context["choice_translation_domain"] : (function () { throw new RuntimeError('Variable "choice_translation_domain" does not exist.', 292, $this->source); })()))));
                    echo "
                ";
                } else {
                    // line 294
                    echo "                    ";
                    $this->displayBlock("form_help", $context, $blocks);
                    echo "
                ";
                }
                // line 296
                echo "                </label>
            ";
            }
            // line 298
            echo "        ";
        }
        // line 299
        echo "        ";
        if (((0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 299, $this->source); })()), "parent", [], "any", false, false, false, 299), null)) && !twig_in_filter("choice", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 299, $this->source); })()), "parent", [], "any", false, false, false, 299), "vars", [], "any", false, false, false, 299), "block_prefixes", [], "any", false, false, false, 299)))) {
            // line 300
            echo "            </div>
        ";
        }
        // line 302
        echo "    ";
        $___internal_66ccdfc90016e866b7d0c89f07e4faa7df5a0d8faf4a1d87a4869cdae498d4e0_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 257
        echo twig_spaceless($___internal_66ccdfc90016e866b7d0c89f07e4faa7df5a0d8faf4a1d87a4869cdae498d4e0_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 305
    public function block_date_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "date_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "date_widget"));

        // line 306
        ob_start();
        // line 307
        if ((0 === twig_compare((isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 307, $this->source); })()), "single_text"))) {
            // line 308
            echo "    ";
            if (array_key_exists("datepicker", $context)) {
                // line 309
                echo "        ";
                $context["widget_addon_icon"] = ((twig_get_attribute($this->env, $this->source, ($context["widget_addon_append"] ?? null), "icon", [], "any", true, true, false, 309)) ? (twig_get_attribute($this->env, $this->source, (isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 309, $this->source); })()), "icon", [], "any", false, false, false, 309)) : ("calendar"));
                // line 310
                echo "        <div ";
                if (twig_get_attribute($this->env, $this->source, ($context["datepicker"] ?? null), "attr", [], "any", true, true, false, 310)) {
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["datepicker"]) || array_key_exists("datepicker", $context) ? $context["datepicker"] : (function () { throw new RuntimeError('Variable "datepicker" does not exist.', 310, $this->source); })()), "attr", [], "any", false, false, false, 310));
                    foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                        echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                        echo "=\"";
                        echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                        echo "\" ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                }
                echo " data-provider=\"datepicker\" class=\"input-group date\" data-date=\"";
                echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 310, $this->source); })()), "html", null, true);
                echo "\" data-link-field=\"";
                echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 310, $this->source); })()), "html", null, true);
                echo "\" data-link-format=\"yyyy-mm-dd\">
            <input type=\"hidden\" value=\"";
                // line 311
                echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 311, $this->source); })()), "html", null, true);
                echo "\" ";
                $this->displayBlock("widget_attributes", $context, $blocks);
                echo ">
            ";
                // line 312
                if ((array_key_exists("widget_reset_icon", $context) && (0 === twig_compare((isset($context["widget_reset_icon"]) || array_key_exists("widget_reset_icon", $context) ? $context["widget_reset_icon"] : (function () { throw new RuntimeError('Variable "widget_reset_icon" does not exist.', 312, $this->source); })()), true)))) {
                    // line 313
                    echo "                <span class=\"input-group-addon\">";
                    echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, "remove");
                    echo "</span>
            ";
                }
                // line 315
                echo "            ";
                // line 316
                echo "            ";
                $context["id"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 316, $this->source); })()) . "_mopa_picker_display");
                // line 317
                echo "            ";
                $context["full_name"] = null;
                // line 318
                echo "            ";
                $context["type"] = "text";
                // line 319
                echo "            ";
                $this->displayBlock("form_widget_simple", $context, $blocks);
                echo "
            <span class=\"input-group-addon\">";
                // line 320
                echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, (isset($context["widget_addon_icon"]) || array_key_exists("widget_addon_icon", $context) ? $context["widget_addon_icon"] : (function () { throw new RuntimeError('Variable "widget_addon_icon" does not exist.', 320, $this->source); })()));
                echo "</span>
        </div>
    ";
            } else {
                // line 323
                echo "        ";
                $this->displayBlock("form_widget_simple", $context, $blocks);
                echo "
    ";
            }
        } else {
            // line 326
            echo "    ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 326, $this->source); })()), ["class" => ((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 326)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 326), "inline")) : ("inline"))]);
            // line 327
            echo "    \t<div class=\"row\">
        ";
            // line 328
            echo twig_replace_filter((isset($context["date_pattern"]) || array_key_exists("date_pattern", $context) ? $context["date_pattern"] : (function () { throw new RuntimeError('Variable "date_pattern" does not exist.', 328, $this->source); })()), ["{{ year }}" => (((("<div class=\"" . ((twig_get_attribute($this->env, $this->source,             // line 329
($context["date_wrapper_class"] ?? null), "year", [], "array", true, true, false, 329)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["date_wrapper_class"] ?? null), "year", [], "array", false, false, false, 329), "col-xs-4")) : ("col-xs-4"))) . "\">") . $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 329, $this->source); })()), "year", [], "any", false, false, false, 329), 'widget', ["attr" => ["class" => (((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", true, true, false, 329)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", false, false, false, 329), "")) : ("")) . "")]])) . "</div>"), "{{ month }}" => (((("<div class=\"" . ((twig_get_attribute($this->env, $this->source,             // line 330
($context["date_wrapper_class"] ?? null), "month", [], "array", true, true, false, 330)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["date_wrapper_class"] ?? null), "month", [], "array", false, false, false, 330), "col-xs-4")) : ("col-xs-4"))) . "\">") . $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 330, $this->source); })()), "month", [], "any", false, false, false, 330), 'widget', ["attr" => ["class" => (((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", true, true, false, 330)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", false, false, false, 330), "")) : ("")) . "")]])) . "</div>"), "{{ day }}" => (((("<div class=\"" . ((twig_get_attribute($this->env, $this->source,             // line 331
($context["date_wrapper_class"] ?? null), "day", [], "array", true, true, false, 331)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["date_wrapper_class"] ?? null), "day", [], "array", false, false, false, 331), "col-xs-4")) : ("col-xs-4"))) . "\">") . $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 331, $this->source); })()), "day", [], "any", false, false, false, 331), 'widget', ["attr" => ["class" => (((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", true, true, false, 331)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", false, false, false, 331), "")) : ("")) . "")]])) . "</div>")]);
            // line 332
            echo "
        </div>
";
        }
        $___internal_c16962eb611f9bcbd30d8d68f437c47a6392e0885a263ec0fab5bcbb1ca235be_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 306
        echo twig_spaceless($___internal_c16962eb611f9bcbd30d8d68f437c47a6392e0885a263ec0fab5bcbb1ca235be_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 338
    public function block_time_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "time_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "time_widget"));

        // line 339
        ob_start();
        // line 340
        if ((0 === twig_compare((isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 340, $this->source); })()), "single_text"))) {
            // line 341
            echo "    ";
            if (array_key_exists("timepicker", $context)) {
                // line 342
                echo "        ";
                $context["widget_addon_icon"] = ((twig_get_attribute($this->env, $this->source, ($context["widget_addon_append"] ?? null), "icon", [], "any", true, true, false, 342)) ? (twig_get_attribute($this->env, $this->source, (isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 342, $this->source); })()), "icon", [], "any", false, false, false, 342)) : ("time"));
                // line 343
                echo "        <div ";
                if (twig_get_attribute($this->env, $this->source, ($context["timepicker"] ?? null), "attr", [], "any", true, true, false, 343)) {
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["timepicker"]) || array_key_exists("timepicker", $context) ? $context["timepicker"] : (function () { throw new RuntimeError('Variable "timepicker" does not exist.', 343, $this->source); })()), "attr", [], "any", false, false, false, 343));
                    foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                        echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                        echo "=\"";
                        echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                        echo "\" ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                }
                echo " data-provider=\"timepicker\" class=\"input-group date\" data-date=\"";
                echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 343, $this->source); })()), "html", null, true);
                echo "\" data-link-field=\"";
                echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 343, $this->source); })()), "html", null, true);
                echo "\" data-link-format=\"hh:ii\">
            <input type=\"hidden\" value=\"";
                // line 344
                echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 344, $this->source); })()), "html", null, true);
                echo "\" ";
                $this->displayBlock("widget_attributes", $context, $blocks);
                echo ">
            ";
                // line 345
                if ((array_key_exists("widget_reset_icon", $context) && (0 === twig_compare((isset($context["widget_reset_icon"]) || array_key_exists("widget_reset_icon", $context) ? $context["widget_reset_icon"] : (function () { throw new RuntimeError('Variable "widget_reset_icon" does not exist.', 345, $this->source); })()), true)))) {
                    // line 346
                    echo "                <span class=\"input-group-addon\">";
                    echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, "remove");
                    echo "</span>
            ";
                }
                // line 348
                echo "            ";
                // line 349
                echo "            ";
                $context["id"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 349, $this->source); })()) . "_mopa_picker_display");
                // line 350
                echo "            ";
                $context["full_name"] = null;
                // line 351
                echo "            ";
                $context["type"] = "text";
                // line 352
                echo "            ";
                $this->displayBlock("form_widget_simple", $context, $blocks);
                echo "
            <span class=\"input-group-addon\">";
                // line 353
                echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, (isset($context["widget_addon_icon"]) || array_key_exists("widget_addon_icon", $context) ? $context["widget_addon_icon"] : (function () { throw new RuntimeError('Variable "widget_addon_icon" does not exist.', 353, $this->source); })()));
                echo "</span>
        </div>
    ";
            } else {
                // line 356
                echo "        ";
                $this->displayBlock("form_widget_simple", $context, $blocks);
                echo "
    ";
            }
        } else {
            // line 359
            echo "    ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 359, $this->source); })()), ["class" => ((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 359)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 359), "")) : (""))]);
            // line 360
            echo "    ";
            ob_start();
            // line 361
            echo "    ";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 361, $this->source); })()), "hour", [], "any", false, false, false, 361), 'widget', ["horizontal_input_wrapper_class" => ((array_key_exists("horizontal_input_wrapper_class", $context)) ? (_twig_default_filter((isset($context["horizontal_input_wrapper_class"]) || array_key_exists("horizontal_input_wrapper_class", $context) ? $context["horizontal_input_wrapper_class"] : (function () { throw new RuntimeError('Variable "horizontal_input_wrapper_class" does not exist.', 361, $this->source); })()), "col-sm-2")) : ("col-sm-2"))]);
            echo "
    ";
            // line 362
            if ((isset($context["with_minutes"]) || array_key_exists("with_minutes", $context) ? $context["with_minutes"] : (function () { throw new RuntimeError('Variable "with_minutes" does not exist.', 362, $this->source); })())) {
                // line 363
                echo "        ";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 363, $this->source); })()), "minute", [], "any", false, false, false, 363), 'widget', ["horizontal_input_wrapper_class" => ((array_key_exists("horizontal_input_wrapper_class", $context)) ? (_twig_default_filter((isset($context["horizontal_input_wrapper_class"]) || array_key_exists("horizontal_input_wrapper_class", $context) ? $context["horizontal_input_wrapper_class"] : (function () { throw new RuntimeError('Variable "horizontal_input_wrapper_class" does not exist.', 363, $this->source); })()), "col-sm-2")) : ("col-sm-2"))]);
                echo "
    ";
            }
            // line 365
            echo "    ";
            if ((isset($context["with_seconds"]) || array_key_exists("with_seconds", $context) ? $context["with_seconds"] : (function () { throw new RuntimeError('Variable "with_seconds" does not exist.', 365, $this->source); })())) {
                // line 366
                echo "        :";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 366, $this->source); })()), "second", [], "any", false, false, false, 366), 'widget', ["horizontal_input_wrapper_class" => ((array_key_exists("horizontal_input_wrapper_class", $context)) ? (_twig_default_filter((isset($context["horizontal_input_wrapper_class"]) || array_key_exists("horizontal_input_wrapper_class", $context) ? $context["horizontal_input_wrapper_class"] : (function () { throw new RuntimeError('Variable "horizontal_input_wrapper_class" does not exist.', 366, $this->source); })()), "col-sm-2")) : ("col-sm-2"))]);
                echo "
    ";
            }
            // line 368
            echo "    ";
            $___internal_65f7e63cef50ec207a913a9c7117d908b3df6277e562abb6faae7c0c8610d422_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 360
            echo twig_spaceless($___internal_65f7e63cef50ec207a913a9c7117d908b3df6277e562abb6faae7c0c8610d422_);
        }
        $___internal_c5f9ed46921810ad5fb61b2297de578d80dbca70845f913ae546e9f7370d8c1b_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 339
        echo twig_spaceless($___internal_c5f9ed46921810ad5fb61b2297de578d80dbca70845f913ae546e9f7370d8c1b_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 373
    public function block_datetime_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "datetime_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "datetime_widget"));

        // line 374
        ob_start();
        // line 375
        echo "    ";
        if ((0 === twig_compare((isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 375, $this->source); })()), "single_text"))) {
            // line 376
            echo "        ";
            if (array_key_exists("datetimepicker", $context)) {
                // line 377
                echo "            ";
                $context["widget_addon_icon"] = ((twig_get_attribute($this->env, $this->source, ($context["widget_addon_append"] ?? null), "icon", [], "any", true, true, false, 377)) ? (twig_get_attribute($this->env, $this->source, (isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 377, $this->source); })()), "icon", [], "any", false, false, false, 377)) : ("th"));
                // line 378
                echo "            <div ";
                if (twig_get_attribute($this->env, $this->source, ($context["datetimepicker"] ?? null), "attr", [], "any", true, true, false, 378)) {
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["datetimepicker"]) || array_key_exists("datetimepicker", $context) ? $context["datetimepicker"] : (function () { throw new RuntimeError('Variable "datetimepicker" does not exist.', 378, $this->source); })()), "attr", [], "any", false, false, false, 378));
                    foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                        echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                        echo "=\"";
                        echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                        echo "\" ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                }
                echo " data-provider=\"datetimepicker\" class=\"input-group date\" data-date=\"";
                if ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 378, $this->source); })())) {
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 378, $this->source); })()), "Y-m-d H:i"), "html", null, true);
                }
                echo "\" data-link-field=\"";
                echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 378, $this->source); })()), "html", null, true);
                echo "\" data-link-format=\"yyyy-mm-dd hh:ii\">
                <input type=\"hidden\" value=\"";
                // line 379
                if ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 379, $this->source); })())) {
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 379, $this->source); })()), "Y-m-d H:i"), "html", null, true);
                }
                echo "\" ";
                $this->displayBlock("widget_attributes", $context, $blocks);
                echo ">
                ";
                // line 380
                if ((array_key_exists("widget_reset_icon", $context) && (0 === twig_compare((isset($context["widget_reset_icon"]) || array_key_exists("widget_reset_icon", $context) ? $context["widget_reset_icon"] : (function () { throw new RuntimeError('Variable "widget_reset_icon" does not exist.', 380, $this->source); })()), true)))) {
                    // line 381
                    echo "                    <span class=\"input-group-addon\">";
                    echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, "remove");
                    echo "</span>
                ";
                }
                // line 383
                echo "                ";
                // line 384
                echo "                ";
                $context["id"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 384, $this->source); })()) . "_mopa_picker_display");
                // line 385
                echo "                ";
                $context["full_name"] = null;
                // line 386
                echo "                ";
                $context["type"] = "text";
                // line 387
                echo "                ";
                $this->displayBlock("form_widget_simple", $context, $blocks);
                echo "
                <span class=\"input-group-addon\">";
                // line 388
                echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, (isset($context["widget_addon_icon"]) || array_key_exists("widget_addon_icon", $context) ? $context["widget_addon_icon"] : (function () { throw new RuntimeError('Variable "widget_addon_icon" does not exist.', 388, $this->source); })()));
                echo "</span>
            </div>
        ";
            } else {
                // line 391
                echo "            ";
                $this->displayBlock("form_widget_simple", $context, $blocks);
                echo "
        ";
            }
            // line 393
            echo "    ";
        } else {
            // line 394
            echo "            ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 394, $this->source); })()), ["class" => ((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 394)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 394), "")) : (""))]);
            // line 395
            echo "            <div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">
                ";
            // line 396
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 396, $this->source); })()), "date", [], "any", false, false, false, 396), 'errors');
            echo "
                ";
            // line 397
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 397, $this->source); })()), "time", [], "any", false, false, false, 397), 'errors');
            echo "
                ";
            // line 398
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 398, $this->source); })()), "date", [], "any", false, false, false, 398), 'widget', ["attr" => ["class" => ((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", true, true, false, 398)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", false, false, false, 398), "")) : (""))], "horizontal_input_wrapper_class" => ((array_key_exists("horizontal_input_wrapper_class", $context)) ? (_twig_default_filter((isset($context["horizontal_input_wrapper_class"]) || array_key_exists("horizontal_input_wrapper_class", $context) ? $context["horizontal_input_wrapper_class"] : (function () { throw new RuntimeError('Variable "horizontal_input_wrapper_class" does not exist.', 398, $this->source); })()), "col-sm-3")) : ("col-sm-3"))]);
            echo "
                ";
            // line 399
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 399, $this->source); })()), "time", [], "any", false, false, false, 399), 'widget', ["attr" => ["class" => ((twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", true, true, false, 399)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["attr"] ?? null), "widget_class", [], "any", false, false, false, 399), "")) : (""))], "horizontal_input_wrapper_class" => ((array_key_exists("horizontal_input_wrapper_class", $context)) ? (_twig_default_filter((isset($context["horizontal_input_wrapper_class"]) || array_key_exists("horizontal_input_wrapper_class", $context) ? $context["horizontal_input_wrapper_class"] : (function () { throw new RuntimeError('Variable "horizontal_input_wrapper_class" does not exist.', 399, $this->source); })()), "col-sm-2")) : ("col-sm-2"))]);
            echo "
            </div>
    ";
        }
        $___internal_5bc669562c6cf453eebfdec92ef7b5bcbf8fb63d802f5bcf687a840878e84e08_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 374
        echo twig_spaceless($___internal_5bc669562c6cf453eebfdec92ef7b5bcbf8fb63d802f5bcf687a840878e84e08_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 405
    public function block_percent_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "percent_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "percent_widget"));

        // line 406
        ob_start();
        // line 407
        echo "    ";
        $context["widget_addon_append"] = twig_array_merge((isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 407, $this->source); })()), ["text" => ((twig_get_attribute($this->env, $this->source, ($context["widget_addon_append"] ?? null), "text", [], "any", true, true, false, 407)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["widget_addon_append"] ?? null), "text", [], "any", false, false, false, 407), "%")) : ("%"))]);
        // line 408
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo "
";
        $___internal_e011d4fd3a9b3c37193b5f7777017d67c7975778c0b9c6942d566a3536e1f737_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 406
        echo twig_spaceless($___internal_e011d4fd3a9b3c37193b5f7777017d67c7975778c0b9c6942d566a3536e1f737_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 412
    public function block_money_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "money_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "money_widget"));

        // line 413
        ob_start();
        // line 414
        echo "    ";
        $context["widget_addon_prepend"] = (((((0 !== twig_compare((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 414, $this->source); })()), false)) || (0 === twig_compare((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 414, $this->source); })()), null))) && (0 !== twig_compare((isset($context["money_pattern"]) || array_key_exists("money_pattern", $context) ? $context["money_pattern"] : (function () { throw new RuntimeError('Variable "money_pattern" does not exist.', 414, $this->source); })()), "{{ widget }}")))) ? (["text" => twig_trim_filter(twig_replace_filter((isset($context["money_pattern"]) || array_key_exists("money_pattern", $context) ? $context["money_pattern"] : (function () { throw new RuntimeError('Variable "money_pattern" does not exist.', 414, $this->source); })()), ["{{ widget }}" => ""]))]) : (((array_key_exists("widget_addon_prepend", $context)) ? (_twig_default_filter((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 414, $this->source); })()), null)) : (null))));
        // line 415
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo "
";
        $___internal_830c7a0841c4012bb57e97e2a2f97dcae02ea32b5db95d058510f5f8cd3f3afa_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 413
        echo twig_spaceless($___internal_830c7a0841c4012bb57e97e2a2f97dcae02ea32b5db95d058510f5f8cd3f3afa_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 419
    public function block_file_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "file_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "file_widget"));

        // line 420
        ob_start();
        // line 421
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 421, $this->source); })()), "file")) : ("file"));
        // line 422
        echo "    ";
        if ( !(null === ((array_key_exists("widget_addon_prepend", $context)) ? (_twig_default_filter((isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 422, $this->source); })()), null)) : (null)))) {
            // line 423
            echo "        ";
            $context["widget_addon"] = (isset($context["widget_addon_prepend"]) || array_key_exists("widget_addon_prepend", $context) ? $context["widget_addon_prepend"] : (function () { throw new RuntimeError('Variable "widget_addon_prepend" does not exist.', 423, $this->source); })());
            // line 424
            echo "        ";
            $this->displayBlock("widget_addon", $context, $blocks);
            echo "
    ";
        }
        // line 426
        echo "<input type=\"";
        echo twig_escape_filter($this->env, (isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 426, $this->source); })()), "html", null, true);
        echo "\" ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        echo "/>
";
        // line 427
        if (((0 !== twig_compare((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 427, $this->source); })()), "hidden")) &&  !(null === ((twig_get_attribute($this->env, $this->source, ($context["widget_addon"] ?? null), "type", [], "any", true, true, false, 427)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["widget_addon"] ?? null), "type", [], "any", false, false, false, 427), null)) : (null))))) {
            // line 428
            echo "    ";
            if ( !(null === ((array_key_exists("widget_addon_append", $context)) ? (_twig_default_filter((isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 428, $this->source); })()), null)) : (null)))) {
                // line 429
                echo "        ";
                $context["widget_addon"] = (isset($context["widget_addon_append"]) || array_key_exists("widget_addon_append", $context) ? $context["widget_addon_append"] : (function () { throw new RuntimeError('Variable "widget_addon_append" does not exist.', 429, $this->source); })());
                // line 430
                echo "        ";
                $this->displayBlock("widget_addon", $context, $blocks);
                echo "
    ";
            }
        }
        $___internal_7da3d60c62ac3e6dbdbf5f477aef272b985bae5043714fa972d5e6f00bb0df4d_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 420
        echo twig_spaceless($___internal_7da3d60c62ac3e6dbdbf5f477aef272b985bae5043714fa972d5e6f00bb0df4d_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 438
    public function block_form_legend($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_legend"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_legend"));

        // line 439
        ob_start();
        // line 440
        echo "    ";
        if (twig_test_empty((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 440, $this->source); })()))) {
            // line 441
            if ((array_key_exists("label_format", $context) &&  !twig_test_empty((isset($context["label_format"]) || array_key_exists("label_format", $context) ? $context["label_format"] : (function () { throw new RuntimeError('Variable "label_format" does not exist.', 441, $this->source); })())))) {
                // line 442
                $context["label"] = twig_replace_filter((isset($context["label_format"]) || array_key_exists("label_format", $context) ? $context["label_format"] : (function () { throw new RuntimeError('Variable "label_format" does not exist.', 442, $this->source); })()), ["%name%" =>                 // line 443
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 443, $this->source); })()), "%id%" =>                 // line 444
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 444, $this->source); })())]);
            } else {
                // line 447
                $context["label"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 447, $this->source); })()));
            }
        }
        // line 450
        echo "    <";
        echo twig_escape_filter($this->env, (isset($context["legend_tag"]) || array_key_exists("legend_tag", $context) ? $context["legend_tag"] : (function () { throw new RuntimeError('Variable "legend_tag" does not exist.', 450, $this->source); })()), "html", null, true);
        echo ">";
        echo twig_escape_filter($this->env, ((((isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 450, $this->source); })()) === false)) ? ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 450, $this->source); })())) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 450, $this->source); })()), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 450, $this->source); })())))), "html", null, true);
        echo "</";
        echo twig_escape_filter($this->env, (isset($context["legend_tag"]) || array_key_exists("legend_tag", $context) ? $context["legend_tag"] : (function () { throw new RuntimeError('Variable "legend_tag" does not exist.', 450, $this->source); })()), "html", null, true);
        echo ">
";
        $___internal_fdb5f3f705de08e4fd7497643c43e6996b5eb460b4e1c6e113b033bc5726b3da_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 439
        echo twig_spaceless($___internal_fdb5f3f705de08e4fd7497643c43e6996b5eb460b4e1c6e113b033bc5726b3da_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 454
    public function block_form_label($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_label"));

        // line 455
        if ((!twig_in_filter("checkbox", (isset($context["block_prefixes"]) || array_key_exists("block_prefixes", $context) ? $context["block_prefixes"] : (function () { throw new RuntimeError('Variable "block_prefixes" does not exist.', 455, $this->source); })())) || twig_in_filter((isset($context["widget_checkbox_label"]) || array_key_exists("widget_checkbox_label", $context) ? $context["widget_checkbox_label"] : (function () { throw new RuntimeError('Variable "widget_checkbox_label" does not exist.', 455, $this->source); })()), [0 => "label", 1 => "both"]))) {
            // line 456
            ob_start();
            // line 457
            echo "    ";
            if ( !((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 457, $this->source); })()) === false)) {
                // line 458
                echo "        ";
                if (twig_test_empty((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 458, $this->source); })()))) {
                    // line 459
                    if ((array_key_exists("label_format", $context) &&  !twig_test_empty((isset($context["label_format"]) || array_key_exists("label_format", $context) ? $context["label_format"] : (function () { throw new RuntimeError('Variable "label_format" does not exist.', 459, $this->source); })())))) {
                        // line 460
                        $context["label"] = twig_replace_filter((isset($context["label_format"]) || array_key_exists("label_format", $context) ? $context["label_format"] : (function () { throw new RuntimeError('Variable "label_format" does not exist.', 460, $this->source); })()), ["%name%" =>                         // line 461
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 461, $this->source); })()), "%id%" =>                         // line 462
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 462, $this->source); })())]);
                    } else {
                        // line 465
                        $context["label"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 465, $this->source); })()));
                    }
                }
                // line 468
                echo "        ";
                if ( !(isset($context["compound"]) || array_key_exists("compound", $context) ? $context["compound"] : (function () { throw new RuntimeError('Variable "compound" does not exist.', 468, $this->source); })())) {
                    // line 469
                    echo "            ";
                    $context["label_attr"] = twig_array_merge((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 469, $this->source); })()), ["for" => (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 469, $this->source); })())]);
                    // line 470
                    echo "        ";
                }
                // line 471
                echo "        ";
                $context["label_attr_class"] = "";
                // line 472
                echo "        ";
                if ((0 === twig_compare((isset($context["layout"]) || array_key_exists("layout", $context) ? $context["layout"] : (function () { throw new RuntimeError('Variable "layout" does not exist.', 472, $this->source); })()), "horizontal"))) {
                    // line 473
                    echo "            ";
                    $context["label_attr_class"] = (("control-label " . (isset($context["label_attr_class"]) || array_key_exists("label_attr_class", $context) ? $context["label_attr_class"] : (function () { throw new RuntimeError('Variable "label_attr_class" does not exist.', 473, $this->source); })())) . (isset($context["horizontal_label_class"]) || array_key_exists("horizontal_label_class", $context) ? $context["horizontal_label_class"] : (function () { throw new RuntimeError('Variable "horizontal_label_class" does not exist.', 473, $this->source); })()));
                    // line 474
                    echo "        ";
                }
                // line 475
                echo "        ";
                if ((isset($context["horizontal_label_div_class"]) || array_key_exists("horizontal_label_div_class", $context) ? $context["horizontal_label_div_class"] : (function () { throw new RuntimeError('Variable "horizontal_label_div_class" does not exist.', 475, $this->source); })())) {
                    // line 476
                    echo "        <div class=\"";
                    echo twig_escape_filter($this->env, (isset($context["horizontal_label_div_class"]) || array_key_exists("horizontal_label_div_class", $context) ? $context["horizontal_label_div_class"] : (function () { throw new RuntimeError('Variable "horizontal_label_div_class" does not exist.', 476, $this->source); })()), "html", null, true);
                    echo "\">
        ";
                }
                // line 478
                echo "        ";
                $context["label_attr"] = twig_array_merge((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 478, $this->source); })()), ["class" => twig_trim_filter((((((twig_get_attribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", true, true, false, 478)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", false, false, false, 478), "")) : ("")) . " ") . (isset($context["label_attr_class"]) || array_key_exists("label_attr_class", $context) ? $context["label_attr_class"] : (function () { throw new RuntimeError('Variable "label_attr_class" does not exist.', 478, $this->source); })())) . (((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 478, $this->source); })())) ? (" required") : (" optional"))))]);
                // line 479
                echo "        <label";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["label_attr"]) || array_key_exists("label_attr", $context) ? $context["label_attr"] : (function () { throw new RuntimeError('Variable "label_attr" does not exist.', 479, $this->source); })()));
                foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                    echo " ";
                    echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                    echo "=\"";
                    echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                    echo "\"";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                echo ">
        ";
                // line 480
                echo twig_escape_filter($this->env, ((((isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 480, $this->source); })()) === false)) ? ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 480, $this->source); })())) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 480, $this->source); })()), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 480, $this->source); })())))), "html", null, true);
                // line 481
                $this->displayBlock("label_asterisk", $context, $blocks);
                echo "
        ";
                // line 482
                if (((twig_in_filter("collection", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 482, $this->source); })()), "vars", [], "any", false, false, false, 482), "block_prefixes", [], "any", false, false, false, 482)) && ((array_key_exists("widget_add_btn", $context)) ? (_twig_default_filter((isset($context["widget_add_btn"]) || array_key_exists("widget_add_btn", $context) ? $context["widget_add_btn"] : (function () { throw new RuntimeError('Variable "widget_add_btn" does not exist.', 482, $this->source); })()), null)) : (null))) && (0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 482, $this->source); })()), "vars", [], "any", false, false, false, 482), "allow_add", [], "any", false, false, false, 482), true)))) {
                    // line 483
                    echo "            &nbsp;";
                    $this->displayBlock("form_widget_add_btn", $context, $blocks);
                    echo "
        ";
                }
                // line 485
                echo "        ";
                if ((isset($context["help_label"]) || array_key_exists("help_label", $context) ? $context["help_label"] : (function () { throw new RuntimeError('Variable "help_label" does not exist.', 485, $this->source); })())) {
                    // line 486
                    echo "            ";
                    $this->displayBlock("help_label", $context, $blocks);
                    echo "
        ";
                }
                // line 488
                echo "        ";
                if (twig_get_attribute($this->env, $this->source, (isset($context["help_label_tooltip"]) || array_key_exists("help_label_tooltip", $context) ? $context["help_label_tooltip"] : (function () { throw new RuntimeError('Variable "help_label_tooltip" does not exist.', 488, $this->source); })()), "title", [], "any", false, false, false, 488)) {
                    // line 489
                    echo "            ";
                    $this->displayBlock("help_label_tooltip", $context, $blocks);
                    echo "
        ";
                }
                // line 491
                echo "        ";
                if (twig_get_attribute($this->env, $this->source, (isset($context["help_label_popover"]) || array_key_exists("help_label_popover", $context) ? $context["help_label_popover"] : (function () { throw new RuntimeError('Variable "help_label_popover" does not exist.', 491, $this->source); })()), "title", [], "any", false, false, false, 491)) {
                    // line 492
                    echo "            ";
                    $this->displayBlock("help_label_popover", $context, $blocks);
                    echo "
        ";
                }
                // line 494
                echo "        </label>
        ";
                // line 495
                if ((isset($context["horizontal_label_div_class"]) || array_key_exists("horizontal_label_div_class", $context) ? $context["horizontal_label_div_class"] : (function () { throw new RuntimeError('Variable "horizontal_label_div_class" does not exist.', 495, $this->source); })())) {
                    // line 496
                    echo "        </div>
        ";
                }
                // line 498
                echo "    ";
            }
            $___internal_127a520e6c4bac5945ee5ea64ec18ad7a78d4b4fe3e0b8e1fe9b308aa1541610_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 456
            echo twig_spaceless($___internal_127a520e6c4bac5945ee5ea64ec18ad7a78d4b4fe3e0b8e1fe9b308aa1541610_);
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 503
    public function block_help_label($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_label"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_label"));

        // line 504
        echo "    <span class=\"help-block\">";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["help_label"]) || array_key_exists("help_label", $context) ? $context["help_label"] : (function () { throw new RuntimeError('Variable "help_label" does not exist.', 504, $this->source); })()), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 504, $this->source); })())), "html", null, true);
        echo "</span>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 507
    public function block_help_label_tooltip($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_label_tooltip"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_label_tooltip"));

        // line 508
        echo "    <span class=\"help-block\">
        <a href=\"#\" data-toggle=\"tooltip\" data-placement=\"";
        // line 509
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["help_label_tooltip"]) || array_key_exists("help_label_tooltip", $context) ? $context["help_label_tooltip"] : (function () { throw new RuntimeError('Variable "help_label_tooltip" does not exist.', 509, $this->source); })()), "placement", [], "any", false, false, false, 509), "html", null, true);
        echo "\" data-title=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["help_label_tooltip"]) || array_key_exists("help_label_tooltip", $context) ? $context["help_label_tooltip"] : (function () { throw new RuntimeError('Variable "help_label_tooltip" does not exist.', 509, $this->source); })()), "title", [], "any", false, false, false, 509), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 509, $this->source); })())), "html", null, true);
        echo "\">
            ";
        // line 510
        if ( !(twig_get_attribute($this->env, $this->source, (isset($context["help_label_tooltip"]) || array_key_exists("help_label_tooltip", $context) ? $context["help_label_tooltip"] : (function () { throw new RuntimeError('Variable "help_label_tooltip" does not exist.', 510, $this->source); })()), "icon", [], "any", false, false, false, 510) === false)) {
            // line 511
            echo "                ";
            echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, twig_get_attribute($this->env, $this->source, (isset($context["help_label_tooltip"]) || array_key_exists("help_label_tooltip", $context) ? $context["help_label_tooltip"] : (function () { throw new RuntimeError('Variable "help_label_tooltip" does not exist.', 511, $this->source); })()), "icon", [], "any", false, false, false, 511));
            echo "
            ";
        }
        // line 513
        echo "            ";
        if ( !(twig_get_attribute($this->env, $this->source, (isset($context["help_label_tooltip"]) || array_key_exists("help_label_tooltip", $context) ? $context["help_label_tooltip"] : (function () { throw new RuntimeError('Variable "help_label_tooltip" does not exist.', 513, $this->source); })()), "text", [], "any", false, false, false, 513) === null)) {
            // line 514
            echo "                ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["help_label_tooltip"]) || array_key_exists("help_label_tooltip", $context) ? $context["help_label_tooltip"] : (function () { throw new RuntimeError('Variable "help_label_tooltip" does not exist.', 514, $this->source); })()), "text", [], "any", false, false, false, 514), "html", null, true);
            echo "
            ";
        }
        // line 516
        echo "        </a>
    </span>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 520
    public function block_help_block_tooltip($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_block_tooltip"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_block_tooltip"));

        // line 521
        echo "    ";
        $context["help_label_tooltip"] = (isset($context["help_block_tooltip"]) || array_key_exists("help_block_tooltip", $context) ? $context["help_block_tooltip"] : (function () { throw new RuntimeError('Variable "help_block_tooltip" does not exist.', 521, $this->source); })());
        // line 522
        echo "    ";
        $this->displayBlock("help_label_tooltip", $context, $blocks);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 525
    public function block_help_label_popover($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_label_popover"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_label_popover"));

        // line 526
        echo "    <span class=\"help-block\">
        <a href=\"#\" data-toggle=\"popover\" data-trigger=\"hover\" data-placement=\"";
        // line 527
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["help_label_popover"]) || array_key_exists("help_label_popover", $context) ? $context["help_label_popover"] : (function () { throw new RuntimeError('Variable "help_label_popover" does not exist.', 527, $this->source); })()), "placement", [], "any", false, false, false, 527), "html", null, true);
        echo "\" data-title=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["help_label_popover"]) || array_key_exists("help_label_popover", $context) ? $context["help_label_popover"] : (function () { throw new RuntimeError('Variable "help_label_popover" does not exist.', 527, $this->source); })()), "title", [], "any", false, false, false, 527), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 527, $this->source); })())), "html", null, true);
        echo "\" data-content=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["help_label_popover"]) || array_key_exists("help_label_popover", $context) ? $context["help_label_popover"] : (function () { throw new RuntimeError('Variable "help_label_popover" does not exist.', 527, $this->source); })()), "content", [], "any", false, false, false, 527), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 527, $this->source); })())), "html", null, true);
        echo "\" data-html=\"true\">
            ";
        // line 528
        if ( !(twig_get_attribute($this->env, $this->source, (isset($context["help_label_popover"]) || array_key_exists("help_label_popover", $context) ? $context["help_label_popover"] : (function () { throw new RuntimeError('Variable "help_label_popover" does not exist.', 528, $this->source); })()), "icon", [], "any", false, false, false, 528) === false)) {
            // line 529
            echo "                ";
            echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, twig_get_attribute($this->env, $this->source, (isset($context["help_label_popover"]) || array_key_exists("help_label_popover", $context) ? $context["help_label_popover"] : (function () { throw new RuntimeError('Variable "help_label_popover" does not exist.', 529, $this->source); })()), "icon", [], "any", false, false, false, 529));
            echo "
            ";
        }
        // line 531
        echo "            ";
        if ( !(twig_get_attribute($this->env, $this->source, (isset($context["help_label_popover"]) || array_key_exists("help_label_popover", $context) ? $context["help_label_popover"] : (function () { throw new RuntimeError('Variable "help_label_popover" does not exist.', 531, $this->source); })()), "text", [], "any", false, false, false, 531) === null)) {
            // line 532
            echo "                ";
            echo twig_get_attribute($this->env, $this->source, (isset($context["help_label_popover"]) || array_key_exists("help_label_popover", $context) ? $context["help_label_popover"] : (function () { throw new RuntimeError('Variable "help_label_popover" does not exist.', 532, $this->source); })()), "text", [], "any", false, false, false, 532);
            echo "
            ";
        }
        // line 534
        echo "        </a>
    </span>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 538
    public function block_help_block_popover($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_block_popover"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_block_popover"));

        // line 539
        echo "    ";
        $context["help_label_popover"] = (isset($context["help_block_popover"]) || array_key_exists("help_block_popover", $context) ? $context["help_block_popover"] : (function () { throw new RuntimeError('Variable "help_block_popover" does not exist.', 539, $this->source); })());
        // line 540
        echo "    ";
        $this->displayBlock("help_label_popover", $context, $blocks);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 543
    public function block_form_actions_widget($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_actions_widget"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_actions_widget"));

        // line 544
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 544, $this->source); })()), "children", [], "any", false, false, false, 544));
        foreach ($context['_seq'] as $context["_key"] => $context["button"]) {
            // line 545
            echo "        ";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["button"], 'widget');
            echo "&nbsp; ";
            // line 546
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['button'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 550
    public function block_form_actions_row($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_actions_row"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_actions_row"));

        // line 551
        echo "    ";
        $this->displayBlock("button_row", $context, $blocks);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 554
    public function block_form_rows_visible($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_rows_visible"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_rows_visible"));

        // line 555
        ob_start();
        // line 556
        echo "     ";
        if ((1 === twig_compare(twig_length_filter($this->env, (isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 556, $this->source); })())), 0))) {
            // line 557
            echo "        <div class=\"symfony-form-errors\">
            ";
            // line 558
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 558, $this->source); })()), 'errors');
            echo "
        </div>
    ";
        }
        // line 561
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 561, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 562
            echo "        ";
            if (!twig_in_filter("hidden", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["child"], "vars", [], "any", false, false, false, 562), "block_prefixes", [], "any", false, false, false, 562))) {
                echo " ";
                // line 563
                echo "            ";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'row');
                echo "
        ";
            }
            // line 565
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        $___internal_e55fa86bbe36a48f7cbb8faa3afb910ffe6a01fd35aa8fa0a33026e781788339_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 555
        echo twig_spaceless($___internal_e55fa86bbe36a48f7cbb8faa3afb910ffe6a01fd35aa8fa0a33026e781788339_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 569
    public function block_form_row($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_row"));

        // line 570
        ob_start();
        // line 571
        echo "    ";
        if (twig_in_filter("tab", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 571, $this->source); })()), "vars", [], "any", false, false, false, 571), "block_prefixes", [], "any", false, false, false, 571))) {
            // line 572
            echo "        ";
            $this->displayBlock("form_tab", $context, $blocks);
            echo "
    ";
        } elseif ((        // line 573
(isset($context["embed_form"]) || array_key_exists("embed_form", $context) ? $context["embed_form"] : (function () { throw new RuntimeError('Variable "embed_form" does not exist.', 573, $this->source); })()) === true)) {
            // line 574
            echo "        ";
            if ( !twig_test_empty((isset($context["widget_prefix"]) || array_key_exists("widget_prefix", $context) ? $context["widget_prefix"] : (function () { throw new RuntimeError('Variable "widget_prefix" does not exist.', 574, $this->source); })()))) {
                echo $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["widget_prefix"]) || array_key_exists("widget_prefix", $context) ? $context["widget_prefix"] : (function () { throw new RuntimeError('Variable "widget_prefix" does not exist.', 574, $this->source); })()), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 574, $this->source); })()));
            }
            echo " ";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 574, $this->source); })()), 'widget', $context);
            echo " ";
            if ( !twig_test_empty((isset($context["widget_suffix"]) || array_key_exists("widget_suffix", $context) ? $context["widget_suffix"] : (function () { throw new RuntimeError('Variable "widget_suffix" does not exist.', 574, $this->source); })()))) {
                echo $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["widget_suffix"]) || array_key_exists("widget_suffix", $context) ? $context["widget_suffix"] : (function () { throw new RuntimeError('Variable "widget_suffix" does not exist.', 574, $this->source); })()), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 574, $this->source); })()));
            }
            // line 575
            echo "    ";
        } else {
            // line 576
            echo "        ";
            $this->displayBlock("widget_form_group_start", $context, $blocks);
            echo "

        ";
            // line 578
            if (((0 === twig_compare((isset($context["layout"]) || array_key_exists("layout", $context) ? $context["layout"] : (function () { throw new RuntimeError('Variable "layout" does not exist.', 578, $this->source); })()), "horizontal")) &&  !(isset($context["label_render"]) || array_key_exists("label_render", $context) ? $context["label_render"] : (function () { throw new RuntimeError('Variable "label_render" does not exist.', 578, $this->source); })()))) {
                // line 579
                echo "            ";
                $context["horizontal_input_wrapper_class"] = (((isset($context["horizontal_input_wrapper_class"]) || array_key_exists("horizontal_input_wrapper_class", $context) ? $context["horizontal_input_wrapper_class"] : (function () { throw new RuntimeError('Variable "horizontal_input_wrapper_class" does not exist.', 579, $this->source); })()) . " ") . (isset($context["horizontal_label_offset_class"]) || array_key_exists("horizontal_label_offset_class", $context) ? $context["horizontal_label_offset_class"] : (function () { throw new RuntimeError('Variable "horizontal_label_offset_class" does not exist.', 579, $this->source); })()));
                // line 580
                echo "        ";
            }
            // line 581
            echo "
        ";
            // line 582
            if ((isset($context["horizontal"]) || array_key_exists("horizontal", $context) ? $context["horizontal"] : (function () { throw new RuntimeError('Variable "horizontal" does not exist.', 582, $this->source); })())) {
                // line 583
                echo "        <div class=\"";
                echo twig_escape_filter($this->env, (isset($context["horizontal_input_wrapper_class"]) || array_key_exists("horizontal_input_wrapper_class", $context) ? $context["horizontal_input_wrapper_class"] : (function () { throw new RuntimeError('Variable "horizontal_input_wrapper_class" does not exist.', 583, $this->source); })()), "html", null, true);
                echo "\">
        ";
            }
            // line 585
            echo "
        ";
            // line 586
            if ( !twig_test_empty((isset($context["widget_prefix"]) || array_key_exists("widget_prefix", $context) ? $context["widget_prefix"] : (function () { throw new RuntimeError('Variable "widget_prefix" does not exist.', 586, $this->source); })()))) {
                echo $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["widget_prefix"]) || array_key_exists("widget_prefix", $context) ? $context["widget_prefix"] : (function () { throw new RuntimeError('Variable "widget_prefix" does not exist.', 586, $this->source); })()), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 586, $this->source); })()));
            }
            echo " ";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 586, $this->source); })()), 'widget', $context);
            echo " ";
            if ( !twig_test_empty((isset($context["widget_suffix"]) || array_key_exists("widget_suffix", $context) ? $context["widget_suffix"] : (function () { throw new RuntimeError('Variable "widget_suffix" does not exist.', 586, $this->source); })()))) {
                echo $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["widget_suffix"]) || array_key_exists("widget_suffix", $context) ? $context["widget_suffix"] : (function () { throw new RuntimeError('Variable "widget_suffix" does not exist.', 586, $this->source); })()), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 586, $this->source); })()));
            }
            // line 587
            echo "
        ";
            // line 588
            $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 588, $this->source); })()), "text")) : ("text"));
            // line 589
            echo "        ";
            if ((0 !== twig_compare((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 589, $this->source); })()), "hidden"))) {
                // line 590
                echo "        ";
                $this->displayBlock("form_message", $context, $blocks);
                echo "
        ";
            }
            // line 592
            echo "
        ";
            // line 593
            if ((isset($context["horizontal"]) || array_key_exists("horizontal", $context) ? $context["horizontal"] : (function () { throw new RuntimeError('Variable "horizontal" does not exist.', 593, $this->source); })())) {
                // line 594
                echo "        </div>
        ";
            }
            // line 596
            echo "
        ";
            // line 597
            if (((( !(null === twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 597, $this->source); })()), "parent", [], "any", false, false, false, 597)) && twig_in_filter("collection", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 597, $this->source); })()), "parent", [], "any", false, false, false, 597), "vars", [], "any", false, false, false, 597), "block_prefixes", [], "any", false, false, false, 597))) && ((array_key_exists("widget_remove_btn", $context)) ? (_twig_default_filter((isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 597, $this->source); })()), null)) : (null))) && ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "parent", [], "any", false, true, false, 597), "vars", [], "any", false, true, false, 597), "allow_delete", [], "any", true, true, false, 597)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "parent", [], "any", false, true, false, 597), "vars", [], "any", false, true, false, 597), "allow_delete", [], "any", false, false, false, 597), false)) : (false)))) {
                // line 598
                echo "            ";
                $this->displayBlock("form_widget_remove_btn", $context, $blocks);
                echo "
        ";
            }
            // line 600
            $this->displayBlock("widget_form_group_end", $context, $blocks);
            echo "
    ";
        }
        $___internal_03fb41448d50c1976c944bdd1d59cc23d4b7d235c3670adf401c94779ad1c235_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 570
        echo twig_spaceless($___internal_03fb41448d50c1976c944bdd1d59cc23d4b7d235c3670adf401c94779ad1c235_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 607
    public function block_form_message($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_message"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_message"));

        // line 608
        ob_start();
        // line 609
        echo "    ";
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 609, $this->source); })()), 'errors');
        echo "

    ";
        // line 611
        if (((!twig_in_filter("checkbox", (isset($context["block_prefixes"]) || array_key_exists("block_prefixes", $context) ? $context["block_prefixes"] : (function () { throw new RuntimeError('Variable "block_prefixes" does not exist.', 611, $this->source); })())) || (0 !== twig_compare((isset($context["widget_checkbox_label"]) || array_key_exists("widget_checkbox_label", $context) ? $context["widget_checkbox_label"] : (function () { throw new RuntimeError('Variable "widget_checkbox_label" does not exist.', 611, $this->source); })()), "label"))) && (isset($context["help_block"]) || array_key_exists("help_block", $context) ? $context["help_block"] : (function () { throw new RuntimeError('Variable "help_block" does not exist.', 611, $this->source); })()))) {
            // line 612
            echo "        ";
            $this->displayBlock("form_help", $context, $blocks);
            echo "
    ";
        }
        $___internal_c271461e8146850849966b2602f9659d11190fe971cbbf96c85d855eee1c0f72_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 608
        echo twig_spaceless($___internal_c271461e8146850849966b2602f9659d11190fe971cbbf96c85d855eee1c0f72_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 619
    public function block_form_help($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_help"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_help"));

        // line 620
        ob_start();
        // line 621
        echo "    ";
        if ((isset($context["help_block"]) || array_key_exists("help_block", $context) ? $context["help_block"] : (function () { throw new RuntimeError('Variable "help_block" does not exist.', 621, $this->source); })())) {
            echo "<p class=\"help-block\">";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["help_block"]) || array_key_exists("help_block", $context) ? $context["help_block"] : (function () { throw new RuntimeError('Variable "help_block" does not exist.', 621, $this->source); })()), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 621, $this->source); })()));
            echo "</p>";
        }
        // line 622
        echo "    ";
        if (twig_get_attribute($this->env, $this->source, (isset($context["help_block_tooltip"]) || array_key_exists("help_block_tooltip", $context) ? $context["help_block_tooltip"] : (function () { throw new RuntimeError('Variable "help_block_tooltip" does not exist.', 622, $this->source); })()), "title", [], "any", false, false, false, 622)) {
            // line 623
            echo "        &nbsp;";
            $this->displayBlock("help_block_tooltip", $context, $blocks);
            echo "
    ";
        }
        // line 625
        echo "    ";
        if (twig_get_attribute($this->env, $this->source, (isset($context["help_block_popover"]) || array_key_exists("help_block_popover", $context) ? $context["help_block_popover"] : (function () { throw new RuntimeError('Variable "help_block_popover" does not exist.', 625, $this->source); })()), "title", [], "any", false, false, false, 625)) {
            // line 626
            echo "        &nbsp;";
            $this->displayBlock("help_block_popover", $context, $blocks);
            echo "
    ";
        }
        $___internal_b2aa0dbecbb56a5d808afad2103d247b94e5fb80ee068602e97747f321be0bf7_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 620
        echo twig_spaceless($___internal_b2aa0dbecbb56a5d808afad2103d247b94e5fb80ee068602e97747f321be0bf7_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 631
    public function block_form_widget_add_btn($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_widget_add_btn"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_widget_add_btn"));

        // line 632
        ob_start();
        // line 633
        echo "    ";
        if (((array_key_exists("widget_add_btn", $context)) ? (_twig_default_filter((isset($context["widget_add_btn"]) || array_key_exists("widget_add_btn", $context) ? $context["widget_add_btn"] : (function () { throw new RuntimeError('Variable "widget_add_btn" does not exist.', 633, $this->source); })()), null)) : (null))) {
            // line 634
            echo "        ";
            $context["button_type"] = "add";
            // line 635
            echo "        ";
            $context["button_values"] = (isset($context["widget_add_btn"]) || array_key_exists("widget_add_btn", $context) ? $context["widget_add_btn"] : (function () { throw new RuntimeError('Variable "widget_add_btn" does not exist.', 635, $this->source); })());
            // line 636
            echo "        ";
            $this->displayBlock("collection_button", $context, $blocks);
            echo "
    ";
        }
        $___internal_db26cd653a02a141cb52956b462ec13555ee0d599da76f9fa8219eb7977af354_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 632
        echo twig_spaceless($___internal_db26cd653a02a141cb52956b462ec13555ee0d599da76f9fa8219eb7977af354_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 641
    public function block_form_widget_remove_btn($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_widget_remove_btn"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_widget_remove_btn"));

        // line 642
        ob_start();
        // line 643
        echo "    ";
        if ((twig_get_attribute($this->env, $this->source, ($context["widget_remove_btn"] ?? null), "wrapper_div", [], "any", true, true, false, 643) &&  !(twig_get_attribute($this->env, $this->source, (isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 643, $this->source); })()), "wrapper_div", [], "any", false, false, false, 643) === false))) {
            // line 644
            echo "        <div class=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 644, $this->source); })()), "wrapper_div", [], "any", false, false, false, 644), "class", [], "any", false, false, false, 644), "html", null, true);
            echo "\">
    ";
        }
        // line 646
        echo "    ";
        if ((twig_get_attribute($this->env, $this->source, ($context["widget_remove_btn"] ?? null), "horizontal_wrapper_div", [], "any", true, true, false, 646) &&  !(twig_get_attribute($this->env, $this->source, (isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 646, $this->source); })()), "horizontal_wrapper_div", [], "any", false, false, false, 646) === false))) {
            // line 647
            echo "        <div class=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 647, $this->source); })()), "horizontal_wrapper_div", [], "any", false, false, false, 647), "class", [], "any", false, false, false, 647), "html", null, true);
            echo "\">
    ";
        }
        // line 649
        echo "    ";
        if (((array_key_exists("widget_remove_btn", $context)) ? (_twig_default_filter((isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 649, $this->source); })()), null)) : (null))) {
            // line 650
            echo "    ";
            $context["button_type"] = "remove";
            // line 651
            echo "    ";
            $context["button_values"] = (isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 651, $this->source); })());
            // line 652
            echo "    ";
            $this->displayBlock("collection_button", $context, $blocks);
            echo "
    ";
        }
        // line 654
        echo "    ";
        if ((twig_get_attribute($this->env, $this->source, ($context["widget_remove_btn"] ?? null), "horizontal_wrapper_div", [], "any", true, true, false, 654) &&  !(twig_get_attribute($this->env, $this->source, (isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 654, $this->source); })()), "horizontal_wrapper_div", [], "any", false, false, false, 654) === false))) {
            // line 655
            echo "        </div>
    ";
        }
        // line 657
        echo "    ";
        if ((twig_get_attribute($this->env, $this->source, ($context["widget_remove_btn"] ?? null), "wrapper_div", [], "any", true, true, false, 657) &&  !(twig_get_attribute($this->env, $this->source, (isset($context["widget_remove_btn"]) || array_key_exists("widget_remove_btn", $context) ? $context["widget_remove_btn"] : (function () { throw new RuntimeError('Variable "widget_remove_btn" does not exist.', 657, $this->source); })()), "wrapper_div", [], "any", false, false, false, 657) === false))) {
            // line 658
            echo "        </div>
    ";
        }
        $___internal_bdab7c3965b776950671e10220fd79acf0a1f66da8796f877db5b065f1715c41_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 642
        echo twig_spaceless($___internal_bdab7c3965b776950671e10220fd79acf0a1f66da8796f877db5b065f1715c41_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 663
    public function block_collection_button($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "collection_button"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "collection_button"));

        // line 664
        echo "<a ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["button_values"]) || array_key_exists("button_values", $context) ? $context["button_values"] : (function () { throw new RuntimeError('Variable "button_values" does not exist.', 664, $this->source); })()), "attr", [], "any", false, false, false, 664));
        foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
            echo " ";
            echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
            echo "=\"";
            echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
            echo "\"";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo " data-collection-";
        echo twig_escape_filter($this->env, (isset($context["button_type"]) || array_key_exists("button_type", $context) ? $context["button_type"] : (function () { throw new RuntimeError('Variable "button_type" does not exist.', 664, $this->source); })()), "html", null, true);
        echo "-btn=\".";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 664, $this->source); })()), "vars", [], "any", false, false, false, 664), "id", [], "array", false, false, false, 664), "html", null, true);
        echo "_form_group\">
";
        // line 665
        if ( !(null === twig_get_attribute($this->env, $this->source, (isset($context["button_values"]) || array_key_exists("button_values", $context) ? $context["button_values"] : (function () { throw new RuntimeError('Variable "button_values" does not exist.', 665, $this->source); })()), "icon", [], "any", false, false, false, 665))) {
            // line 666
            echo "    ";
            echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, twig_get_attribute($this->env, $this->source, (isset($context["button_values"]) || array_key_exists("button_values", $context) ? $context["button_values"] : (function () { throw new RuntimeError('Variable "button_values" does not exist.', 666, $this->source); })()), "icon", [], "any", false, false, false, 666), ((twig_get_attribute($this->env, $this->source, ($context["button_values"] ?? null), "icon_inverted", [], "any", true, true, false, 666)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["button_values"] ?? null), "icon_inverted", [], "any", false, false, false, 666), false)) : (false)));
            echo "
";
        }
        // line 668
        if (twig_get_attribute($this->env, $this->source, ($context["button_values"] ?? null), "label", [], "any", true, true, false, 668)) {
            // line 669
            echo "    ";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["button_values"]) || array_key_exists("button_values", $context) ? $context["button_values"] : (function () { throw new RuntimeError('Variable "button_values" does not exist.', 669, $this->source); })()), "label", [], "any", false, false, false, 669), [], ((twig_get_attribute($this->env, $this->source, ($context["button_values"] ?? null), "translation_domain", [], "any", true, true, false, 669)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["button_values"] ?? null), "translation_domain", [], "any", false, false, false, 669), (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 669, $this->source); })()))) : ((isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 669, $this->source); })())))), "html", null, true);
            echo "
";
        }
        // line 671
        echo "</a>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 675
    public function block_label_asterisk($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "label_asterisk"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "label_asterisk"));

        // line 676
        if ((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 676, $this->source); })())) {
            // line 677
            if ((isset($context["render_required_asterisk"]) || array_key_exists("render_required_asterisk", $context) ? $context["render_required_asterisk"] : (function () { throw new RuntimeError('Variable "render_required_asterisk" does not exist.', 677, $this->source); })())) {
                echo "&nbsp;<span class=\"asterisk\">*</span>";
            }
        } else {
            // line 679
            if ((isset($context["render_optional_text"]) || array_key_exists("render_optional_text", $context) ? $context["render_optional_text"] : (function () { throw new RuntimeError('Variable "render_optional_text" does not exist.', 679, $this->source); })())) {
                echo "&nbsp;<span>";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("(optional)", [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 679, $this->source); })())), "html", null, true);
                echo "</span>";
            }
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 683
    public function block_widget_addon($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "widget_addon"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "widget_addon"));

        // line 684
        ob_start();
        // line 685
        $context["widget_addon_icon"] = ((twig_get_attribute($this->env, $this->source, ($context["widget_addon"] ?? null), "icon", [], "any", true, true, false, 685)) ? (twig_get_attribute($this->env, $this->source, (isset($context["widget_addon"]) || array_key_exists("widget_addon", $context) ? $context["widget_addon"] : (function () { throw new RuntimeError('Variable "widget_addon" does not exist.', 685, $this->source); })()), "icon", [], "any", false, false, false, 685)) : (null));
        // line 686
        $context["widget_addon_icon_inverted"] = ((twig_get_attribute($this->env, $this->source, ($context["widget_addon"] ?? null), "icon_inverted", [], "any", true, true, false, 686)) ? (twig_get_attribute($this->env, $this->source, (isset($context["widget_addon"]) || array_key_exists("widget_addon", $context) ? $context["widget_addon"] : (function () { throw new RuntimeError('Variable "widget_addon" does not exist.', 686, $this->source); })()), "icon_inverted", [], "any", false, false, false, 686)) : (false));
        // line 687
        echo "    <span class=\"input-group-addon\">";
        echo ((((twig_get_attribute($this->env, $this->source, ($context["widget_addon"] ?? null), "text", [], "any", true, true, false, 687)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["widget_addon"] ?? null), "text", [], "any", false, false, false, 687), false)) : (false))) ? ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["widget_addon"]) || array_key_exists("widget_addon", $context) ? $context["widget_addon"] : (function () { throw new RuntimeError('Variable "widget_addon" does not exist.', 687, $this->source); })()), "text", [], "any", false, false, false, 687), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 687, $this->source); })()))) : ($this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, (isset($context["widget_addon_icon"]) || array_key_exists("widget_addon_icon", $context) ? $context["widget_addon_icon"] : (function () { throw new RuntimeError('Variable "widget_addon_icon" does not exist.', 687, $this->source); })()), (isset($context["widget_addon_icon_inverted"]) || array_key_exists("widget_addon_icon_inverted", $context) ? $context["widget_addon_icon_inverted"] : (function () { throw new RuntimeError('Variable "widget_addon_icon_inverted" does not exist.', 687, $this->source); })()))));
        echo "</span>
";
        $___internal_d5e0db7444fbffe1fca504ea49447dd34b82e654e1129d5ef8789fe0cdb926ee_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 684
        echo twig_spaceless($___internal_d5e0db7444fbffe1fca504ea49447dd34b82e654e1129d5ef8789fe0cdb926ee_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 691
    public function block_widget_btns($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "widget_btns"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "widget_btns"));

        // line 692
        ob_start();
        // line 693
        echo "    <span class=\"input-group-btn\">
    ";
        // line 694
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["widget_btns"]) || array_key_exists("widget_btns", $context) ? $context["widget_btns"] : (function () { throw new RuntimeError('Variable "widget_btns" does not exist.', 694, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["widget_btn"]) {
            // line 695
            echo "        <button type=\"";
            echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->source, $context["widget_btn"], "type", [], "any", true, true, false, 695)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, $context["widget_btn"], "type", [], "any", false, false, false, 695), "button")) : ("button")), "html", null, true);
            echo "\" class=\"";
            echo twig_escape_filter($this->env, ("btn " . ((twig_get_attribute($this->env, $this->source, $context["widget_btn"], "class", [], "any", true, true, false, 695)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, $context["widget_btn"], "class", [], "any", false, false, false, 695), "btn-default")) : ("btn-default"))), "html", null, true);
            echo "\">
        ";
            // line 696
            if ( !twig_test_empty(twig_get_attribute($this->env, $this->source, $context["widget_btn"], "icon", [], "any", false, false, false, 696))) {
                // line 697
                echo "                ";
                echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, twig_get_attribute($this->env, $this->source, $context["widget_btn"], "icon", [], "any", false, false, false, 697), ((twig_get_attribute($this->env, $this->source, $context["widget_btn"], "icon_inverted", [], "any", true, true, false, 697)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, $context["widget_btn"], "icon_inverted", [], "any", false, false, false, 697), false)) : (false)));
                echo "
        ";
            }
            // line 699
            echo "        ";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((twig_get_attribute($this->env, $this->source, $context["widget_btn"], "label", [], "any", true, true, false, 699)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, $context["widget_btn"], "label", [], "any", false, false, false, 699), "")) : ("")), [], (isset($context["translation_domain"]) || array_key_exists("translation_domain", $context) ? $context["translation_domain"] : (function () { throw new RuntimeError('Variable "translation_domain" does not exist.', 699, $this->source); })())), "html", null, true);
            echo "</button>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['widget_btn'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 701
        echo "    </span>
";
        $___internal_039e89e3f315c32f5b8c2e79ece4536837447be327e67fb80a32a7a8cc1c2676_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 692
        echo twig_spaceless($___internal_039e89e3f315c32f5b8c2e79ece4536837447be327e67fb80a32a7a8cc1c2676_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 707
    public function block_form_errors($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "form_errors"));

        // line 708
        ob_start();
        // line 709
        if ((isset($context["error_delay"]) || array_key_exists("error_delay", $context) ? $context["error_delay"] : (function () { throw new RuntimeError('Variable "error_delay" does not exist.', 709, $this->source); })())) {
            // line 710
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 710, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 711
                echo "        ";
                if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 711), 1))) {
                    // line 712
                    echo "            ";
                    if (twig_get_attribute($this->env, $this->source, $context["child"], "set", [0 => "errors", 1 => (isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 712, $this->source); })())], "method", false, false, false, 712)) {
                    }
                    // line 713
                    echo "        ";
                }
                // line 714
                echo "    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 716
            echo "    ";
            if ((1 === twig_compare(twig_length_filter($this->env, (isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 716, $this->source); })())), 0))) {
                // line 717
                echo "        ";
                if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 717, $this->source); })()), "parent", [], "any", false, false, false, 717), null))) {
                    // line 718
                    echo "            ";
                    $macros["__internal_e36bb299e9d80ba3e13124ddce0324488fcc2aa218e8f660d91e875b11f23eeb"] = $this->loadTemplate("@MopaBootstrap/flash.html.twig", "@MopaBootstrap/Form/fields.html.twig", 718)->unwrap();
                    // line 719
                    echo "            ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 719, $this->source); })()));
                    foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                        // line 720
                        echo "                ";
                        echo twig_call_macro($macros["__internal_e36bb299e9d80ba3e13124ddce0324488fcc2aa218e8f660d91e875b11f23eeb"], "macro_flash", ["danger", twig_get_attribute($this->env, $this->source, $context["error"], "message", [], "any", false, false, false, 720)], 720, $context, $this->getSourceContext());
                        echo "
            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 722
                    echo "        ";
                } else {
                    // line 723
                    echo "            <span class=\"help-";
                    $this->displayBlock("error_type", $context, $blocks);
                    echo "\">
            ";
                    // line 724
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 724, $this->source); })()));
                    foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                        // line 725
                        echo "                ";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["error"], "message", [], "any", false, false, false, 725), "html", null, true);
                        echo " <br>
            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 727
                    echo "            </span>
        ";
                }
                // line 729
                echo "    ";
            }
        }
        $___internal_579381f9bb4e183f01c1d113b917246204b90f69f3653bc3a3a9a06bc99a7f66_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 708
        echo twig_spaceless($___internal_579381f9bb4e183f01c1d113b917246204b90f69f3653bc3a3a9a06bc99a7f66_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 736
    public function block_error_type($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "error_type"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "error_type"));

        // line 737
        ob_start();
        // line 738
        if ((isset($context["error_type"]) || array_key_exists("error_type", $context) ? $context["error_type"] : (function () { throw new RuntimeError('Variable "error_type" does not exist.', 738, $this->source); })())) {
            // line 739
            echo "    ";
            echo twig_escape_filter($this->env, (isset($context["error_type"]) || array_key_exists("error_type", $context) ? $context["error_type"] : (function () { throw new RuntimeError('Variable "error_type" does not exist.', 739, $this->source); })()), "html", null, true);
            echo "
";
        } elseif ((0 === twig_compare(twig_get_attribute($this->env, $this->source,         // line 740
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 740, $this->source); })()), "parent", [], "any", false, false, false, 740), null))) {
            // line 741
            echo "    ";
            echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 741), "error_type", [], "any", true, true, false, 741)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 741), "error_type", [], "any", false, false, false, 741), "inline")) : ("inline")), "html", null, true);
            echo "
";
        } else {
            // line 743
            echo "    block
";
        }
        $___internal_e4a550f45de4bc10f07697da635702df51c1d3a54cf4cd83a283b3ca1467af84_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 737
        echo twig_spaceless($___internal_e4a550f45de4bc10f07697da635702df51c1d3a54cf4cd83a283b3ca1467af84_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 750
    public function block_widget_form_group_start($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "widget_form_group_start"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "widget_form_group_start"));

        // line 751
        if ((((array_key_exists("widget_form_group", $context)) ? (_twig_default_filter((isset($context["widget_form_group"]) || array_key_exists("widget_form_group", $context) ? $context["widget_form_group"] : (function () { throw new RuntimeError('Variable "widget_form_group" does not exist.', 751, $this->source); })()), false)) : (false)) || (0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 751, $this->source); })()), "parent", [], "any", false, false, false, 751), null)))) {
            // line 752
            echo "    ";
            if (( !(null === twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 752, $this->source); })()), "parent", [], "any", false, false, false, 752)) && twig_in_filter("collection", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 752, $this->source); })()), "parent", [], "any", false, false, false, 752), "vars", [], "any", false, false, false, 752), "block_prefixes", [], "any", false, false, false, 752)))) {
                echo " ";
                // line 753
                echo "        ";
                if ( !(isset($context["omit_collection_item"]) || array_key_exists("omit_collection_item", $context) ? $context["omit_collection_item"] : (function () { throw new RuntimeError('Variable "omit_collection_item" does not exist.', 753, $this->source); })())) {
                    // line 754
                    echo "            ";
                    // line 755
                    echo "        \t";
                    $context["widget_form_group_attr"] = twig_array_merge((isset($context["widget_form_group_attr"]) || array_key_exists("widget_form_group_attr", $context) ? $context["widget_form_group_attr"] : (function () { throw new RuntimeError('Variable "widget_form_group_attr" does not exist.', 755, $this->source); })()), ["class" => "collection-item"]);
                    // line 756
                    echo "        ";
                }
                // line 757
                echo "    ";
            }
            // line 758
            echo "    ";
            if ((1 === twig_compare(twig_length_filter($this->env, (isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 758, $this->source); })())), 0))) {
                // line 759
                echo "\t    ";
                // line 760
                echo "\t    ";
                $context["widget_form_group_attr"] = twig_array_merge((isset($context["widget_form_group_attr"]) || array_key_exists("widget_form_group_attr", $context) ? $context["widget_form_group_attr"] : (function () { throw new RuntimeError('Variable "widget_form_group_attr" does not exist.', 760, $this->source); })()), ["class" => (((twig_get_attribute($this->env, $this->source, ($context["widget_form_group_attr"] ?? null), "class", [], "any", true, true, false, 760)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["widget_form_group_attr"] ?? null), "class", [], "any", false, false, false, 760), "")) : ("")) . " has-error")]);
                // line 761
                echo "    ";
            }
            // line 762
            echo "    ";
            if ((twig_get_attribute($this->env, $this->source, (isset($context["help_widget_popover"]) || array_key_exists("help_widget_popover", $context) ? $context["help_widget_popover"] : (function () { throw new RuntimeError('Variable "help_widget_popover" does not exist.', 762, $this->source); })()), "selector", [], "any", false, false, false, 762) === null)) {
                // line 763
                echo "        ";
                $context["help_widget_popover"] = twig_array_merge((isset($context["help_widget_popover"]) || array_key_exists("help_widget_popover", $context) ? $context["help_widget_popover"] : (function () { throw new RuntimeError('Variable "help_widget_popover" does not exist.', 763, $this->source); })()), ["selector" => ("#" . (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 763, $this->source); })()))]);
                // line 764
                echo "    ";
            }
            // line 765
            echo "    <div";
            if ( !(twig_get_attribute($this->env, $this->source, (isset($context["help_widget_popover"]) || array_key_exists("help_widget_popover", $context) ? $context["help_widget_popover"] : (function () { throw new RuntimeError('Variable "help_widget_popover" does not exist.', 765, $this->source); })()), "title", [], "any", false, false, false, 765) === null)) {
                $this->displayBlock("help_widget_popover", $context, $blocks);
            }
            echo " ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["widget_form_group_attr"]) || array_key_exists("widget_form_group_attr", $context) ? $context["widget_form_group_attr"] : (function () { throw new RuntimeError('Variable "widget_form_group_attr" does not exist.', 765, $this->source); })()));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">
    ";
            // line 767
            echo "    ";
            if (((((1 === twig_compare(twig_length_filter($this->env, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 767, $this->source); })())), 0)) && (0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 767, $this->source); })()), "parent", [], "any", false, false, false, 767), null))) && !twig_in_filter("field", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source,             // line 768
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 768, $this->source); })()), "vars", [], "any", false, false, false, 768), "block_prefixes", [], "any", false, false, false, 768))) && !twig_in_filter("date", twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source,             // line 769
(isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 769, $this->source); })()), "vars", [], "any", false, false, false, 769), "block_prefixes", [], "any", false, false, false, 769)))) {
                // line 770
                echo "        ";
                if ((isset($context["show_child_legend"]) || array_key_exists("show_child_legend", $context) ? $context["show_child_legend"] : (function () { throw new RuntimeError('Variable "show_child_legend" does not exist.', 770, $this->source); })())) {
                    // line 771
                    echo "            ";
                    $this->displayBlock("form_legend", $context, $blocks);
                    echo "
        ";
                } elseif (                // line 772
(isset($context["label_render"]) || array_key_exists("label_render", $context) ? $context["label_render"] : (function () { throw new RuntimeError('Variable "label_render" does not exist.', 772, $this->source); })())) {
                    // line 773
                    echo "            ";
                    echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 773, $this->source); })()), 'label', (twig_test_empty($_label_ = ((array_key_exists("label", $context)) ? (_twig_default_filter((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 773, $this->source); })()), null)) : (null))) ? [] : ["label" => $_label_]));
                    echo "
        ";
                } else {
                    // line 775
                    echo "        ";
                }
                // line 776
                echo "    ";
            } else {
                // line 777
                echo "        ";
                if ((isset($context["label_render"]) || array_key_exists("label_render", $context) ? $context["label_render"] : (function () { throw new RuntimeError('Variable "label_render" does not exist.', 777, $this->source); })())) {
                    // line 778
                    echo "            ";
                    echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 778, $this->source); })()), 'label', (twig_test_empty($_label_ = ((array_key_exists("label", $context)) ? (_twig_default_filter((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 778, $this->source); })()), null)) : (null))) ? [] : ["label" => $_label_]));
                    echo "
        ";
                }
                // line 780
                echo "    ";
            }
        } else {
            // line 782
            echo "    ";
            if ((isset($context["label_render"]) || array_key_exists("label_render", $context) ? $context["label_render"] : (function () { throw new RuntimeError('Variable "label_render" does not exist.', 782, $this->source); })())) {
                // line 783
                echo "        ";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 783, $this->source); })()), 'label', (twig_test_empty($_label_ = ((array_key_exists("label", $context)) ? (_twig_default_filter((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 783, $this->source); })()), null)) : (null))) ? [] : ["label" => $_label_]));
                echo "
    ";
            }
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 788
    public function block_help_widget_popover($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_widget_popover"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "help_widget_popover"));

        // line 789
        echo " ";
        ob_start();
        // line 790
        echo " ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["help_widget_popover"]) || array_key_exists("help_widget_popover", $context) ? $context["help_widget_popover"] : (function () { throw new RuntimeError('Variable "help_widget_popover" does not exist.', 790, $this->source); })()));
        foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
            // line 791
            echo " data-";
            echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
            echo "=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["attrvalue"], [], ((array_key_exists("domain", $context)) ? (_twig_default_filter((isset($context["domain"]) || array_key_exists("domain", $context) ? $context["domain"] : (function () { throw new RuntimeError('Variable "domain" does not exist.', 791, $this->source); })()), "messages")) : ("messages"))), "html", null, true);
            echo "\"
 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 793
        echo " ";
        $___internal_3e1100721656c745112ce3f59f173dbe8fbe79fcd3799da7bb14c9e063d65e78_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 789
        echo twig_spaceless($___internal_3e1100721656c745112ce3f59f173dbe8fbe79fcd3799da7bb14c9e063d65e78_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 796
    public function block_widget_form_group_end($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "widget_form_group_end"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "widget_form_group_end"));

        // line 797
        ob_start();
        // line 798
        if ((((array_key_exists("widget_form_group", $context)) ? (_twig_default_filter((isset($context["widget_form_group"]) || array_key_exists("widget_form_group", $context) ? $context["widget_form_group"] : (function () { throw new RuntimeError('Variable "widget_form_group" does not exist.', 798, $this->source); })()), false)) : (false)) || (0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 798, $this->source); })()), "parent", [], "any", false, false, false, 798), null)))) {
            // line 799
            echo "    </div>
";
        }
        $___internal_30d2786b52cc5a2fc48c0b0536677a961f829e508eaa9212faa7cd2983489ac0_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 797
        echo twig_spaceless($___internal_30d2786b52cc5a2fc48c0b0536677a961f829e508eaa9212faa7cd2983489ac0_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@MopaBootstrap/Form/fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  3186 => 797,  3181 => 799,  3179 => 798,  3177 => 797,  3167 => 796,  3157 => 789,  3154 => 793,  3143 => 791,  3138 => 790,  3135 => 789,  3125 => 788,  3110 => 783,  3107 => 782,  3103 => 780,  3097 => 778,  3094 => 777,  3091 => 776,  3088 => 775,  3082 => 773,  3080 => 772,  3075 => 771,  3072 => 770,  3070 => 769,  3069 => 768,  3067 => 767,  3047 => 765,  3044 => 764,  3041 => 763,  3038 => 762,  3035 => 761,  3032 => 760,  3030 => 759,  3027 => 758,  3024 => 757,  3021 => 756,  3018 => 755,  3016 => 754,  3013 => 753,  3009 => 752,  3007 => 751,  2997 => 750,  2987 => 737,  2982 => 743,  2976 => 741,  2974 => 740,  2969 => 739,  2967 => 738,  2965 => 737,  2955 => 736,  2945 => 708,  2940 => 729,  2936 => 727,  2927 => 725,  2923 => 724,  2918 => 723,  2915 => 722,  2906 => 720,  2901 => 719,  2898 => 718,  2895 => 717,  2892 => 716,  2877 => 714,  2874 => 713,  2870 => 712,  2867 => 711,  2849 => 710,  2847 => 709,  2845 => 708,  2835 => 707,  2825 => 692,  2821 => 701,  2812 => 699,  2806 => 697,  2804 => 696,  2797 => 695,  2793 => 694,  2790 => 693,  2788 => 692,  2778 => 691,  2768 => 684,  2762 => 687,  2760 => 686,  2758 => 685,  2756 => 684,  2746 => 683,  2731 => 679,  2726 => 677,  2724 => 676,  2714 => 675,  2702 => 671,  2696 => 669,  2694 => 668,  2688 => 666,  2686 => 665,  2666 => 664,  2656 => 663,  2646 => 642,  2641 => 658,  2638 => 657,  2634 => 655,  2631 => 654,  2625 => 652,  2622 => 651,  2619 => 650,  2616 => 649,  2610 => 647,  2607 => 646,  2601 => 644,  2598 => 643,  2596 => 642,  2586 => 641,  2576 => 632,  2569 => 636,  2566 => 635,  2563 => 634,  2560 => 633,  2558 => 632,  2548 => 631,  2538 => 620,  2531 => 626,  2528 => 625,  2522 => 623,  2519 => 622,  2512 => 621,  2510 => 620,  2500 => 619,  2490 => 608,  2483 => 612,  2481 => 611,  2475 => 609,  2473 => 608,  2463 => 607,  2453 => 570,  2447 => 600,  2441 => 598,  2439 => 597,  2436 => 596,  2432 => 594,  2430 => 593,  2427 => 592,  2421 => 590,  2418 => 589,  2416 => 588,  2413 => 587,  2403 => 586,  2400 => 585,  2394 => 583,  2392 => 582,  2389 => 581,  2386 => 580,  2383 => 579,  2381 => 578,  2375 => 576,  2372 => 575,  2361 => 574,  2359 => 573,  2354 => 572,  2351 => 571,  2349 => 570,  2339 => 569,  2329 => 555,  2322 => 565,  2316 => 563,  2312 => 562,  2307 => 561,  2301 => 558,  2298 => 557,  2295 => 556,  2293 => 555,  2283 => 554,  2270 => 551,  2260 => 550,  2246 => 546,  2242 => 545,  2237 => 544,  2227 => 543,  2214 => 540,  2211 => 539,  2201 => 538,  2189 => 534,  2183 => 532,  2180 => 531,  2174 => 529,  2172 => 528,  2164 => 527,  2161 => 526,  2151 => 525,  2138 => 522,  2135 => 521,  2125 => 520,  2113 => 516,  2107 => 514,  2104 => 513,  2098 => 511,  2096 => 510,  2090 => 509,  2087 => 508,  2077 => 507,  2064 => 504,  2054 => 503,  2043 => 456,  2039 => 498,  2035 => 496,  2033 => 495,  2030 => 494,  2024 => 492,  2021 => 491,  2015 => 489,  2012 => 488,  2006 => 486,  2003 => 485,  1997 => 483,  1995 => 482,  1991 => 481,  1989 => 480,  1973 => 479,  1970 => 478,  1964 => 476,  1961 => 475,  1958 => 474,  1955 => 473,  1952 => 472,  1949 => 471,  1946 => 470,  1943 => 469,  1940 => 468,  1936 => 465,  1933 => 462,  1932 => 461,  1931 => 460,  1929 => 459,  1926 => 458,  1923 => 457,  1921 => 456,  1919 => 455,  1909 => 454,  1899 => 439,  1889 => 450,  1885 => 447,  1882 => 444,  1881 => 443,  1880 => 442,  1878 => 441,  1875 => 440,  1873 => 439,  1863 => 438,  1853 => 420,  1845 => 430,  1842 => 429,  1839 => 428,  1837 => 427,  1830 => 426,  1824 => 424,  1821 => 423,  1818 => 422,  1816 => 421,  1814 => 420,  1804 => 419,  1794 => 413,  1788 => 415,  1785 => 414,  1783 => 413,  1773 => 412,  1763 => 406,  1757 => 408,  1754 => 407,  1752 => 406,  1742 => 405,  1732 => 374,  1725 => 399,  1721 => 398,  1717 => 397,  1713 => 396,  1708 => 395,  1705 => 394,  1702 => 393,  1696 => 391,  1690 => 388,  1685 => 387,  1682 => 386,  1679 => 385,  1676 => 384,  1674 => 383,  1668 => 381,  1666 => 380,  1658 => 379,  1635 => 378,  1632 => 377,  1629 => 376,  1626 => 375,  1624 => 374,  1614 => 373,  1604 => 339,  1600 => 360,  1597 => 368,  1591 => 366,  1588 => 365,  1582 => 363,  1580 => 362,  1575 => 361,  1572 => 360,  1569 => 359,  1562 => 356,  1556 => 353,  1551 => 352,  1548 => 351,  1545 => 350,  1542 => 349,  1540 => 348,  1534 => 346,  1532 => 345,  1526 => 344,  1505 => 343,  1502 => 342,  1499 => 341,  1497 => 340,  1495 => 339,  1485 => 338,  1475 => 306,  1469 => 332,  1467 => 331,  1466 => 330,  1465 => 329,  1464 => 328,  1461 => 327,  1458 => 326,  1451 => 323,  1445 => 320,  1440 => 319,  1437 => 318,  1434 => 317,  1431 => 316,  1429 => 315,  1423 => 313,  1421 => 312,  1415 => 311,  1394 => 310,  1391 => 309,  1388 => 308,  1386 => 307,  1384 => 306,  1374 => 305,  1364 => 257,  1361 => 302,  1357 => 300,  1354 => 299,  1351 => 298,  1347 => 296,  1341 => 294,  1335 => 292,  1332 => 291,  1329 => 290,  1326 => 289,  1323 => 288,  1320 => 287,  1318 => 286,  1305 => 285,  1298 => 283,  1284 => 282,  1281 => 281,  1278 => 280,  1275 => 279,  1272 => 278,  1269 => 277,  1266 => 276,  1263 => 275,  1260 => 274,  1256 => 272,  1253 => 271,  1249 => 270,  1247 => 269,  1244 => 268,  1240 => 265,  1237 => 262,  1236 => 261,  1235 => 260,  1233 => 259,  1230 => 258,  1227 => 257,  1217 => 256,  1207 => 204,  1204 => 253,  1200 => 251,  1197 => 250,  1193 => 248,  1190 => 247,  1184 => 246,  1180 => 244,  1178 => 243,  1173 => 242,  1167 => 240,  1161 => 238,  1158 => 237,  1155 => 236,  1152 => 235,  1150 => 234,  1146 => 233,  1140 => 232,  1125 => 231,  1122 => 230,  1119 => 229,  1116 => 228,  1113 => 227,  1110 => 226,  1107 => 225,  1104 => 224,  1101 => 223,  1094 => 221,  1090 => 220,  1087 => 219,  1082 => 218,  1078 => 216,  1075 => 215,  1072 => 214,  1068 => 212,  1065 => 211,  1062 => 210,  1059 => 209,  1056 => 208,  1053 => 207,  1050 => 206,  1047 => 205,  1044 => 204,  1034 => 203,  1020 => 199,  1014 => 197,  1011 => 196,  1008 => 195,  998 => 194,  988 => 164,  981 => 189,  978 => 188,  969 => 186,  964 => 185,  961 => 184,  946 => 182,  943 => 181,  940 => 180,  938 => 179,  935 => 178,  932 => 177,  929 => 176,  927 => 175,  924 => 174,  922 => 173,  921 => 172,  920 => 171,  919 => 170,  917 => 169,  914 => 168,  911 => 167,  908 => 166,  905 => 165,  903 => 164,  893 => 163,  880 => 159,  864 => 158,  861 => 157,  851 => 156,  841 => 137,  837 => 152,  829 => 149,  826 => 147,  824 => 146,  822 => 145,  820 => 144,  816 => 143,  812 => 142,  803 => 141,  800 => 140,  796 => 139,  791 => 138,  789 => 137,  779 => 136,  766 => 132,  764 => 131,  754 => 130,  744 => 105,  740 => 126,  735 => 125,  733 => 124,  728 => 122,  725 => 121,  721 => 119,  719 => 118,  714 => 116,  711 => 115,  704 => 112,  702 => 111,  699 => 110,  696 => 109,  691 => 108,  686 => 107,  683 => 106,  681 => 105,  671 => 104,  661 => 68,  656 => 99,  650 => 97,  647 => 96,  644 => 95,  638 => 93,  635 => 92,  632 => 91,  629 => 90,  623 => 88,  617 => 86,  614 => 85,  611 => 84,  608 => 83,  605 => 82,  602 => 81,  599 => 80,  593 => 78,  590 => 77,  587 => 76,  581 => 74,  578 => 73,  576 => 72,  573 => 71,  570 => 70,  567 => 69,  565 => 68,  555 => 67,  543 => 63,  537 => 61,  534 => 60,  531 => 59,  529 => 58,  524 => 57,  521 => 56,  518 => 55,  512 => 53,  509 => 52,  507 => 51,  504 => 50,  501 => 49,  498 => 48,  488 => 47,  478 => 30,  475 => 43,  469 => 40,  466 => 39,  459 => 35,  444 => 34,  441 => 33,  438 => 32,  435 => 31,  432 => 30,  422 => 29,  412 => 10,  406 => 25,  400 => 23,  398 => 22,  391 => 21,  387 => 18,  384 => 15,  383 => 14,  382 => 13,  380 => 12,  377 => 11,  375 => 10,  365 => 9,  352 => 6,  349 => 5,  339 => 4,  329 => 796,  326 => 795,  324 => 788,  321 => 787,  319 => 750,  316 => 749,  313 => 747,  311 => 736,  308 => 735,  305 => 733,  303 => 707,  300 => 706,  297 => 704,  295 => 691,  292 => 690,  290 => 683,  287 => 682,  285 => 675,  282 => 674,  280 => 663,  277 => 662,  275 => 641,  272 => 640,  270 => 631,  267 => 630,  265 => 619,  262 => 618,  259 => 616,  257 => 607,  254 => 606,  251 => 604,  249 => 569,  246 => 568,  244 => 554,  241 => 553,  239 => 550,  236 => 548,  234 => 543,  231 => 542,  229 => 538,  226 => 537,  224 => 525,  221 => 524,  219 => 520,  216 => 519,  214 => 507,  211 => 506,  209 => 503,  206 => 502,  204 => 454,  201 => 453,  199 => 438,  196 => 437,  193 => 435,  191 => 419,  188 => 418,  186 => 412,  183 => 411,  181 => 405,  178 => 404,  176 => 373,  173 => 372,  171 => 338,  168 => 337,  166 => 305,  163 => 304,  161 => 256,  158 => 255,  156 => 203,  153 => 202,  151 => 194,  148 => 193,  146 => 163,  143 => 162,  141 => 156,  138 => 155,  136 => 136,  133 => 135,  131 => 130,  128 => 129,  126 => 104,  123 => 103,  121 => 67,  118 => 66,  116 => 47,  113 => 45,  111 => 29,  108 => 28,  106 => 9,  103 => 8,  101 => 4,  98 => 2,  30 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% use 'form_div_layout.html.twig' %}

{# Buttons #}
{% block button_attributes %}
    {% set attr = attr|merge({class: 'btn ' ~ attr.class | default(\"btn-default\")}) %}
    {{ parent() }}
{% endblock button_attributes %}

{% block button_widget %}
{% apply spaceless %}
    {% if label is empty %}
        {%- if label_format is defined and label_format is not empty -%}
            {% set label = label_format|replace({
            '%name%': name,
            '%id%': id,
            }) %}
        {%- else -%}
            {% set label = name|humanize %}
        {%- endif -%}
    {% endif %}
    <button type=\"{{ type|default('button') }}\" {{ block('button_attributes') }}>
    {% if icon is not empty %}
            {{ mopa_bootstrap_icon(icon, icon_inverted|default(false)) }}
    {% endif %}
    {{ translation_domain is same as(false) ? label : label|trans({}, translation_domain) }}</button>
{% endapply %}
{% endblock button_widget %}

{% block button_row %}
    {% apply spaceless %}
        {% if button_offset is defined and button_offset is not empty %}
            {% set attr = attr|merge({'for': id, 'class': button_offset }) %}
            <div class=\"form-group\">
                <div {% for attrname, attrvalue in attr %} {{attrname}}=\"{{attrvalue}}\"{% endfor %}>
                {{ form_widget(form) }}
                </div>
            </div>
        {% else %}
            <div class=\"form-group\">
                {{ form_widget(form) }}
            </div>
        {% endif %}
    {% endapply %}
{% endblock button_row %}

{# Widgets #}
{% block textarea_widget %}
    {% set type = type|default('text') %}
    {% if type != 'hidden' and ( widget_addon_prepend|default(null) is not null or widget_addon_append|default(null) is not null ) %}
    <div class=\"input-group\">
        {% if widget_addon_prepend|default(null) is not null %}
            {% set widget_addon = widget_addon_prepend %}
            {{ block('widget_addon') }}
        {% endif %}
    {% endif %}
    {% set attr = attr|merge({'class': attr.class|default('') ~ ' ' ~ widget_form_control_class}) %}
    {{ parent() }}
    {% if type != 'hidden' and ( widget_addon_prepend|default(null) is not null or widget_addon_append|default(null) is not null ) %}
        {% if widget_addon_append|default(null) is not null %}
        {% set widget_addon = widget_addon_append %}
        {{ block('widget_addon') }}
        {% endif %}
    </div>
    {% endif %}
{% endblock textarea_widget %}

{% block form_widget_simple %}
{% apply spaceless %}
    {% set type = type|default('text') %}
    {% if type != 'hidden' and ( widget_addon_prepend|default(null) is not null or widget_addon_append|default(null) is not null or widget_btn_prepend|default(null) is not null or widget_btn_append|default(null) is not null ) %}
    <div class=\"input-group\">
        {% if widget_btn_prepend|default(null) is not null %}
            {% set widget_btns = widget_btn_prepend %}
            {{ block('widget_btns') }}
        {% endif %}
        {% if widget_addon_prepend|default(null) is not null %}
            {% set widget_addon = widget_addon_prepend %}
            {{ block('widget_addon') }}
        {% endif %}
    {% endif %}
    {% if not widget_remove_btn|default(null) %}
        {% set attr = attr|merge({'class': attr.class|default('') ~ ' not-removable'}) %}
    {% endif %}
    {% set attr = attr|merge({'class': (attr.class|default('') ~ ' ' ~ widget_form_control_class)|trim}) %}
    {% if static_text is same as(true) %}
        <p class=\"form-control-static\">{{ value }}</p>
    {% else %}
        {{ parent() }}
    {% endif %}
    {% if type != 'hidden' and ( widget_addon_prepend|default(null) is not null or widget_addon_append|default(null) is not null or widget_btn_prepend|default(null) is not null or widget_btn_append|default(null) is not null ) %}
        {% if widget_addon_append|default(null) is not null %}
            {% set widget_addon = widget_addon_append %}
            {{ block('widget_addon') }}
        {% endif %}
        {% if widget_btn_append|default(null) is not null %}
            {% set widget_btns = widget_btn_append %}
            {{ block('widget_btns') }}
        {% endif %}
    </div>
    {% endif %}
{% endapply %}
{% endblock form_widget_simple %}

{% block form_widget_compound %}
{% apply spaceless %}
    {% if form.parent == null %}
        {% if render_fieldset %}<fieldset>{% endif %}
        {% if show_legend %}{{ block('form_legend') }}{% endif %}
    {% endif %}

    {% if form.vars.tabbed %}
        {{ form_tabs(form) }}
        <div class=\"tab-content\">
    {% endif %}

    {{ block('form_rows_visible') }}

    {% if form.vars.tabbed %}
        </div>
    {% endif %}

    {{ form_rest(form) }}

    {% if form.parent == null %}
        {% if render_fieldset %}</fieldset>{% endif %}
    {% endif %}
{% endapply %}
{% endblock form_widget_compound %}

{% block form_tabs %}
{% if form.vars.tabsView is defined %}
{{ form_widget(form.vars.tabsView) }}
{% endif %}
{% endblock %}

{% block tabs_widget %}
{% apply spaceless %}
<ul class=\"{{ form.vars.attr.class }}\">
    {% for tab in form.vars.tabs %}
        {% set class = ((tab.active ? 'active ' : '') ~ (tab.disabled ? 'disabled' : ''))|trim %}
        <li{% if class|trim is not empty %} class=\"{{ class }}\"{% endif %}>
            <a data-toggle=\"tab\" href=\"#{{ tab.id }}\">
                {% if tab.icon %}{{ mopa_bootstrap_icon(tab.icon) }}{% endif %}
                {%- if tab.label is not empty -%}
                    {{ tab.translation_domain is same as(false) ? tab.label : tab.label|trans({}, tab.translation_domain) }}
                {%- elseif tab.label is not same as(false) -%}
                    {{ tab.translation_domain is same as(false) ? tab.name|humanize : tab.name|humanize|trans({}, tab.translation_domain) }}
                {%- endif -%}
            </a>
        </li>
    {% endfor %}
</ul>
{% endapply %}
{% endblock %}

{% block form_tab %}
    {% set tab_attr = attr|merge({'class': ('tab-pane' ~ (form.vars.tab_active ? ' active' : '') ~ ' ' ~ attr.class|default(''))|trim, 'id': id}) %}
    <div{% for attrname, attrvalue in tab_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}>
        {{ block('form_widget') }}
    </div>
{% endblock %}

{% block collection_widget %}
{% apply spaceless %}
    {% if prototype is defined %}
        {% set prototype_markup = form_row(prototype) %}
        {% set data_prototype_name = form.vars.form.vars.prototype.vars.name|default('__name__') %}
        {% set data_prototype_label = form.vars.form.vars.prototype.vars.label|default('__name__label__') %}
        {% set widget_form_group_attr = widget_form_group_attr|merge({
            'data-prototype': prototype_markup,
            'data-prototype-name': data_prototype_name,
            'data-prototype-label': data_prototype_label
        })|merge(attr) %}
    {% endif %}
    {# Add row by default use attr.class to change#}
\t{% if 'collection' in form.vars.block_prefixes and attr.class is defined %}
\t\t{% set widget_form_group_attr = widget_form_group_attr|merge({'class': widget_form_group_attr.class|default('row') ~ ' ' ~ attr.class}) %}
\t{% endif %}
    {# collection item adds class {form_id}_form-group  too #}
    {% set widget_form_group_attr = widget_form_group_attr|merge({'id': 'collection' ~ id ~ '_form_group', 'class': widget_form_group_attr.class ~ ' collection-items ' ~ id ~ '_form_group'}) %}

    <div {% for attrname,attrvalue in widget_form_group_attr %} {{attrname}}=\"{{attrvalue}}\"{% endfor %}>
    {# Add initial prototype form #}
    {% if form.vars.value|length == 0 and prototype is defined %}
        {% for name in prototype_names %}
            {{ prototype_markup|replace({'__name__': name})|raw }}
        {% endfor %}
    {% endif %}
    {{ block('form_widget') }}
    </div>
{% endapply %}
{% endblock collection_widget %}

{% block choice_widget_collapsed %}
    {% set attr = attr|merge({'class': attr.class|default('') ~ ' ' ~ widget_form_control_class}) %}
    {% if widget_type == 'inline-btn' %}
        {{ block('choice_widget_expanded') }}
    {% else %}
        {{ parent() }}
    {% endif %}
{% endblock choice_widget_collapsed %}

{% block choice_widget_expanded %}
    {% apply spaceless %}
        {% set tagName = 'label' %}
        {% set label_attr = label_attr|merge({'class': (label_attr.class|default(''))}) %}
        {% set label_attr = label_attr|merge({'class': (label_attr.class ~ ' ' ~ (widget_type != '' ? (multiple ? 'checkbox' : 'radio') ~ '-' ~ widget_type : ''))}) %}
        {% if expanded %}
            {% set attr = attr|merge({'class': attr.class|default('') ~ ' ' ~ horizontal_input_wrapper_class}) %}
        {% endif %}
        {% if layout is same as(false) %}
            <div>
        {% endif %}
        {% if widget_type == 'inline-btn' %}
            {% set tagName = 'button' %}
            <div class=\"btn-group\" data-toggle=\"buttons\">
        {% endif %}
        {% for child in form %}
            {% if widget_type not in ['inline', 'inline-btn'] %}
                <div class=\"{{ multiple ? 'checkbox' : 'radio' }}\"
                {%- if widget_type == 'inline-btn' %} class=\"btn-group\" data-toggle=\"buttons\"{% endif %}>
            {% endif %}
            {% if widget_type == 'inline-btn' %}
                {% set label_attr = label_attr|default({})|merge({'class': 'btn ' ~ label_attr.class|default('')}) %}
            {% endif %}
            {% if child.vars.checked and widget_type == 'inline-btn' %}
                {% set label_attr_copy = label_attr|default({})|merge({'class': 'active ' ~ label_attr.class|default('')}) %}
            {% else %}
                {% set label_attr_copy = label_attr|default({}) %}
            {% endif %}
            <{{ tagName }}{% for attrname, attrvalue in label_attr_copy %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}
            {%- if disabled %} disabled=\"disabled\"{% endif -%}>
            {{ form_widget(child, {'horizontal_label_class': horizontal_label_class, 'horizontal_input_wrapper_class': horizontal_input_wrapper_class, 'attr': {'class': attr.widget_class|default('') }}) }}
            {% if choice_translation_domain is not defined %}
                {% set choice_translation_domain = translation_domain %}
            {% endif %}
            {% if widget_type == 'inline-btn' or widget_checkbox_label == 'widget'%}
                {{ choice_translation_domain is same as(false) ? child.vars.label|raw : child.vars.label|trans({}, choice_translation_domain)|raw }}
            {% else %}
                {{ choice_translation_domain is same as(false) ? child.vars.label : child.vars.label|trans({}, choice_translation_domain) }}
            {% endif %}
            </{{ tagName }}>
            {% if widget_type not in ['inline', 'inline-btn'] %}
                </div>
            {% endif %}
        {% endfor %}
        {% if widget_type == 'inline-btn' %}
            </div>
        {% endif %}
        {% if layout is same as(false) %}
            </div>
        {% endif %}
    {% endapply %}
{% endblock choice_widget_expanded %}

{% block checkbox_widget %}
    {% apply spaceless %}
        {% if label is not same as(false) and label is empty %}
            {%- if label_format is defined and label_format is not empty -%}
                {% set label = label_format|replace({
                '%name%': name,
                '%id%': id,
                }) %}
            {%- else -%}
                {% set label = name|humanize %}
            {%- endif -%}
        {% endif %}
        {% if form.parent != null and 'choice' not in form.parent.vars.block_prefixes %}
            <div
            {%- if widget_type == 'inline-btn' %} class=\"btn-group\" data-toggle=\"buttons\"
            {%- else %} class=\"checkbox\"
            {%- endif %}>
        {% endif %}
        {% if form.parent != null and 'choice' not in form.parent.vars.block_prefixes and label_render %}
            {% if widget_type == 'inline-btn' %}
                {% set default_class = 'btn btn-primary' %}
                {% set label_attr = attr|default({'class': default_class}) %}
                {% if checked %}
                    {% set label_attr = label_attr|merge({'class': 'active ' ~ attr.class|default(default_class)}) %}
                {% endif %}
            {% endif %}
            <label{% for attrname, attrvalue in label_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}
            {%- if layout == 'inline' %} class=\"checkbox-inline\"{% endif %}>
        {% endif %}
        <input type=\"checkbox\" {{ block('widget_attributes') }}{% if value is defined %} value=\"{{ value }}\"{% endif %}{% if checked %} checked=\"checked\"{% endif %}/>
        {% if form.parent != null and 'choice' not in form.parent.vars.block_prefixes %}
            {% if label_render %}
                {% if widget_checkbox_label in ['both', 'widget'] %}
                    {% if choice_translation_domain is not defined %}
                        {% set choice_translation_domain = translation_domain %}
                    {% endif %}
                    {{ choice_translation_domain is same as(false) ? label|raw : label|trans({}, choice_translation_domain)|raw }}
                {% else %}
                    {{ block('form_help') }}
                {% endif %}
                </label>
            {% endif %}
        {% endif %}
        {% if form.parent != null and 'choice' not in form.parent.vars.block_prefixes %}
            </div>
        {% endif %}
    {% endapply %}
{% endblock checkbox_widget %}

{% block date_widget %}
{% apply spaceless %}
{% if widget == 'single_text' %}
    {% if datepicker is defined %}
        {% set widget_addon_icon = widget_addon_append.icon is defined ? widget_addon_append.icon : 'calendar'  %}
        <div {% if datepicker.attr is defined %}{%- for attrname, attrvalue in datepicker.attr %}{{ attrname }}=\"{{ attrvalue }}\" {% endfor %}{% endif %} data-provider=\"datepicker\" class=\"input-group date\" data-date=\"{{ value }}\" data-link-field=\"{{ id }}\" data-link-format=\"yyyy-mm-dd\">
            <input type=\"hidden\" value=\"{{ value }}\" {{ block('widget_attributes') }}>
            {% if widget_reset_icon is defined and widget_reset_icon == true %}
                <span class=\"input-group-addon\">{{ mopa_bootstrap_icon('remove') }}</span>
            {% endif %}
            {# Clear the id & name attributes so that they don't override the hidden fields values #}
            {% set id = id ~ '_mopa_picker_display' %}
            {% set full_name = null %}
            {% set type = 'text' %}
            {{ block('form_widget_simple') }}
            <span class=\"input-group-addon\">{{ mopa_bootstrap_icon(widget_addon_icon) }}</span>
        </div>
    {% else %}
        {{ block('form_widget_simple') }}
    {% endif %}
{% else %}
    {% set attr = attr|merge({'class': attr.class|default('inline')}) %}
    \t<div class=\"row\">
        {{ date_pattern|replace({
            '{{ year }}':  '<div class=\"'~date_wrapper_class['year']|default('col-xs-4')~'\">'~form_widget(form.year, {'attr': {'class': attr.widget_class|default('') ~ ''}})~'</div>',
            '{{ month }}': '<div class=\"'~date_wrapper_class['month']|default('col-xs-4')~'\">'~form_widget(form.month, {'attr': {'class': attr.widget_class|default('') ~ ''}})~'</div>',
            '{{ day }}':   '<div class=\"'~date_wrapper_class['day']|default('col-xs-4')~'\">'~form_widget(form.day, {'attr': {'class': attr.widget_class|default('') ~ ''}})~'</div>',
        })|raw }}
        </div>
{% endif %}
{% endapply %}
{% endblock date_widget %}

{% block time_widget %}
{% apply spaceless %}
{% if widget == 'single_text' %}
    {% if timepicker is defined %}
        {% set widget_addon_icon = widget_addon_append.icon is defined ? widget_addon_append.icon : 'time'  %}
        <div {% if timepicker.attr is defined %}{%- for attrname, attrvalue in timepicker.attr %}{{ attrname }}=\"{{ attrvalue }}\" {% endfor %}{% endif %} data-provider=\"timepicker\" class=\"input-group date\" data-date=\"{{ value }}\" data-link-field=\"{{ id }}\" data-link-format=\"hh:ii\">
            <input type=\"hidden\" value=\"{{ value }}\" {{ block('widget_attributes') }}>
            {% if widget_reset_icon is defined and widget_reset_icon == true %}
                <span class=\"input-group-addon\">{{ mopa_bootstrap_icon('remove') }}</span>
            {% endif %}
            {# Clear the id & name attributes so that they don't override the hidden fields values #}
            {% set id = id ~ '_mopa_picker_display' %}
            {% set full_name = null %}
            {% set type = 'text' %}
            {{ block('form_widget_simple') }}
            <span class=\"input-group-addon\">{{ mopa_bootstrap_icon(widget_addon_icon) }}</span>
        </div>
    {% else %}
        {{ block('form_widget_simple') }}
    {% endif %}
{% else %}
    {% set attr = attr|merge({'class': attr.class|default('')}) %}
    {% apply spaceless %}
    {{ form_widget(form.hour, { 'horizontal_input_wrapper_class': horizontal_input_wrapper_class|default('col-sm-2')}) }}
    {% if with_minutes %}
        {{ form_widget(form.minute, { 'horizontal_input_wrapper_class': horizontal_input_wrapper_class|default('col-sm-2')}) }}
    {% endif %}
    {% if with_seconds %}
        :{{ form_widget(form.second, { 'horizontal_input_wrapper_class': horizontal_input_wrapper_class|default('col-sm-2') }) }}
    {% endif %}
    {% endapply %}
{% endif %}
{% endapply %}
{% endblock time_widget %}

{% block datetime_widget %}
{% apply spaceless %}
    {% if widget == 'single_text' %}
        {% if datetimepicker is defined %}
            {% set widget_addon_icon = widget_addon_append.icon is defined ? widget_addon_append.icon : 'th'  %}
            <div {% if datetimepicker.attr is defined %}{%- for attrname, attrvalue in datetimepicker.attr %}{{ attrname }}=\"{{ attrvalue }}\" {% endfor %}{% endif %} data-provider=\"datetimepicker\" class=\"input-group date\" data-date=\"{% if value %}{{ value|date('Y-m-d H:i') }}{% endif %}\" data-link-field=\"{{ id }}\" data-link-format=\"yyyy-mm-dd hh:ii\">
                <input type=\"hidden\" value=\"{% if value %}{{ value|date('Y-m-d H:i') }}{% endif %}\" {{ block('widget_attributes') }}>
                {% if widget_reset_icon is defined and widget_reset_icon == true %}
                    <span class=\"input-group-addon\">{{ mopa_bootstrap_icon('remove') }}</span>
                {% endif %}
                {# Clear the id & name attributes so that they don't override the hidden fields values #}
                {% set id = id ~ '_mopa_picker_display' %}
                {% set full_name = null %}
                {% set type = 'text' %}
                {{ block('form_widget_simple') }}
                <span class=\"input-group-addon\">{{ mopa_bootstrap_icon(widget_addon_icon) }}</span>
            </div>
        {% else %}
            {{ block('form_widget_simple') }}
        {% endif %}
    {% else %}
            {% set attr = attr|merge({'class': attr.class|default('')}) %}
            <div {{ block('widget_container_attributes') }}>
                {{ form_errors(form.date) }}
                {{ form_errors(form.time) }}
                {{ form_widget(form.date, {'attr': {'class': attr.widget_class|default('')}, 'horizontal_input_wrapper_class': horizontal_input_wrapper_class|default('col-sm-3')}) }}
                {{ form_widget(form.time, {'attr': {'class': attr.widget_class|default('')}, 'horizontal_input_wrapper_class': horizontal_input_wrapper_class|default('col-sm-2')}) }}
            </div>
    {% endif %}
{% endapply %}
{% endblock datetime_widget %}

{% block percent_widget %}
{% apply spaceless %}
    {% set widget_addon_append = widget_addon_append|merge({'text': widget_addon_append.text|default('%')}) %}
    {{ block('form_widget_simple') }}
{% endapply %}
{% endblock percent_widget %}

{% block money_widget %}
{% apply spaceless %}
    {% set widget_addon_prepend = (widget_addon_prepend != false or widget_addon_prepend == null) and money_pattern != '{{ widget }}' ? {'text': money_pattern|replace({ '{{ widget }}': ''})|trim} : widget_addon_prepend|default(null) %}
    {{ block('form_widget_simple') }}
{% endapply %}
{% endblock money_widget %}

{% block file_widget %}
{% apply spaceless %}
{% set type = type|default('file') %}
    {% if widget_addon_prepend|default(null) is not null %}
        {% set widget_addon = widget_addon_prepend %}
        {{ block('widget_addon') }}
    {% endif %}
<input type=\"{{ type }}\" {{ block('widget_attributes') }}/>
{% if type != 'hidden' and widget_addon.type|default(null) is not null %}
    {% if widget_addon_append|default(null) is not null %}
        {% set widget_addon = widget_addon_append %}
        {{ block('widget_addon') }}
    {% endif %}
{% endif %}
{% endapply %}
{% endblock file_widget %}

{# Labels #}

{% block form_legend %}
{% apply spaceless %}
    {% if label is empty %}
        {%- if label_format is defined and label_format is not empty -%}
            {% set label = label_format|replace({
            '%name%': name,
            '%id%': id,
            }) %}
        {%- else -%}
            {% set label = name|humanize %}
        {%- endif -%}
    {% endif %}
    <{{ legend_tag }}>{{ translation_domain is same as(false) ? label : label|trans({}, translation_domain) }}</{{ legend_tag }}>
{% endapply %}
{% endblock form_legend %}

{% block form_label %}
{% if 'checkbox' not in block_prefixes or widget_checkbox_label in ['label', 'both'] %}
{% apply spaceless %}
    {% if label is not same as(false) %}
        {% if label is empty %}
            {%- if label_format is defined and label_format is not empty -%}
                {% set label = label_format|replace({
                '%name%': name,
                '%id%': id,
                }) %}
            {%- else -%}
                {% set label = name|humanize %}
            {%- endif -%}
        {% endif %}
        {% if not compound %}
            {% set label_attr = label_attr|merge({'for': id}) %}
        {% endif %}
        {% set label_attr_class = '' %}
        {% if layout == 'horizontal' %}
            {% set label_attr_class = 'control-label ' ~ label_attr_class ~ horizontal_label_class %}
        {% endif %}
        {% if horizontal_label_div_class %}
        <div class=\"{{ horizontal_label_div_class }}\">
        {% endif %}
        {% set label_attr = label_attr|merge({'class': (label_attr.class|default('') ~ \" \" ~ label_attr_class ~ (required ? ' required' : ' optional'))|trim }) %}
        <label{% for attrname,attrvalue in label_attr %} {{attrname}}=\"{{attrvalue}}\"{% endfor %}>
        {{ translation_domain is same as(false) ? label : label|trans({}, translation_domain) }}
        {{- block('label_asterisk') }}
        {% if 'collection' in form.vars.block_prefixes and widget_add_btn|default(null) and form.vars.allow_add == true %}
            &nbsp;{{ block('form_widget_add_btn') }}
        {% endif %}
        {% if help_label %}
            {{ block('help_label') }}
        {% endif %}
        {% if help_label_tooltip.title %}
            {{ block('help_label_tooltip') }}
        {% endif %}
        {% if help_label_popover.title %}
            {{ block('help_label_popover') }}
        {% endif %}
        </label>
        {% if horizontal_label_div_class %}
        </div>
        {% endif %}
    {% endif %}
{% endapply %}
{% endif %}
{% endblock form_label %}

{% block help_label %}
    <span class=\"help-block\">{{ help_label|trans({}, translation_domain) }}</span>
{% endblock help_label %}

{% block help_label_tooltip %}
    <span class=\"help-block\">
        <a href=\"#\" data-toggle=\"tooltip\" data-placement=\"{{ help_label_tooltip.placement}}\" data-title=\"{{ help_label_tooltip.title|trans({}, translation_domain) }}\">
            {% if help_label_tooltip.icon is not same as(false) %}
                {{ mopa_bootstrap_icon(help_label_tooltip.icon) }}
            {% endif %}
            {% if help_label_tooltip.text is not same as(null) %}
                {{ help_label_tooltip.text }}
            {% endif %}
        </a>
    </span>
{% endblock help_label_tooltip %}

{% block help_block_tooltip %}
    {% set help_label_tooltip = help_block_tooltip %}
    {{ block('help_label_tooltip') }}
{% endblock help_block_tooltip %}

{% block help_label_popover %}
    <span class=\"help-block\">
        <a href=\"#\" data-toggle=\"popover\" data-trigger=\"hover\" data-placement=\"{{ help_label_popover.placement}}\" data-title=\"{{ help_label_popover.title|trans({}, translation_domain) }}\" data-content=\"{{ help_label_popover.content|trans({}, translation_domain) }}\" data-html=\"true\">
            {% if help_label_popover.icon is not same as(false) %}
                {{ mopa_bootstrap_icon(help_label_popover.icon) }}
            {% endif %}
            {% if help_label_popover.text is not same as(null) %}
                {{ help_label_popover.text|raw }}
            {% endif %}
        </a>
    </span>
{% endblock help_label_popover %}

{% block help_block_popover %}
    {% set help_label_popover = help_block_popover %}
    {{ block('help_label_popover') }}
{% endblock help_block_popover %}

{% block form_actions_widget %}
    {% for button in form.children %}
        {{ form_widget(button) }}&nbsp; {# this needs to be here due to https://github.com/twbs/bootstrap/issues/3245 #}
    {% endfor  %}
{% endblock %}

{# Rows #}
{% block form_actions_row %}
    {{ block('button_row')  }}
{% endblock %}

{% block form_rows_visible %}
{% apply spaceless %}
     {% if errors|length > 0 %}
        <div class=\"symfony-form-errors\">
            {{ form_errors(form) }}
        </div>
    {% endif %}
    {% for child in form %}
        {% if 'hidden' not in child.vars.block_prefixes %} {# smbdy: why do we not add the hiddens of childs? 131024 phiamo: i think form rest should do this !? it was afaik removed because it cause side effekts #}
            {{ form_row(child) }}
        {% endif %}
    {% endfor %}
{% endapply %}
{% endblock form_rows_visible %}

{% block form_row %}
{% apply spaceless %}
    {% if 'tab' in form.vars.block_prefixes %}
        {{ block('form_tab') }}
    {% elseif embed_form is same as(true) %}
        {% if widget_prefix is not empty %}{{ widget_prefix|trans({}, translation_domain)|raw }}{% endif %} {{ form_widget(form, _context) }} {% if widget_suffix is not empty %}{{ widget_suffix|trans({}, translation_domain)|raw }}{% endif %}
    {% else %}
        {{ block('widget_form_group_start') }}

        {% if layout == 'horizontal' and not label_render %}
            {% set horizontal_input_wrapper_class = horizontal_input_wrapper_class ~ ' ' ~ horizontal_label_offset_class %}
        {% endif %}

        {% if horizontal %}
        <div class=\"{{ horizontal_input_wrapper_class }}\">
        {% endif %}

        {% if widget_prefix is not empty %}{{ widget_prefix|trans({}, translation_domain)|raw }}{% endif %} {{ form_widget(form, _context) }} {% if widget_suffix is not empty %}{{ widget_suffix|trans({}, translation_domain)|raw }}{% endif %}

        {% set type = type|default('text') %}
        {% if type != 'hidden' %}
        {{ block('form_message') }}
        {% endif %}

        {% if horizontal %}
        </div>
        {% endif %}

        {% if form.parent is not null and 'collection' in form.parent.vars.block_prefixes and widget_remove_btn|default(null) and form.parent.vars.allow_delete|default(false) %}
            {{ block('form_widget_remove_btn') }}
        {% endif -%}
        {{ block('widget_form_group_end') }}
    {% endif %}
{% endapply %}
{% endblock form_row %}

{# Support #}

{% block form_message %}
{% apply spaceless %}
    {{ form_errors(form) }}

    {% if ('checkbox' not in block_prefixes or widget_checkbox_label != 'label') and help_block %}
        {{ block('form_help') }}
    {% endif %}
{% endapply %}
{% endblock form_message %}

{# Help #}

{% block form_help %}
{% apply spaceless %}
    {% if help_block %}<p class=\"help-block\">{{ help_block|trans({}, translation_domain)|raw }}</p>{%endif %}
    {% if help_block_tooltip.title %}
        &nbsp;{{ block('help_block_tooltip') }}
    {% endif %}
    {% if help_block_popover.title %}
        &nbsp;{{ block('help_block_popover') }}
    {% endif %}
{% endapply %}
{% endblock form_help %}

{% block form_widget_add_btn %}
{% apply spaceless %}
    {% if widget_add_btn|default(null) %}
        {% set button_type = 'add' %}
        {% set button_values = widget_add_btn %}
        {{ block('collection_button') }}
    {% endif %}
{% endapply %}
{% endblock form_widget_add_btn %}

{% block form_widget_remove_btn %}
{% apply spaceless %}
    {% if widget_remove_btn.wrapper_div is defined and widget_remove_btn.wrapper_div is not same as(false) %}
        <div class=\"{{ widget_remove_btn.wrapper_div.class }}\">
    {% endif %}
    {% if widget_remove_btn.horizontal_wrapper_div is defined and widget_remove_btn.horizontal_wrapper_div is not same as(false) %}
        <div class=\"{{ widget_remove_btn.horizontal_wrapper_div.class }}\">
    {% endif %}
    {% if widget_remove_btn|default(null) %}
    {% set button_type = 'remove' %}
    {% set button_values = widget_remove_btn %}
    {{ block('collection_button') }}
    {% endif %}
    {% if widget_remove_btn.horizontal_wrapper_div is defined and widget_remove_btn.horizontal_wrapper_div is not same as(false) %}
        </div>
    {% endif %}
    {% if widget_remove_btn.wrapper_div is defined and widget_remove_btn.wrapper_div is not same as(false) %}
        </div>
    {% endif %}
{% endapply %}
{% endblock form_widget_remove_btn %}

{% block collection_button %}
<a {% for attrname,attrvalue in button_values.attr %} {{attrname}}=\"{{attrvalue}}\"{% endfor %} data-collection-{{ button_type }}-btn=\".{{ form.vars['id'] }}_form_group\">
{% if button_values.icon is not null %}
    {{ mopa_bootstrap_icon(button_values.icon, button_values.icon_inverted|default(false)) }}
{% endif %}
{% if button_values.label is defined %}
    {{ button_values.label|trans({}, button_values.translation_domain|default(translation_domain)) }}
{% endif %}
</a>

{% endblock collection_button %}

{% block label_asterisk %}
{% if required %}
    {%- if render_required_asterisk %}&nbsp;<span class=\"asterisk\">*</span>{% endif %}
{% else %}
    {%- if render_optional_text %}&nbsp;<span>{{ \"(optional)\"|trans({}, translation_domain) }}</span>{% endif %}
{% endif %}
{% endblock label_asterisk %}

{% block widget_addon %}
{% apply spaceless %}
{% set widget_addon_icon = widget_addon.icon is defined ? widget_addon.icon : null  %}
{% set widget_addon_icon_inverted = widget_addon.icon_inverted is defined ? widget_addon.icon_inverted : false  %}
    <span class=\"input-group-addon\">{{ (widget_addon.text|default(false) ? widget_addon.text|trans({}, translation_domain)|raw : mopa_bootstrap_icon(widget_addon_icon, widget_addon_icon_inverted)) }}</span>
{% endapply %}
{% endblock widget_addon %}

{% block widget_btns %}
{% apply spaceless %}
    <span class=\"input-group-btn\">
    {% for widget_btn in widget_btns %}
        <button type=\"{{ widget_btn.type | default('button') }}\" class=\"{{ 'btn ' ~ widget_btn.class | default('btn-default') }}\">
        {% if widget_btn.icon is not empty %}
                {{ mopa_bootstrap_icon(widget_btn.icon, widget_btn.icon_inverted | default(false)) }}
        {% endif %}
        {{ widget_btn.label | default(\"\") | trans({}, translation_domain) }}</button>
    {% endfor %}
    </span>
{% endapply %}
{% endblock widget_btns %}

{# Errors #}

{% block form_errors %}
{% apply spaceless %}
{% if error_delay %}
    {% for child in form %}
        {% if loop.index == 1 %}
            {% if child.set('errors', errors) %}{% endif %}
        {% endif %}
    {% endfor %}
{% else %}
    {% if errors|length > 0 %}
        {% if form.parent == null %}
            {% from '@MopaBootstrap/flash.html.twig' import flash %}
            {% for error in errors %}
                {{ flash('danger', error.message) }}
            {% endfor %}
        {% else %}
            <span class=\"help-{{ block('error_type') }}\">
            {% for error in errors %}
                {{ error.message }} <br>
            {% endfor %}
            </span>
        {% endif %}
    {% endif %}
{% endif %}
{% endapply %}
{% endblock form_errors %}

{# used to determine which type of error #}

{% block error_type %}
{% apply spaceless %}
{% if error_type %}
    {{ error_type }}
{% elseif form.parent == null %}
    {{ form.vars.error_type | default('inline') }}
{% else %}
    block
{% endif %}
{% endapply %}
{% endblock error_type %}

{# widget helper blocks #}

{% block widget_form_group_start %}
{% if widget_form_group|default(false) or form.parent == null %}
    {% if form.parent is not null and 'collection' in form.parent.vars.block_prefixes %} {# i am a collection child #}
        {% if not omit_collection_item %}
            {# collection item wrapper doesnt need form-group it gets added to childs anyways #}
        \t{% set widget_form_group_attr = widget_form_group_attr|merge({class: 'collection-item'}) %}
        {% endif %}
    {% endif %}
    {% if errors|length > 0 %}
\t    {# Add Error Class to Widget Wrapper#}
\t    {% set widget_form_group_attr = widget_form_group_attr|merge({'class': widget_form_group_attr.class|default('') ~ ' has-error'}) %}
    {% endif %}
    {% if help_widget_popover.selector is same as(null) %}
        {% set help_widget_popover = help_widget_popover|merge({'selector': '#' ~ id }) %}
    {% endif %}
    <div{% if help_widget_popover.title is not same as(null) %}{{ block('help_widget_popover') }}{% endif %} {% for attrname,attrvalue in widget_form_group_attr %} {{attrname}}=\"{{attrvalue}}\"{% endfor %}>
    {# a form item containing the field in block_prefixes is a near subform or a field directly #}
    {% if (form|length > 0 and form.parent != null)
        and 'field' not in form.vars.block_prefixes
        and 'date' not in form.vars.block_prefixes %}
        {% if show_child_legend%}
            {{ block('form_legend') }}
        {% elseif label_render %}
            {{ form_label(form, label|default(null)) }}
        {% else %}
        {% endif %}
    {% else %}
        {% if label_render %}
            {{ form_label(form, label|default(null)) }}
        {% endif %}
    {% endif %}
{% else %}
    {% if label_render %}
        {{ form_label(form, label|default(null)) }}
    {% endif %}
{% endif %}
{% endblock widget_form_group_start %}

{% block help_widget_popover %}
 {% apply spaceless %}
 {% for attrname,attrvalue in help_widget_popover %}
 data-{{attrname}}=\"{{attrvalue|trans({}, domain|default('messages'))}}\"
 {% endfor %}
 {% endapply %}
{% endblock help_widget_popover %}

{% block widget_form_group_end %}
{% apply spaceless %}
{% if widget_form_group|default(false) or form.parent == null %}
    </div>
{% endif %}
{% endapply %}
{% endblock widget_form_group_end %}
", "@MopaBootstrap/Form/fields.html.twig", "/var/www/productos/vendor/mopa/bootstrap-bundle/Resources/views/Form/fields.html.twig");
    }
}
