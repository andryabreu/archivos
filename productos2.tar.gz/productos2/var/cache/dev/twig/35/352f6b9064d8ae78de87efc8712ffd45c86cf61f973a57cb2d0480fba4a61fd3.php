<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @MopaBootstrap/Menu/menu.html.twig */
class __TwigTemplate_5a0f69c0e01c2cf91eebcc5f842d2e83ae6fadc54a328aa260e707e7e78e9c86 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'linkElement' => [$this, 'block_linkElement'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "@KnpMenu/menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/Menu/menu.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@MopaBootstrap/Menu/menu.html.twig"));

        $this->parent = $this->loadTemplate("@KnpMenu/menu.html.twig", "@MopaBootstrap/Menu/menu.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_linkElement($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "linkElement"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "linkElement"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        ";
        $macros["macros"] = $this->loadTemplate("knp_menu.html.twig", "@MopaBootstrap/Menu/menu.html.twig", 5)->unwrap();
        // line 6
        echo "        <a href=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 6, $this->source); })()), "uri", [], "any", false, false, false, 6), "html", null, true);
        echo "\"";
        echo twig_call_macro($macros["macros"], "macro_attributes", [twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 6, $this->source); })()), "linkAttributes", [], "any", false, false, false, 6)], 6, $context, $this->getSourceContext());
        echo ">
            ";
        // line 7
        if (((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "extras", [], "any", false, true, false, 7), "icon", [], "any", true, true, false, 7)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "extras", [], "any", false, true, false, 7), "icon", [], "any", false, false, false, 7), false)) : (false))) {
            // line 8
            echo "                ";
            echo $this->extensions['Mopa\Bundle\BootstrapBundle\Twig\IconExtension']->renderIcon($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 8, $this->source); })()), "extras", [], "any", false, false, false, 8), "icon", [], "any", false, false, false, 8), ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "extras", [], "any", false, true, false, 8), "icon_white", [], "any", true, true, false, 8)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "extras", [], "any", false, true, false, 8), "icon_white", [], "any", false, false, false, 8), false)) : (false)));
            echo " ";
        }
        // line 10
        echo "            ";
        $this->displayBlock("label", $context, $blocks);
        echo "
            ";
        // line 11
        $macros["badgemacro"] = $this->loadTemplate("@MopaBootstrap/macros.html.twig", "@MopaBootstrap/Menu/menu.html.twig", 11)->unwrap();
        // line 12
        if (((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "extras", [], "any", false, true, false, 12), "badge", [], "any", true, true, false, 12)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "extras", [], "any", false, true, false, 12), "badge", [], "any", false, false, false, 12), false)) : (false))) {
            // line 13
            echo "                ";
            echo twig_call_macro($macros["badgemacro"], "macro_badge", [twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 13, $this->source); })()), "extras", [], "any", false, false, false, 13), "badge", [], "any", false, false, false, 13), false, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 13, $this->source); })()), "extras", [], "any", false, false, false, 13), "badge_class", [], "any", false, false, false, 13)], 13, $context, $this->getSourceContext());
            echo "
            ";
        }
        // line 15
        if (((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "extras", [], "any", false, true, false, 15), "caret", [], "any", true, true, false, 15)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "extras", [], "any", false, true, false, 15), "caret", [], "any", false, false, false, 15), false)) : (false))) {
            // line 16
            echo "                <b class=\"caret\"></b>
            ";
        }
        // line 18
        echo "</a>
    ";
        $___internal_da24febc767db285d503d4d2a281a2612dd33196c933a7a16d23354499312304_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 4
        echo twig_spaceless($___internal_da24febc767db285d503d4d2a281a2612dd33196c933a7a16d23354499312304_);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@MopaBootstrap/Menu/menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 4,  109 => 18,  105 => 16,  103 => 15,  97 => 13,  95 => 12,  93 => 11,  88 => 10,  83 => 8,  81 => 7,  74 => 6,  71 => 5,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '@KnpMenu/menu.html.twig' %}

{% block linkElement %}
    {% apply spaceless %}
        {% import 'knp_menu.html.twig' as macros %}
        <a href=\"{{ item.uri }}\"{{ macros.attributes(item.linkAttributes) }}>
            {% if item.extras.icon|default(false) %}
                {{ mopa_bootstrap_icon(item.extras.icon, item.extras.icon_white|default(false)) }}{{ ' ' }}
            {%- endif %}
            {{ block('label') }}
            {% import '@MopaBootstrap/macros.html.twig' as badgemacro %}
            {%- if item.extras.badge|default(false) %}
                {{ badgemacro.badge(item.extras.badge, false, item.extras.badge_class) }}
            {% endif -%}
            {%- if item.extras.caret|default(false) %}
                <b class=\"caret\"></b>
            {% endif -%}
        </a>
    {% endapply %}
{% endblock %}
", "@MopaBootstrap/Menu/menu.html.twig", "/var/www/productos/vendor/mopa/bootstrap-bundle/Resources/views/Menu/menu.html.twig");
    }
}
